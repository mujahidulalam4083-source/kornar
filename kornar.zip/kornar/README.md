# KORNAR

A browser-based tool for designing **flexible logo systems**: edit live text and vector shapes on a canvas,
keep several variations of the same logo (horizontal, stacked, icon-only, dark, monochrome...) and export
clean **SVG** or high-resolution **PNG**. Everything runs locally in your browser; there is no server and
nothing is uploaded.

Stack: React 19 + TypeScript + Vite, plain CSS, SVG rendering, [lucide-react](https://lucide.dev) icons,
`localStorage` for projects. Runtime dependencies: `react`, `react-dom`, `lucide-react` only.

---

## Run it on Windows

You need **Node.js 20.19+ or 22.12+** (required by Vite 7). Check with `node -v`.
If it is missing, install the LTS version from <https://nodejs.org> or run
`winget install OpenJS.NodeJS.LTS`, then open a **new** terminal.

Open PowerShell (or Command Prompt) **in this folder** and run:

```powershell
npm install
npm run dev
```

Vite prints a local address (normally <http://localhost:5173>) and opens it in your browser.
Stop the server with `Ctrl+C`.

| Command | What it does |
| --- | --- |
| `npm run dev` | Development server with hot reload |
| `npm run build` | Production build into `dist/` |
| `npm run preview` | Serves the production build at <http://localhost:4173> to check it |
| `npm test` | Unit tests for the core logic (Node's built-in test runner via `tsx`) |
| `npm run typecheck` | Full TypeScript check (`tsc --noEmit`) |
| `npm run build:check` | Type-check, then build |

Notes
- `npm run build` intentionally does **not** run `tsc`, so a type-only problem can never stop you from
  building. Run `npm run typecheck` (or `build:check`) when you want the strict check.
- Open the built site through `npm run preview` or any static web server. Browsers block ES-module scripts
  opened directly from `file://`, so double-clicking `dist/index.html` will not work.
- Use a current Chrome, Edge or Firefox. (Only Chrome has been exercised; see *Verification*.)

---

## Using the app

First launch shows a short tour (reopen it from the Help button). A starter design is already on the canvas.

**Layout**
- **Top bar** - project name (click to rename), save status, Undo/Redo, New, Save, Reset, **Export**, theme, help.
- **Left panel** - *Design* (add shapes, position, size, rotation, fill/stroke), *Type* (all typography),
  *Color* (palettes, colour versions, brand colours), *Layout* (canvas size, aspect presets, padding, align,
  distribute, exact spacing, grid / snapping / guides).
- **Canvas** - click, drag, resize, rotate; shift-click or drag a box to multi-select; wheel to zoom,
  Space+drag to pan.
- **Right panel** - *Layers* (visibility, lock, stacking, duplicate, delete), *Variations*, *Projects*.
- **Status bar** - canvas size, zoom, selection, save state, last export.
- On screens narrower than ~1100 px the panels become slide-over drawers (toggle buttons in the top bar).

**Keyboard shortcuts** (press `?` in the app for the list)

| Keys | Action |
| --- | --- |
| `Ctrl+Z` / `Ctrl+Shift+Z` or `Ctrl+Y` | Undo / redo |
| `Ctrl+S`, `Ctrl+E` | Save, Export |
| `Ctrl+D`, `Ctrl+A`, `Delete`, `Esc` | Duplicate, select all, delete, deselect |
| Arrow keys (`Shift` = 10 px) | Nudge |
| `T` `R` `C` `E` `L` | Add text / rectangle / circle / ellipse / line |
| `V` / `H`, `Space`+drag | Select tool / hand tool, temporary pan |
| `Ctrl+0`, `Ctrl+1`, `Ctrl+=`, `Ctrl+-` | Fit, 100 %, zoom in/out |
| `[` / `]` | Send backward / bring forward |
| `Shift` while dragging | Constrain axis / keep proportions / 15 degree rotation steps |
| `Alt` while dragging | Disable snapping (resize: scale from centre) |

### Colours
Objects can use the palette roles **Primary**, **Secondary**, **Background** (handy for cut-outs) or a
custom hex colour. Switching a palette recolours everything that uses roles. *Colour version* gives
Full colour, Monochrome, Black/white and White/black without losing your palette. "Transparent background"
shows a checkerboard and exports without a background by default.

### Variations
Create a variation from the current one: *Copy*, *Horizontal*, *Stacked*, *Icon only*, *Wordmark only*,
*Light background*, *Dark background*, *Monochrome*. Layout variations are a **starting point** (symbol and
text are arranged automatically and the canvas is resized); edit them by hand as you like. If a conversion
is impossible (for example "Icon only" with no shapes) you get a clear message instead of a bad result.
Each variation keeps its own canvas, colours, colour version and objects.

### Fonts
KORNAR uses fonts installed on your computer (no font files are bundled). The Type tab marks fonts that are
**not installed**, shows what is rendered instead (a fallback), and lets you enter any other installed font
name. To use a Google font such as *Inter* or *Amiri*, install it in Windows first. Bengali-capable
(Nirmala UI, Vrinda, Shonar Bangla) and Arabic-capable (Tahoma, Segoe UI, Arial, Traditional Arabic...) fonts
are listed. Letter-spacing is automatically disabled for Arabic text because it breaks letter joining.

### Arabic-inspired work
Text objects support **RTL direction** and Arabic content; the geometric tools (rotated squares, rings, lines)
cover Islamic-geometry style construction, and the *Arabic-inspired geometric mark* template shows the idea.
KORNAR does **not** generate calligraphy and has no text-on-path.

### Export
Open **Export** (`Ctrl+E`) for the active variation:
- **SVG** - clean standalone markup, `viewBox` = design size, scalable. Custom width sets the `width`/`height`
  attributes; the height always follows the canvas proportions so nothing is cropped.
- **PNG** - drawn from your design alone (never a screenshot of the app) at 1x-4x or any width up to 8192 px.
- Include/exclude background (exclude = real alpha transparency), custom file name, copy SVG code.
- Success/error feedback appears in the dialog, a toast and the status bar. A browser cannot confirm where a
  download was saved, so the message says *"Download started"*.

**SVG text caveat.** Text stays live text. Someone opening the SVG without the same font will see a
substitute font and shifted spacing. For identical results everywhere export PNG, or convert text to
outlines in Inkscape (*Path > Object to Path*) / Illustrator (*Type > Create Outlines*). KORNAR does not
convert text to outlines itself (see limitations). Exporting never changes your project.

### Saving
- Projects **autosave to this browser** (`localStorage`) about 0.7 s after each change; the chip in the top bar
  shows *Saved / Saving... / Unsaved / Save failed*. A save is only reported as successful after the data is
  read back and verified. If storage is full or blocked you get an error, not a false "Saved".
- **Export JSON / Import JSON** (Projects panel) back up or move projects. Imports are validated
  field by field, numbers are clamped, colours and enums are whitelisted, files over 5 MB are rejected and
  nothing in a file is ever executed. Invalid files produce a specific message.
- Browser storage belongs to one browser profile on one computer and is cleared if you clear site data. Keep
  JSON backups of work you care about.

---

## Branding

- Header lockup: the golden "K" mark (`public/kornar-mark.png`, transparent background, native resolution)
  followed by the **KORNAR** wordmark (serif, wide tracking, gold). On screens narrower than ~900 px only the mark
  is shown; the name stays available to screen readers.
- Browser tab: title `KORNAR`; icons in `public/`: `favicon.ico` (16/24/32/48/64 px), `favicon-32.png`,
  `favicon-192.png`, `apple-touch-icon.png`. All were cropped from the supplied `korner.ico` (256 x 256, opaque
  background removed to a clean transparent cut-out).
- Storage: projects are stored under the `kornar:v1:` key prefix. Data saved by earlier releases under the old
  prefix is **moved automatically on first start** (verified copy, old keys removed only after every project
  copied successfully; if storage is full it rolls back and retries next start). Project JSON files exported by
  earlier releases still import. New project files are named `<project>.kornar.json`.
- To change the logo later, replace the files in `public/` (keep the file names) and the colour tokens
  `--brand-gold` in `src/styles/index.css`.

## Project structure

```
src/
  main.tsx, App.tsx            entry point and app shell (panels, dialogs)
  studio.tsx                   central state hub: reducer, autosave, project actions, view/zoom, toasts
  types.ts                     document model (Project > Variation > LogoObject), export options, prefs
  lib/
    reducer.ts                 editor state + undo/redo with coalescing (a drag/slider = one undo step)
    geometry.ts                bounds, rotated resize, snapping, align/distribute, fit-to-area
    measure.ts                 text layout (canvas measurement; deterministic estimate outside a browser)
    color.ts / palettes.ts     colour roles, colour versions (mono, B/W), contrast, curated palettes
    fonts.ts                   font list, installed-font detection, safe font stacks
    variations.ts              derive horizontal / stacked / icon / wordmark / light / dark / mono
    templates.ts               six original editable starter designs
    validate.ts                import validation / sanitising
    storage.ts                 verified localStorage persistence
    exporter.ts                SVG markup, PNG rendering, filenames, downloads
  components/
    canvas/                    LogoSvg (single renderer for canvas, thumbnails and export), Canvas, SelectionOverlay
    panels/                    Design, Type, Color, Layout, Layers, Variations, Projects
    dialogs/                   New project, Export, Onboarding, Help, Reset, Confirm
    ui/                        form fields, buttons, modal, toasts, icons
  styles/index.css             design tokens (light/dark) and all styling
public/                        logo mark + favicons
tests/                         unit tests (node:test)
```

Design notes
- The canvas, thumbnails and the SVG/PNG exports all render through the same React components
  (`LogoSvg.tsx`); the export is `renderToStaticMarkup` of that tree, so what you see is what you export.
- Editing state is one pure reducer over an immutable project, so undo/redo is a stack of snapshots.
- Objects are rebuilt from whitelisted fields on import, and all text is rendered as escaped SVG text.

---

## Verification status (please read)

This project was built in a sandbox **without internet access**, so `npm install`, `vite build` and a
Windows run could **not** be performed there. What was and was not verified:

**Run and passing**
- **78 unit tests** (`npm test` equivalent, run with `tsx` and Node's test runner): colour maths, geometry
  (rotated resize, snapping, align/distribute, fit), reducer/undo/redo/coalescing, import validation incl.
  hostile input, storage incl. quota failure and silent-write-drop detection, templates, variations, and SVG
  export (validated with `xmllint`).
- **Real-browser checks (101 assertions, headless Chrome 131)** against the actual bundled app: canvas drag/
  resize/rotate/marquee, shortcuts, typography incl. multi-line + Arabic/RTL anchoring, colour modes,
  layout, variations, autosave + reload persistence, project open/duplicate/delete, import rejection, reset +
  undo, theme, tablet layout, and **real downloaded files**: SVG validated with `xmllint`; PNGs checked with
  `sharp` for exact pixel size, background colour, and genuine alpha transparency.
- A TypeScript check passed (`tsc` 6.0.3, strict) **against hand-written minimal type stubs** for React and
  lucide, because `@types/react` could not be installed.

**Not verified**
- `npm install`, `npm run build`, `npm run dev` on Windows, and the strict `tsc` check with the real
  `@types/react` / `@types/node`. If `npm run typecheck` reports something, it is most likely a typing detail
  around React event types; it does not affect running the app (`build` skips `tsc` on purpose).
- Icons: the browser checks used placeholder icons (lucide could not be installed), so the *visual* look of
  icons is unverified. Icon names used are current canonical lucide names.
- Browsers other than Chrome (Firefox, Safari), real touch devices, and high-DPI/Windows font rendering.
- The browser test scripts are not included in this folder (they depend on tooling local to the sandbox).

## Known limitations

- **No text-to-outlines** inside the app (see the SVG text caveat). It would need font-file access and a font
  parser; use PNG or an external editor for outlined text.
- Shapes are rectangles, circles, ellipses and lines. **No pen tool / node editing**, no polygons, no boolean
  operations, no text-on-path, no gradients, no images, no grouping.
- Multi-selection supports move, align, distribute, spacing, fill/stroke/opacity; it does not resize or rotate
  as a group.
- Text boxes are measured with the browser's canvas text metrics; selection boxes follow the font's line box
  and can differ slightly from glyph ink. Positions are anchored at the box's top-left, so a project opened on a
  computer **without the same fonts** will render with fallback fonts and slightly different widths.
- Automatic variation layouts are heuristic; objects with custom (non-palette) colours keep them in
  Light/Dark variations.
- No export-all-variations button (export each variation in turn); no pinch-to-zoom on touch screens.
- `localStorage` limits (about 5 MB per site). PNG export is capped at 8192 px per side.
- Projects live in one browser profile; there is no cloud sync.
