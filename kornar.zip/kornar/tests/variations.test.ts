import test from 'node:test';
import assert from 'node:assert/strict';
import { deriveVariation, VARIATION_PRESETS } from '../src/lib/variations';
import { buildTemplate } from '../src/lib/templates';
import { getAABB, selectionBounds } from '../src/lib/geometry';
import { contrastRatio } from '../src/lib/color';
import { createText, createRect } from '../src/lib/model';
import { buildSvg } from '../src/lib/exporter';
import { assertWellFormedXml, sampleVariation } from './helpers';
import type { Variation } from '../src/types';

const source = (): Variation => buildTemplate('geometric-symbol')!.variations[0]!;
const must = (r: ReturnType<typeof deriveVariation>) => {
  assert.ok(r.ok, r.ok ? '' : r.error);
  return r.ok ? r.variation : (undefined as never);
};

test('deriving never mutates the source and always assigns new ids', () => {
  const s = source();
  const snapshot = JSON.stringify(s);
  for (const p of VARIATION_PRESETS) {
    const r = deriveVariation(s, p.kind);
    if (r.ok) {
      assert.notEqual(r.variation.id, s.id);
      assert.ok(r.variation.objects.every((o) => !s.objects.some((so) => so.id === o.id)));
    }
  }
  assert.equal(JSON.stringify(s), snapshot);
});

test('icon-only keeps only non-text objects, fitted into the safe area', () => {
  const v = must(deriveVariation(source(), 'icon'));
  assert.ok(v.objects.length > 0 && v.objects.every((o) => o.type !== 'text'));
  const b = selectionBounds(v.objects)!;
  assert.ok(b.x >= v.padding - 1 && b.y >= v.padding - 1 && b.x + b.w <= v.width - v.padding + 1 && b.y + b.h <= v.height - v.padding + 1);
});

test('wordmark-only keeps only text', () => {
  const v = must(deriveVariation(source(), 'wordmark'));
  assert.ok(v.objects.length > 0 && v.objects.every((o) => o.type === 'text'));
});

test('horizontal puts symbols left of text on one row; stacked puts symbols above text, centred', () => {
  const h = must(deriveVariation(source(), 'horizontal'));
  const hs = selectionBounds(h.objects.filter((o) => o.type !== 'text'))!;
  const ht = selectionBounds(h.objects.filter((o) => o.type === 'text'))!;
  assert.ok(hs.x + hs.w <= ht.x + 0.5, 'symbol should end before text starts');
  assert.ok(Math.abs(hs.y + hs.h / 2 - (ht.y + ht.h / 2)) < 1, 'vertically centred on one row');
  assert.ok(h.width > h.height, 'horizontal canvas is landscape');
  const s = must(deriveVariation(source(), 'stacked'));
  const ss = selectionBounds(s.objects.filter((o) => o.type !== 'text'))!;
  const st = selectionBounds(s.objects.filter((o) => o.type === 'text'))!;
  assert.ok(ss.y + ss.h <= st.y + 0.5);
  assert.ok(Math.abs(ss.x + ss.w / 2 - (st.x + st.w / 2)) < 1, 'horizontally centred');
  for (const v of [h, s]) for (const o of v.objects) {
    const a = getAABB(o);
    assert.ok(a.x >= -1 && a.y >= -1 && a.x + a.w <= v.width + 1 && a.y + a.h <= v.height + 1, `${v.name}/${o.name} escapes canvas`);
  }
});

test('layouts report an honest error when there is nothing to arrange', () => {
  const onlyText = sampleVariation([createText()]);
  const onlyShape = sampleVariation([createRect()]);
  for (const kind of ['horizontal', 'stacked'] as const) {
    for (const v of [onlyText, onlyShape]) {
      const r = deriveVariation(v, kind);
      assert.equal(r.ok, false);
      if (!r.ok) assert.match(r.error, /needs both text and shapes/);
    }
  }
  assert.equal(deriveVariation(onlyShape, 'wordmark').ok, false);
  assert.equal(deriveVariation(onlyText, 'icon').ok, false);
});

test('light and dark variations pick readable colours', () => {
  const dark = sampleVariation([createText()], { colors: { background: '#000000', primary: '#fafafa', secondary: '#ffff66', transparentBackground: true } });
  const light = must(deriveVariation(dark, 'light'));
  assert.equal(light.colors.background, '#ffffff');
  assert.ok(contrastRatio(light.colors.primary, '#ffffff') >= 3);
  assert.ok(contrastRatio(light.colors.secondary, '#ffffff') >= 3);
  assert.equal(light.colors.transparentBackground, false);
  const bright = sampleVariation([createText()], { colors: { background: '#ffffff', primary: '#101010', secondary: '#222222', transparentBackground: false } });
  const darkV = must(deriveVariation(bright, 'dark'));
  assert.ok(contrastRatio(darkV.colors.primary, darkV.colors.background) >= 3);
  assert.ok(contrastRatio(darkV.colors.secondary, darkV.colors.background) >= 3);
});

test('monochrome variation only switches the colour mode and keeps the geometry', () => {
  const s = source();
  const m = must(deriveVariation(s, 'mono'));
  assert.equal(m.colorMode, 'mono');
  assert.equal(m.objects.length, s.objects.length);
});

test('every derivable variation exports as valid SVG', () => {
  for (const p of VARIATION_PRESETS) {
    const r = deriveVariation(source(), p.kind);
    if (!r.ok) continue;
    assertWellFormedXml(buildSvg(r.variation, { width: r.variation.width, height: r.variation.height, includeBackground: true }));
  }
});
