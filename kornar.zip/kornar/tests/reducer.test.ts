import test from 'node:test';
import assert from 'node:assert/strict';
import { createEditorState, getActiveVariation, reducer, type Action, type EditorState } from '../src/lib/reducer';
import { createRect, createCircle, createVariation, createProject, createText } from '../src/lib/model';
import { sampleProject } from './helpers';
import type { RectObject } from '../src/types';

const fresh = (): EditorState => createEditorState(sampleProject());
const run = (s: EditorState, ...as: Action[]) => as.reduce(reducer, s);
const objs = (s: EditorState) => getActiveVariation(s).objects;

test('add object selects it; undo removes it; redo restores it', () => {
  const r = createRect({ name: 'R' });
  let s = run(fresh(), { type: 'addObject', object: r, t: 1 });
  assert.equal(objs(s).length, 1);
  assert.deepEqual(s.selection, [r.id]);
  s = run(s, { type: 'undo' });
  assert.equal(objs(s).length, 0);
  assert.equal(s.selection.length, 0);
  s = run(s, { type: 'redo' });
  assert.equal(objs(s).length, 1);
});

test('a new edit clears the redo stack', () => {
  const r = createRect();
  let s = run(fresh(), { type: 'addObject', object: r, t: 1 }, { type: 'undo' });
  assert.equal(s.future.length, 1);
  s = run(s, { type: 'addObject', object: createCircle(), t: 2 });
  assert.equal(s.future.length, 0);
});

test('coalescing: same key within the window = one undo step; different key or stale = new step', () => {
  const r = createRect({ x: 0 });
  let s = run(fresh(), { type: 'addObject', object: r, t: 0 });
  const base = s.past.length;
  s = run(s,
    { type: 'patchObjects', ids: [r.id], patch: { x: 1 }, coalesce: 'x', t: 100 },
    { type: 'patchObjects', ids: [r.id], patch: { x: 2 }, coalesce: 'x', t: 300 },
    { type: 'patchObjects', ids: [r.id], patch: { x: 3 }, coalesce: 'x', t: 900 });
  assert.equal(s.past.length, base + 1);
  s = run(s, { type: 'patchObjects', ids: [r.id], patch: { x: 4 }, coalesce: 'x', t: 5000 }); // stale -> new step
  assert.equal(s.past.length, base + 2);
  s = run(s, { type: 'patchObjects', ids: [r.id], patch: { y: 9 }, coalesce: 'y', t: 5100 }); // other key
  assert.equal(s.past.length, base + 3);
  s = run(s, { type: 'undo' });
  assert.equal((objs(s)[0] as RectObject).y, 0);
  assert.equal((objs(s)[0] as RectObject).x, 4);
  s = run(s, { type: 'undo' });
  assert.equal((objs(s)[0] as RectObject).x, 3);
});

test('a drag (infinite window) is one undo step even with long pauses', () => {
  const r = createRect({ x: 10 });
  let s = run(fresh(), { type: 'addObject', object: r, t: 0 });
  const base = s.past.length;
  for (let i = 1; i <= 5; i++) s = run(s, { type: 'applyChanges', changes: { [r.id]: { x: 10 + i * 10 } }, coalesce: 'drag:1', window: Infinity, t: i * 3000 });
  assert.equal(s.past.length, base + 1);
  s = run(s, { type: 'undo' });
  assert.equal((objs(s)[0] as RectObject).x, 10);
});

test('no-op patches do not create history entries', () => {
  const r = createRect({ x: 5 });
  let s = run(fresh(), { type: 'addObject', object: r, t: 0 });
  const n = s.past.length;
  s = run(s, { type: 'patchObjects', ids: [r.id], patch: {}, t: 1 });
  assert.equal(s.past.length, n);
  s = run(s, { type: 'patchObjects', ids: ['missing'], patch: { x: 1 }, t: 2 });
  assert.equal(s.past.length, n);
});

test('patches ignore properties that do not belong to the object type', () => {
  const t = createText();
  const s = run(fresh(), { type: 'addObject', object: t, t: 0 }, { type: 'patchObjects', ids: [t.id], patch: { cornerRadius: 9, fontSize: 40 }, t: 1 });
  const o = objs(s)[0] as unknown as Record<string, unknown>;
  assert.equal(o.fontSize, 40);
  assert.ok(!('cornerRadius' in o));
});

test('delete and duplicate', () => {
  const a = createRect({ x: 0, y: 0 });
  const b = createCircle({ x: 50, y: 50 });
  let s = run(fresh(), { type: 'addObject', object: a, t: 0 }, { type: 'addObject', object: b, t: 1 });
  s = run(s, { type: 'duplicateObjects', ids: [a.id], t: 2 });
  assert.equal(objs(s).length, 3);
  const copy = objs(s)[2]!;
  assert.notEqual(copy.id, a.id);
  assert.equal(copy.x, 20);
  assert.deepEqual(s.selection, [copy.id]);
  s = run(s, { type: 'deleteObjects', ids: [copy.id, b.id], t: 3 });
  assert.equal(objs(s).length, 1);
  assert.deepEqual(s.selection, []);
});

test('reorder moves objects in the stacking order and stops at the ends', () => {
  const [a, b, c] = [createRect(), createRect(), createRect()];
  let s = run(fresh(), ...[a, b, c].map((object, i) => ({ type: 'addObject', object, t: i }) as Action));
  s = run(s, { type: 'reorder', id: a.id, to: 'up', t: 10 });
  assert.deepEqual(objs(s).map((o) => o.id), [b.id, a.id, c.id]);
  s = run(s, { type: 'reorder', id: a.id, to: 'top', t: 11 });
  assert.deepEqual(objs(s).map((o) => o.id), [b.id, c.id, a.id]);
  const n = s.past.length;
  s = run(s, { type: 'reorder', id: a.id, to: 'up', t: 12 });
  assert.equal(s.past.length, n);
  s = run(s, { type: 'reorder', id: a.id, to: 'bottom', t: 13 });
  assert.equal(objs(s)[0]!.id, a.id);
});

test('canvas resize clamps, recentres content and updates padding limits', () => {
  const r = createRect({ x: 100, y: 100, width: 100, height: 100 });
  let s = run(fresh(), { type: 'addObject', object: r, t: 0 });
  const v0 = getActiveVariation(s);
  s = run(s, { type: 'setCanvas', width: v0.width + 200, height: v0.height + 100, recenter: true, t: 1 });
  assert.equal(objs(s)[0]!.x, 200);
  assert.equal(objs(s)[0]!.y, 150);
  s = run(s, { type: 'setCanvas', width: 1, height: 999999, t: 2 });
  assert.equal(getActiveVariation(s).width, 16);
  assert.equal(getActiveVariation(s).height, 8000);
  assert.ok(getActiveVariation(s).padding <= 0);
});

test('colours: active variation vs all variations; colour mode', () => {
  const v2 = createVariation({ name: 'Second' });
  const p = createProject('P', [createVariation(), v2]);
  let s = createEditorState(p);
  s = run(s, { type: 'setColors', patch: { primary: '#ff0000' }, t: 1 });
  assert.equal(s.project.variations[0]!.colors.primary, '#ff0000');
  assert.notEqual(s.project.variations[1]!.colors.primary, '#ff0000');
  s = run(s, { type: 'setColors', patch: { background: '#000000' }, allVariations: true, t: 2 });
  assert.ok(s.project.variations.every((v) => v.colors.background === '#000000'));
  s = run(s, { type: 'setColorMode', mode: 'bw', t: 3 });
  assert.equal(s.project.variations[0]!.colorMode, 'bw');
  assert.equal(s.project.variations[1]!.colorMode, 'full');
});

test('variations: add switches to it, each keeps its own objects, last one cannot be deleted', () => {
  const r = createRect();
  let s = run(fresh(), { type: 'addObject', object: r, t: 0 });
  const first = s.activeId;
  const v2 = createVariation({ name: 'Second', objects: [] });
  s = run(s, { type: 'addVariation', variation: v2, t: 1 });
  assert.equal(s.activeId, v2.id);
  assert.equal(objs(s).length, 0);
  s = run(s, { type: 'setActiveVariation', id: first });
  assert.equal(objs(s).length, 1);
  s = run(s, { type: 'deleteVariation', id: first, t: 2 });
  assert.equal(s.project.variations.length, 1);
  assert.equal(s.activeId, v2.id);
  const before = s.project;
  s = run(s, { type: 'deleteVariation', id: v2.id, t: 3 });
  assert.equal(s.project, before);
});

test('undo/redo never leaves the active variation pointing at a missing id', () => {
  const v2 = createVariation({ name: 'Second' });
  let s = run(fresh(), { type: 'addVariation', variation: v2, t: 1 });
  assert.equal(s.activeId, v2.id);
  s = run(s, { type: 'undo' });
  assert.ok(s.project.variations.some((v) => v.id === s.activeId));
  s = run(s, { type: 'redo' });
  assert.equal(s.project.variations.length, 2);
});

test('load resets history and selection; rename coalesces', () => {
  let s = run(fresh(), { type: 'addObject', object: createRect(), t: 0 });
  s = run(s, { type: 'load', project: sampleProject() });
  assert.equal(s.past.length, 0);
  assert.equal(s.selection.length, 0);
  const n = s.past.length;
  s = run(s, { type: 'rename', name: 'A', t: 10 }, { type: 'rename', name: 'AB', t: 20 }, { type: 'rename', name: 'ABC', t: 30 });
  assert.equal(s.past.length, n + 1);
  assert.equal(s.project.name, 'ABC');
});

test('project object identity is preserved when nothing changes (dirty tracking relies on it)', () => {
  const s = fresh();
  const same = run(s, { type: 'select', ids: [] }, { type: 'setColorMode', mode: 'full', t: 1 }, { type: 'setCanvas', t: 2 });
  assert.equal(same.project, s.project);
  const undone = run(run(s, { type: 'rename', name: 'X', t: 1 }), { type: 'undo' });
  assert.equal(undone.project, s.project);
});
