import test from 'node:test';
import assert from 'node:assert/strict';
import { TEMPLATES, buildTemplate } from '../src/lib/templates';
import { parseProject } from '../src/lib/validate';
import { getAABB } from '../src/lib/geometry';
import { createBlankProject } from '../src/lib/model';

test('there are the six required starter templates, each building a valid editable project', () => {
  assert.deepEqual(
    TEMPLATES.map((t) => t.id),
    ['minimal-wordmark', 'bold-typographic', 'geometric-symbol', 'circular-badge', 'arabic-geometric', 'modern-editorial'],
  );
  for (const t of TEMPLATES) {
    const p = t.build();
    assert.ok(parseProject(p).ok, t.id);
    const v = p.variations[0]!;
    assert.ok(v.objects.length >= 3, `${t.id} should be built from several editable objects`);
    const ids = new Set(v.objects.map((o) => o.id));
    assert.equal(ids.size, v.objects.length, `${t.id} has duplicate ids`);
    assert.equal(p.activeVariationId, v.id);
    assert.equal(p.templateId, t.id);
  }
});

test('each build produces fresh ids (templates can be used repeatedly)', () => {
  const a = buildTemplate('circular-badge')!;
  const b = buildTemplate('circular-badge')!;
  assert.notEqual(a.id, b.id);
  assert.notEqual(a.variations[0]!.objects[0]!.id, b.variations[0]!.objects[0]!.id);
  assert.equal(buildTemplate('nope'), null);
});

test('template content stays inside its canvas', () => {
  for (const t of TEMPLATES) {
    const v = t.build().variations[0]!;
    for (const o of v.objects) {
      const a = getAABB(o);
      assert.ok(a.x >= -1 && a.y >= -1 && a.x + a.w <= v.width + 1 && a.y + a.h <= v.height + 1, `${t.id}/${o.name} escapes the canvas: ${JSON.stringify(a)}`);
    }
  }
});

test('Arabic-inspired template uses RTL Arabic text plus geometric shapes (no fake calligraphy)', () => {
  const v = buildTemplate('arabic-geometric')!.variations[0]!;
  const arabic = v.objects.find((o) => o.type === 'text' && /[\u0600-\u06FF]/.test(o.text));
  assert.ok(arabic && arabic.type === 'text' && arabic.direction === 'rtl');
  assert.ok(v.objects.filter((o) => o.type === 'rect' && o.rotation === 45).length >= 2, 'eight-pointed star needs rotated squares');
});

test('templates colour through palette roles, so palette switching recolours them', () => {
  for (const t of TEMPLATES) {
    const v = t.build().variations[0]!;
    const refs = v.objects.flatMap((o) => [(o as { fill?: string }).fill, (o as { stroke?: string }).stroke]).filter(Boolean) as string[];
    assert.ok(refs.every((r) => ['primary', 'secondary', 'background', 'none'].includes(r)), `${t.id} uses hard-coded colours`);
  }
});

test('blank project has an empty canvas', () => {
  assert.equal(createBlankProject().variations[0]!.objects.length, 0);
});
