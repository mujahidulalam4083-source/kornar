import test from 'node:test';
import assert from 'node:assert/strict';
import { ProjectStore, DEFAULT_PREFS, migrateLegacyData, type KeyValueStore } from '../src/lib/storage';
import { sampleProject } from './helpers';
import { createRect } from '../src/lib/model';

class MemStore implements KeyValueStore {
  data = new Map<string, string>();
  getItem(k: string) { return this.data.get(k) ?? null; }
  setItem(k: string, v: string) { this.data.set(k, v); }
  removeItem(k: string) { this.data.delete(k); }
}

test('save, list, load and remove round-trip', () => {
  const store = new ProjectStore(new MemStore());
  const p = sampleProject([createRect()]);
  const saved = store.save(p);
  assert.ok(saved.ok);
  assert.equal(store.list().length, 1);
  assert.equal(store.list()[0]!.name, 'Test project');
  const loaded = store.load(p.id);
  assert.ok(loaded.ok);
  if (loaded.ok) assert.deepEqual(loaded.value, p);
  assert.ok(store.remove(p.id).ok);
  assert.equal(store.list().length, 0);
  assert.equal(store.load(p.id).ok, false);
});

test('saving the same project twice updates (does not duplicate) the index entry', () => {
  const store = new ProjectStore(new MemStore());
  const p = sampleProject();
  store.save(p);
  store.save({ ...p, name: 'Renamed', updatedAt: p.updatedAt + 5 });
  assert.equal(store.list().length, 1);
  assert.equal(store.list()[0]!.name, 'Renamed');
});

test('a quota error is reported as a failed save, never as success', () => {
  const mem = new MemStore();
  mem.setItem = () => { const e = new Error('full'); e.name = 'QuotaExceededError'; throw e; };
  const r = new ProjectStore(mem).save(sampleProject());
  assert.equal(r.ok, false);
  if (!r.ok) assert.match(r.error, /storage is full/i);
});

test('a store that silently drops writes is detected by read-back verification', () => {
  const mem = new MemStore();
  mem.setItem = () => undefined; // pretends to work
  const r = new ProjectStore(mem).save(sampleProject());
  assert.equal(r.ok, false);
  if (!r.ok) assert.match(r.error, /could not be verified/);
});

test('corrupted or tampered stored data fails safely', () => {
  const mem = new MemStore();
  const store = new ProjectStore(mem);
  const p = sampleProject();
  store.save(p);
  mem.setItem('kornar:v1:project:' + p.id, '{broken');
  const r = store.load(p.id);
  assert.equal(r.ok, false);
  mem.setItem('kornar:v1:project:' + p.id, JSON.stringify({ variations: [{ width: 'x' }] }));
  assert.equal(store.load(p.id).ok, false);
  mem.setItem('kornar:v1:index', '{"not":"an array"}');
  assert.deepEqual(store.list(), []);
  mem.setItem('kornar:v1:index', 'garbage');
  assert.deepEqual(store.list(), []);
});

test('preferences: defaults, persistence and sanitising', () => {
  const mem = new MemStore();
  const store = new ProjectStore(mem);
  assert.deepEqual(store.getPrefs(), DEFAULT_PREFS);
  store.setPrefs({ ...DEFAULT_PREFS, theme: 'dark', autosave: false, onboardingSeen: true, gridSize: 40 });
  const p = store.getPrefs();
  assert.equal(p.theme, 'dark');
  assert.equal(p.autosave, false);
  assert.equal(p.gridSize, 40);
  mem.setItem('kornar:v1:prefs', JSON.stringify({ theme: 'neon', gridSize: -5, autosave: 'yes' }));
  const q = store.getPrefs();
  assert.equal(q.theme, DEFAULT_PREFS.theme);
  assert.equal(q.gridSize, DEFAULT_PREFS.gridSize);
  assert.equal(q.autosave, DEFAULT_PREFS.autosave);
});

test('current project pointer is cleared when that project is deleted', () => {
  const store = new ProjectStore(new MemStore());
  const p = sampleProject();
  store.save(p);
  store.setCurrentId(p.id);
  assert.equal(store.getCurrentId(), p.id);
  store.remove(p.id);
  assert.equal(store.getCurrentId(), null);
});

// ---- migration from the pre-rename key prefix -----------------------------------------------------
const OLD = 'fleximark:v1:'; // the legacy prefix, spelled out here on purpose: this is test data for the migration
function legacyStore(n = 2) {
  const mem = new MemStore();
  const projects = Array.from({ length: n }, (_, i) => ({ ...sampleProject([createRect()]), name: `Old ${i}` }));
  for (const p of projects) mem.setItem(OLD + 'project:' + p.id, JSON.stringify(p));
  mem.setItem(OLD + 'index', JSON.stringify(projects.map((p) => ({ id: p.id, name: p.name, updatedAt: p.updatedAt }))));
  mem.setItem(OLD + 'current', projects[0]!.id);
  mem.setItem(OLD + 'prefs', JSON.stringify({ ...DEFAULT_PREFS, theme: 'dark', onboardingSeen: true }));
  return { mem, projects };
}

test('migration: saved projects, current pointer and prefs move to the new prefix and old keys are removed', () => {
  const { mem, projects } = legacyStore(2);
  assert.deepEqual(migrateLegacyData(mem), { migrated: 2, failed: false });
  const store = new ProjectStore(mem);
  assert.equal(store.list().length, 2);
  for (const p of projects) {
    const r = store.load(p.id);
    assert.ok(r.ok);
    if (r.ok) assert.deepEqual(r.value, p);
  }
  assert.equal(store.getCurrentId(), projects[0]!.id);
  assert.equal(store.getPrefs().theme, 'dark');
  assert.equal(store.getPrefs().onboardingSeen, true, 'returning users do not see the tour again');
  assert.deepEqual([...mem.data.keys()].filter((k) => k.startsWith(OLD)), [], 'legacy keys cleaned up');
});

test('migration is idempotent and never overwrites data already on the new prefix', () => {
  const { mem } = legacyStore(1);
  const fresh = sampleProject();
  const store = new ProjectStore(mem);
  store.save(fresh); // new-prefix index now exists
  const before = [...mem.data.entries()].sort().join('|');
  assert.deepEqual(migrateLegacyData(mem), { migrated: 0, failed: false });
  assert.equal([...mem.data.entries()].sort().join('|'), before);
  assert.equal(store.list().length, 1);
  const again = legacyStore(1).mem;
  assert.equal(migrateLegacyData(again).migrated, 1);
  assert.deepEqual(migrateLegacyData(again), { migrated: 0, failed: false });
});

test('migration failure (e.g. storage full) rolls back, keeps the old data and retries later', () => {
  const { mem, projects } = legacyStore(2);
  const realSet = mem.setItem.bind(mem);
  let n = 0;
  mem.setItem = (k: string, v: string) => { if (k.startsWith('kornar:') && ++n === 2) { const e = new Error('full'); e.name = 'QuotaExceededError'; throw e; } realSet(k, v); };
  assert.deepEqual(migrateLegacyData(mem), { migrated: 0, failed: true });
  assert.deepEqual([...mem.data.keys()].filter((k) => k.startsWith('kornar:')), [], 'partial copies removed');
  assert.ok(mem.getItem(OLD + 'project:' + projects[0]!.id) && mem.getItem(OLD + 'project:' + projects[1]!.id), 'old data intact');
  mem.setItem = realSet; // space freed up -> next start succeeds
  assert.equal(migrateLegacyData(mem).migrated, 2);
});

test('migration tolerates a corrupt legacy index and missing project bodies', () => {
  const bad = new MemStore();
  bad.setItem(OLD + 'index', 'garbage');
  assert.deepEqual(migrateLegacyData(bad), { migrated: 0, failed: false });
  const { mem, projects } = legacyStore(2);
  mem.removeItem(OLD + 'project:' + projects[1]!.id);
  assert.equal(migrateLegacyData(mem).migrated, 1);
  assert.equal(new ProjectStore(mem).list().length, 1);
  assert.deepEqual(migrateLegacyData(new MemStore()), { migrated: 0, failed: false });
});
