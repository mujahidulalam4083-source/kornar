import test from 'node:test';
import assert from 'node:assert/strict';
import {
  alignChanges, angleFromPointer, computeSnap, distributeChanges, fitObjects, getAABB, getBounds, placeCentered,
  resizeObject, rotatePoint, safeArea, selectionBounds, getFrame, centerOf,
} from '../src/lib/geometry';
import { createCircle, createLine, createRect, createText } from '../src/lib/model';
import type { LogoObject, RectObject } from '../src/types';

const close = (a: number, b: number, eps = 0.01) => assert.ok(Math.abs(a - b) <= eps, `${a} !~ ${b}`);

test('bounds: rect, line and text', () => {
  const r = createRect({ x: 10, y: 20, width: 100, height: 50 });
  assert.deepEqual(getBounds(r), { x: 10, y: 20, w: 100, h: 50 });
  const l = createLine({ x: 0, y: 40, width: 200, strokeWidth: 10 });
  assert.deepEqual(getBounds(l), { x: 0, y: 40, w: 200, h: 0 });
  assert.deepEqual(getFrame(l), { x: 0, y: 35, w: 200, h: 10 });
  const t = createText({ text: 'ab\ncd\nef', fontSize: 100, lineHeight: 1.2 });
  assert.equal(getBounds(t).h, 360);
});

test('AABB of a 90 degree rotated rect swaps its dimensions around the centre', () => {
  const r = createRect({ x: 0, y: 0, width: 200, height: 100, rotation: 90 });
  const a = getAABB(r);
  close(a.w, 100); close(a.h, 200); close(a.x, 50); close(a.y, -50);
});

test('placeCentered centres an object on a point', () => {
  const r = placeCentered(createRect({ width: 100, height: 40 }), 500, 300);
  assert.deepEqual([r.x, r.y], [450, 280]);
});

test('resize: unrotated south-east handle keeps the top-left fixed', () => {
  const r = createRect({ x: 100, y: 100, width: 200, height: 100 });
  const p = resizeObject(r, 'se', { x: 300, y: 200 }, { x: 350, y: 230 }, { keepAspect: false, fromCenter: false });
  assert.deepEqual(p, { x: 100, y: 100, width: 250, height: 130 });
});

test('resize: west handle moves x and keeps the right edge fixed', () => {
  const r = createRect({ x: 100, y: 100, width: 200, height: 100 });
  const p = resizeObject(r, 'w', { x: 100, y: 150 }, { x: 60, y: 150 }, { keepAspect: false, fromCenter: false });
  assert.deepEqual(p, { x: 60, y: 100, width: 240, height: 100 });
});

test('resize: rotated object keeps the opposite edge fixed in canvas space', () => {
  const r = createRect({ x: 100, y: 100, width: 200, height: 100, rotation: 90 });
  const before = getFrame(r);
  const c0 = centerOf(before);
  const anchorBefore = rotatePoint({ x: before.x, y: before.y + before.h / 2 }, c0, 90); // local west-middle
  // east handle sits at canvas-bottom for a 90deg rotation; drag it 40px down
  const patch = resizeObject(r, 'e', { x: 200, y: 250 }, { x: 200, y: 290 }, { keepAspect: false, fromCenter: false });
  const next = { ...r, ...patch } as RectObject;
  close(next.width, 240); close(next.height, 100);
  const after = getFrame(next);
  const anchorAfter = rotatePoint({ x: after.x, y: after.y + after.h / 2 }, centerOf(after), 90);
  close(anchorAfter.x, anchorBefore.x); close(anchorAfter.y, anchorBefore.y);
});

test('resize: aspect lock (circle, shift) scales proportionally; minimum size is enforced', () => {
  const c = createCircle({ x: 0, y: 0, width: 100, height: 100 });
  const p = resizeObject(c, 'se', { x: 100, y: 100 }, { x: 160, y: 120 }, { keepAspect: false, fromCenter: false });
  assert.equal(p.width, p.height);
  assert.equal(p.width, 160);
  const r = createRect({ x: 0, y: 0, width: 200, height: 100 });
  const q = resizeObject(r, 'se', { x: 200, y: 100 }, { x: 300, y: 100 }, { keepAspect: true, fromCenter: false });
  close((q.width as number) / (q.height as number), 2);
  const tiny = resizeObject(r, 'e', { x: 200, y: 50 }, { x: -500, y: 50 }, { keepAspect: false, fromCenter: false });
  assert.equal(tiny.width, 4);
});

test('resize: text scales font size proportionally', () => {
  const t = createText({ x: 0, y: 0, fontSize: 100, text: 'abcd', letterSpacing: 10 });
  const b = getBounds(t);
  const p = resizeObject(t, 'se', { x: b.w, y: b.h }, { x: b.w * 2, y: b.h * 2 }, { keepAspect: true, fromCenter: false });
  close(p.fontSize as number, 200, 0.5);
  close(p.letterSpacing as number, 20, 0.5);
});

test('resize: lines only change length', () => {
  const l = createLine({ x: 0, y: 50, width: 100 });
  const p = resizeObject(l, 'e', { x: 100, y: 50 }, { x: 160, y: 90 }, { keepAspect: false, fromCenter: false });
  assert.deepEqual(p, { x: 0, y: 50, width: 160 });
});

test('rotation handle angle (0 = straight up) with 15 degree snapping', () => {
  const c = { x: 100, y: 100 };
  close(angleFromPointer(c, { x: 100, y: 0 }, false), 0);
  close(angleFromPointer(c, { x: 200, y: 100 }, false), 90);
  close(angleFromPointer(c, { x: 100, y: 200 }, false), 180);
  close(angleFromPointer(c, { x: 200, y: 20 }, true) % 15, 0);
});

const trio = (): LogoObject[] => [
  createRect({ x: 0, y: 0, width: 100, height: 40 }),
  createRect({ x: 150, y: 30, width: 50, height: 40 }),
  createRect({ x: 400, y: 80, width: 100, height: 20 }),
];

test('align to an area', () => {
  const objs = trio();
  const area = { x: 0, y: 0, w: 1000, h: 500 };
  const left = alignChanges(objs, 'left', area);
  assert.ok(Object.values(left).every((p) => p.x === 0));
  const right = alignChanges(objs, 'right', area);
  assert.equal(right[objs[0]!.id]!.x, 900);
  const mid = alignChanges(objs, 'vcenter', area);
  assert.equal(mid[objs[2]!.id]!.y, 240);
});

test('distribute spreads equal gaps; explicit gap sets exact spacing', () => {
  const objs = trio();
  const even = distributeChanges(objs, 'h');
  const placed = objs.map((o) => ({ ...o, ...even[o.id] })) as RectObject[];
  const gap1 = placed[1]!.x - (placed[0]!.x + placed[0]!.width);
  const gap2 = placed[2]!.x - (placed[1]!.x + placed[1]!.width);
  close(gap1, gap2);
  const exact = distributeChanges(objs, 'h', 20);
  const p2 = objs.map((o) => ({ ...o, ...exact[o.id] })) as RectObject[];
  close(p2[1]!.x - (p2[0]!.x + p2[0]!.width), 20);
  close(p2[2]!.x - (p2[1]!.x + p2[1]!.width), 20);
  assert.deepEqual(distributeChanges(objs.slice(0, 2), 'h'), {}); // even distribution needs >= 3
});

test('snapping picks the nearest target within the threshold only', () => {
  const box = { x: 497, y: 100, w: 100, h: 50 };
  const s = computeSnap(box, { xs: [0, 500, 1000], ys: [0, 250] }, 6);
  assert.equal(s.dx, 3);
  assert.equal(s.dy, 0);
  assert.deepEqual(s.guides, [{ axis: 'x', pos: 500 }]);
  const far = computeSnap({ x: 300, y: 300, w: 10, h: 10 }, { xs: [0], ys: [0] }, 6);
  assert.deepEqual([far.dx, far.dy, far.guides.length], [0, 0, 0]);
  const grid = computeSnap({ x: 23, y: 41, w: 10, h: 10 }, { xs: [], ys: [], grid: 20 }, 6);
  assert.deepEqual([grid.dx, grid.dy], [-3, -1]);
});

test('fitObjects scales content into the safe area and centres it', () => {
  const objs = [createRect({ x: 0, y: 0, width: 100, height: 50 }), createCircle({ x: 100, y: 0, width: 50, height: 50 })];
  const area = safeArea({ width: 1000, height: 600, padding: 100 });
  const fitted = fitObjects(objs, area);
  const b = selectionBounds(fitted)!;
  close(b.w, 800); // content is 150x50 -> limited by width
  close(b.x, 100); close(b.y + b.h / 2, 300);
  assert.equal((fitted[0] as RectObject).width, 533.33);
});
