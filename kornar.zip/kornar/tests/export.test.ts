import test from 'node:test';
import assert from 'node:assert/strict';
import { buildSvg, defaultFilename, prettyPrintSvg, safeFilename, validateExportSize } from '../src/lib/exporter';
import { TEMPLATES } from '../src/lib/templates';
import { createCircle, createLine, createRect, createText } from '../src/lib/model';
import { assertWellFormedXml, sampleVariation } from './helpers';

const opts = (v: { width: number; height: number }, extra: object = {}) => ({ width: v.width, height: v.height, includeBackground: true, ...extra });

test('every template exports well-formed SVG with a matching viewBox', () => {
  for (const t of TEMPLATES) {
    const v = t.build().variations[0]!;
    const svg = buildSvg(v, opts(v, { title: t.name }));
    assertWellFormedXml(svg);
    assert.ok(svg.startsWith('<?xml version="1.0" encoding="UTF-8"?>\n<svg '), t.id);
    assert.ok(svg.includes('xmlns="http://www.w3.org/2000/svg"'), t.id);
    assert.ok(svg.includes(`viewBox="0 0 ${v.width} ${v.height}"`), t.id);
    assert.ok(svg.includes(`width="${v.width}"`) && svg.includes(`height="${v.height}"`), t.id);
    assert.ok(!/NaN|undefined|Infinity/.test(svg), `${t.id} contains an invalid number`);
  }
});

test('custom export size changes width/height but keeps the design viewBox (scalable output)', () => {
  const v = sampleVariation([createRect({ x: 10, y: 10, width: 100, height: 100 })], { width: 1200, height: 800 });
  const svg = buildSvg(v, { width: 300, height: 200, includeBackground: true });
  assert.ok(svg.includes('width="300"') && svg.includes('height="200"'));
  assert.ok(svg.includes('viewBox="0 0 1200 800"'));
});

test('background can be included or excluded (transparent export)', () => {
  const v = sampleVariation([createRect({ width: 50, height: 50 })], { colors: { background: '#abcdef', primary: '#111111', secondary: '#222222', transparentBackground: false } });
  assert.ok(buildSvg(v, opts(v)).includes('fill="#abcdef"'));
  const noBg = buildSvg(v, opts(v, { includeBackground: false }));
  assert.ok(!noBg.includes('#abcdef'));
  assert.equal((noBg.match(/<rect/g) ?? []).length, 1); // only the logo's own rect
});

test('colours, shapes, rotation and stroke are preserved', () => {
  const v = sampleVariation(
    [
      createRect({ x: 10, y: 20, width: 100, height: 50, fill: '#ff0000', stroke: '#00ff00', strokeWidth: 4, rotation: 45, cornerRadius: 8, opacity: 0.5 }),
      createCircle({ x: 0, y: 0, width: 60, height: 60, fill: 'secondary' }),
      createLine({ x: 0, y: 100, width: 200, stroke: 'primary', strokeWidth: 8, lineCap: 'round' }),
    ],
    { colors: { background: '#ffffff', primary: '#112233', secondary: '#445566', transparentBackground: false } },
  );
  const svg = buildSvg(v, opts(v));
  assertWellFormedXml(svg);
  assert.match(svg, /<rect[^>]*x="10"[^>]*y="20"[^>]*width="100"[^>]*height="50"[^>]*rx="8"[^>]*fill="#ff0000"[^>]*stroke="#00ff00"[^>]*stroke-width="4"[^>]*opacity="0.5"[^>]*transform="rotate\(45 60 45\)"/);
  assert.match(svg, /<circle[^>]*cx="30"[^>]*cy="30"[^>]*r="30"[^>]*fill="#445566"/);
  const line = svg.match(/<line[^>]*>/)?.[0] ?? '';
  for (const attr of ['x1="0"', 'y1="100"', 'x2="200"', 'y2="100"', 'stroke="#112233"', 'stroke-width="8"', 'stroke-linecap="round"']) {
    assert.ok(line.includes(attr), `line is missing ${attr}: ${line}`);
  }
});

test('fill="none" shapes and zero-width strokes do not emit invalid paint', () => {
  const v = sampleVariation([createRect({ fill: 'none', stroke: 'primary', strokeWidth: 0 })]);
  const svg = buildSvg(v, opts(v, { includeBackground: false }));
  assert.ok(svg.includes('fill="none"'));
  assert.ok(!svg.includes('stroke='));
});

test('text: multiple lines, anchors, escaping and font fallbacks', () => {
  const t = createText({ text: 'A & B <tag> "q"\nSecond', fontFamily: 'Georgia', fontSize: 50, align: 'left', x: 40, y: 60, fontWeight: 700, italic: true, letterSpacing: 3 });
  const v = sampleVariation([t]);
  const svg = buildSvg(v, opts(v, { includeBackground: false }));
  assertWellFormedXml(svg);
  assert.ok(svg.includes('A &amp; B &lt;tag&gt; &quot;q&quot;') || svg.includes('A &amp; B &lt;tag&gt; "q"'));
  assert.ok(!svg.includes('<tag>'));
  assert.equal((svg.match(/<tspan/g) ?? []).length, 2);
  assert.ok(svg.includes(`font-family="'Georgia', serif"`) || svg.includes('font-family="&#x27;Georgia&#x27;, serif"') || svg.includes('font-family="&#39;Georgia&#39;, serif"'));
  assert.ok(svg.includes('font-weight="700"') && svg.includes('font-style="italic"') && svg.includes('letter-spacing="3"'));
  assert.ok(svg.includes('text-anchor="start"'));
});

test('text transform is applied to the exported string (not CSS)', () => {
  const v = sampleVariation([createText({ text: 'Hello World', transform: 'uppercase' }), createText({ text: 'Hello World', transform: 'lowercase', y: 200 })]);
  const svg = buildSvg(v, opts(v));
  assert.ok(svg.includes('HELLO WORLD') && svg.includes('hello world'));
  assert.ok(!svg.includes('text-transform'));
});

test('RTL text exports direction and Arabic content; letter-spacing is dropped for Arabic', () => {
  const v = sampleVariation([createText({ text: 'نجمة', direction: 'rtl', letterSpacing: 12, align: 'left' })]);
  const svg = buildSvg(v, opts(v));
  assertWellFormedXml(svg);
  assert.ok(svg.includes('direction="rtl"'));
  assert.ok(svg.includes('نجمة'));
  assert.ok(!svg.includes('letter-spacing'));
  assert.ok(svg.includes('text-anchor="end"')); // visual-left in RTL
});

test('text outline uses stroke with paint-order so the fill stays clean', () => {
  const v = sampleVariation([createText({ stroke: '#ff0000', strokeWidth: 3 })]);
  const svg = buildSvg(v, opts(v, { includeBackground: false }));
  assert.ok(svg.includes('stroke="#ff0000"') && svg.includes('stroke-width="3"') && svg.includes('paint-order="stroke fill"'));
});

test('hidden objects are not exported; empty design is still valid SVG', () => {
  const hidden = createRect({ fill: '#123456', visible: false });
  const v = sampleVariation([hidden]);
  const svg = buildSvg(v, opts(v, { includeBackground: false }));
  assert.ok(!svg.includes('#123456'));
  assertWellFormedXml(svg);
});

test('monochrome and black-and-white modes are reflected in the export', () => {
  const objs = [createRect({ fill: 'secondary' }), createCircle({ fill: '#ff00ff' })];
  const colors = { background: '#eeeeee', primary: '#335577', secondary: '#ff8800', transparentBackground: false };
  const mono = buildSvg(sampleVariation(objs, { colors, colorMode: 'mono' }), { width: 1200, height: 800, includeBackground: true });
  assert.ok(!mono.includes('#ff8800') && !mono.includes('#ff00ff') && mono.includes('#335577'));
  const bw = buildSvg(sampleVariation(objs, { colors, colorMode: 'bw' }), { width: 1200, height: 800, includeBackground: true });
  assert.ok(bw.includes('#ffffff') && bw.includes('#000000') && !bw.includes('#335577'));
});

test('title is escaped and optional', () => {
  const v = sampleVariation([]);
  assert.ok(buildSvg(v, opts(v, { title: 'A & <B>' })).includes('<title>A &amp; &lt;B&gt;</title>'));
  assert.ok(!buildSvg(v, opts(v)).includes('<title>'));
});

test('pretty printer never inserts whitespace between tspans', () => {
  const v = sampleVariation([createText({ text: 'one\ntwo\nthree' })]);
  const svg = buildSvg(v, opts(v, { includeBackground: false }));
  assert.ok(!/<\/tspan>\s+<tspan/.test(svg));
  assert.ok(!/<text[^>]*>\s+<tspan/.test(svg));
  assert.equal(prettyPrintSvg('<svg a="1"><rect></rect></svg>').split('\n').length, 3);
});

test('export size validation and Windows-safe filenames', () => {
  assert.equal(validateExportSize(1000, 1000), null);
  assert.match(validateExportSize(8, 1000)!, /at least 16/);
  assert.match(validateExportSize(9000, 100)!, /at most 8192/);
  assert.match(validateExportSize(NaN, 100)!, /valid/);
  assert.equal(safeFilename('a<b>c:d"e/f\\g|h?i*j', 'svg'), 'abcdefghij.svg');
  assert.equal(safeFilename('logo.svg', 'svg'), 'logo.svg');
  assert.equal(safeFilename('...', 'png'), 'logo.png');
  const v = sampleVariation([], { name: 'Dark background' });
  assert.equal(defaultFilename('My Brand!', v, 'png', 2400, 1600), 'my-brand-dark-background-2400x1600.png');
  assert.equal(defaultFilename('My Brand!', v, 'svg'), 'my-brand-dark-background.svg');
  assert.equal(defaultFilename('نجمة', v, 'svg'), 'نجمة-dark-background.svg');
});
