import test from 'node:test';
import assert from 'node:assert/strict';
import { parseProject, parseProjectJson, serializeProject } from '../src/lib/validate';
import { TEMPLATES } from '../src/lib/templates';
import { createRect, createText } from '../src/lib/model';
import { sampleProject } from './helpers';

test('every template survives a serialise -> parse round trip unchanged', () => {
  for (const t of TEMPLATES) {
    const p = t.build();
    const r = parseProjectJson(serializeProject(p));
    assert.ok(r.ok, `${t.id}: ${r.ok ? '' : r.error}`);
    if (r.ok) assert.deepEqual(r.value, p, t.id);
  }
});

test('accepts a bare project object as well as the file wrapper', () => {
  const p = sampleProject([createRect()]);
  assert.ok(parseProject(p).ok);
  assert.ok(parseProject({ app: 'KORNAR', schemaVersion: 1, project: p }).ok);
  // the wrapper's app label is informational only, so files exported by earlier releases still import
  assert.ok(parseProject({ app: 'some-earlier-export', schemaVersion: 1, project: p }).ok);
});

test('rejects non-JSON, wrong shapes and unsupported versions with clear messages', () => {
  const bad = (x: string) => {
    const r = parseProjectJson(x);
    assert.equal(r.ok, false, x);
    return r.ok ? '' : r.error;
  };
  assert.match(bad('{not json'), /not valid JSON/);
  assert.match(bad('[]'), /project object/);
  assert.match(bad('null'), /project object/);
  assert.match(bad('{"variations":[]}'), /no variations/);
  assert.match(bad('{"schemaVersion":99,"variations":[]}'), /Unsupported project version/);
  assert.match(bad('{"variations":[{"width":100,"height":100}]}'), /objects must be a list/);
  assert.match(bad('"just a string"'), /project object/);
});

test('rejects unknown object types, bad enums and invalid colours', () => {
  const v = (o: unknown) => ({ variations: [{ width: 500, height: 500, objects: [o] }] });
  const r1 = parseProject(v({ type: 'script', x: 0 }));
  assert.equal(r1.ok, false);
  assert.match(r1.ok ? '' : r1.error, /type must be one of/);
  const r2 = parseProject(v({ type: 'rect', width: 10, height: 10, fill: 'url(javascript:alert(1))' }));
  assert.equal(r2.ok, false);
  assert.match(r2.ok ? '' : r2.error, /not a valid colour/);
  const r3 = parseProject(v({ type: 'text', text: 'x', align: 'justify' }));
  assert.equal(r3.ok, false);
  const r4 = parseProject({ variations: [{ width: 500, height: 500, objects: [], colors: { primary: 'red' } }] });
  assert.equal(r4.ok, false);
});

test('clamps out-of-range numbers and rejects non-numbers', () => {
  const r = parseProject({ variations: [{ width: 999999, height: 2, padding: 1e9, objects: [{ type: 'rect', width: 5, height: 5, opacity: 7, rotation: 1e9, strokeWidth: -4 }] }] });
  assert.ok(r.ok);
  if (!r.ok) return;
  const v = r.value.variations[0]!;
  assert.equal(v.width, 8000);
  assert.equal(v.height, 16);
  assert.ok(v.padding <= 0 + 1);
  const o = v.objects[0]!;
  assert.equal(o.opacity, 1);
  assert.ok(o.rotation <= 3600);
  assert.equal((o as { strokeWidth: number }).strokeWidth, 0);
  const bad = parseProject({ variations: [{ width: 'wide', height: 100, objects: [] }] });
  assert.equal(bad.ok, false);
  const nan = parseProject({ variations: [{ width: 100, height: 100, objects: [{ type: 'rect', width: null }] }] });
  assert.equal(nan.ok, false);
});

test('hostile content is kept as inert data and never interpreted', () => {
  const evil = '</text><script>alert(1)</script>"><img src=x onerror=alert(1)>';
  const r = parseProject({
    id: '__proto__',
    variations: [{ width: 500, height: 500, objects: [{ type: 'text', text: evil, fontFamily: `Arial'; } body { display:none } /*`, __proto__: { polluted: true }, constructor: { prototype: { polluted: true } } }] }],
    __proto__: { polluted2: true },
  });
  assert.ok(r.ok);
  if (!r.ok) return;
  const o = r.value.variations[0]!.objects[0] as { text: string; fontFamily: string };
  assert.equal(o.text, evil); // preserved verbatim as text (escaped on render)
  assert.ok(!/['";{}]/.test(o.fontFamily), `font family not sanitised: ${o.fontFamily}`);
  assert.equal(({} as Record<string, unknown>).polluted, undefined);
  assert.equal(({} as Record<string, unknown>).polluted2, undefined);
});

test('enforces limits: object count, variation count, file size, text length', () => {
  const many = { variations: [{ width: 500, height: 500, objects: Array.from({ length: 501 }, () => ({ type: 'rect', width: 1, height: 1 })) }] };
  assert.equal(parseProject(many).ok, false);
  const manyV = { variations: Array.from({ length: 31 }, () => ({ width: 500, height: 500, objects: [] })) };
  assert.equal(parseProject(manyV).ok, false);
  assert.equal(parseProjectJson(' '.repeat(5 * 1024 * 1024 + 1)).ok, false);
  const long = parseProject({ variations: [{ width: 500, height: 500, objects: [{ type: 'text', text: 'a'.repeat(50000) }] }] });
  assert.ok(long.ok);
  if (long.ok) assert.equal((long.value.variations[0]!.objects[0] as { text: string }).text.length, 2000);
});

test('missing optional fields get defaults; duplicate ids are repaired', () => {
  const r = parseProject({ variations: [{ width: 400, height: 300, objects: [{ id: 'a', type: 'text' }, { id: 'a', type: 'rect', width: 1, height: 1 }] }] });
  assert.ok(r.ok);
  if (!r.ok) return;
  const [o1, o2] = r.value.variations[0]!.objects;
  assert.notEqual(o1!.id, o2!.id);
  assert.equal((o1 as { fontFamily: string }).fontFamily, 'Arial');
  assert.equal(r.value.name, 'Imported logo');
  assert.equal(r.value.activeVariationId, r.value.variations[0]!.id);
});

test('text objects keep RTL direction and Arabic content', () => {
  const p = sampleProject([createText({ text: 'نجمة', direction: 'rtl' })]);
  const r = parseProjectJson(serializeProject(p));
  assert.ok(r.ok);
  if (r.ok) {
    const t = r.value.variations[0]!.objects[0] as { text: string; direction: string };
    assert.equal(t.text, 'نجمة');
    assert.equal(t.direction, 'rtl');
  }
});
