import test from 'node:test';
import assert from 'node:assert/strict';
import { contrastRatio, ensureContrast, normalizeColorRef, normalizeHex, resolveBackground, resolveColor } from '../src/lib/color';
import type { ColorMode } from '../src/types';

const ctx = (colorMode: ColorMode) => ({
  colorMode,
  colors: { background: '#fafafa', primary: '#123456', secondary: '#ff8800', transparentBackground: false },
});

test('normalizeHex accepts #rgb, rgb and #RRGGBB and rejects junk', () => {
  assert.equal(normalizeHex('#ABC'), '#aabbcc');
  assert.equal(normalizeHex('1a2b3c'), '#1a2b3c');
  assert.equal(normalizeHex('  #FFFFFF '), '#ffffff');
  for (const bad of ['', '#12', '#12345', '#gggggg', 'red', '#1234567', 'url(x)']) assert.equal(normalizeHex(bad), null, bad);
});

test('normalizeColorRef accepts roles and hex only', () => {
  assert.equal(normalizeColorRef('primary'), 'primary');
  assert.equal(normalizeColorRef('none'), 'none');
  assert.equal(normalizeColorRef('#FFF'), '#ffffff');
  assert.equal(normalizeColorRef('javascript:alert(1)'), null);
  assert.equal(normalizeColorRef(5), null);
});

test('contrast ratio matches WCAG reference values', () => {
  assert.ok(Math.abs(contrastRatio('#000000', '#ffffff') - 21) < 0.01);
  assert.ok(Math.abs(contrastRatio('#ffffff', '#ffffff') - 1) < 0.01);
  assert.equal(ensureContrast('#f0f0f0', '#ffffff', '#111111'), '#111111');
  assert.equal(ensureContrast('#222222', '#ffffff', '#111111'), '#222222');
});

test('full colour mode resolves roles and passes hex through', () => {
  const c = ctx('full');
  assert.equal(resolveColor('primary', c), '#123456');
  assert.equal(resolveColor('secondary', c), '#ff8800');
  assert.equal(resolveColor('background', c), '#fafafa');
  assert.equal(resolveColor('#abcdef', c), '#abcdef');
  assert.equal(resolveColor('none', c), 'none');
  assert.equal(resolveBackground(c), '#fafafa');
});

test('monochrome paints everything with the primary colour, cut-outs keep the background', () => {
  const c = ctx('mono');
  assert.equal(resolveColor('secondary', c), '#123456');
  assert.equal(resolveColor('#abcdef', c), '#123456');
  assert.equal(resolveColor('background', c), '#fafafa');
  assert.equal(resolveColor('none', c), 'none');
});

test('black & white modes produce only black/white', () => {
  const bw = ctx('bw');
  assert.equal(resolveBackground(bw), '#ffffff');
  assert.equal(resolveColor('primary', bw), '#000000');
  assert.equal(resolveColor('secondary', bw), '#000000');
  assert.equal(resolveColor('background', bw), '#ffffff');
  assert.equal(resolveColor('#ffffff', bw), '#ffffff');
  assert.equal(resolveColor('#336699', bw), '#000000');
  const inv = ctx('bw-inverted');
  assert.equal(resolveBackground(inv), '#000000');
  assert.equal(resolveColor('primary', inv), '#ffffff');
  assert.equal(resolveColor('background', inv), '#000000');
});
