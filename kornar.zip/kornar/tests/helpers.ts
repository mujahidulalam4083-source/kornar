import { spawnSync } from 'node:child_process';
import assert from 'node:assert/strict';
import type { LogoObject, Project, Variation } from '../src/types';
import { createProject, createVariation } from '../src/lib/model';

/** Asserts well-formed XML. Uses xmllint when installed, otherwise a conservative tag-balance check. */
export function assertWellFormedXml(xml: string): 'xmllint' | 'fallback' {
  const probe = spawnSync('xmllint', ['--version'], { encoding: 'utf8' });
  if (!probe.error) {
    const r = spawnSync('xmllint', ['--noout', '-'], { input: xml, encoding: 'utf8' });
    assert.equal(r.status, 0, `xmllint rejected the SVG:\n${r.stderr}`);
    return 'xmllint';
  }
  const body = xml.replace(/<\?xml[^>]*\?>/, '');
  const stack: string[] = [];
  const re = /<(\/?)([A-Za-z][\w:-]*)((?:\s+[\w:-]+="[^"<]*")*)\s*(\/?)>/g;
  let last = 0;
  let m: RegExpExecArray | null;
  while ((m = re.exec(body))) {
    const between = body.slice(last, m.index);
    assert.ok(!/[<>]/.test(between.replace(/&(?:lt|gt|amp|quot|apos|#\d+);/g, '')), `stray markup near: ${between.slice(0, 40)}`);
    last = re.lastIndex;
    if (m[1]) assert.equal(stack.pop(), m[2], `unbalanced </${m[2]}>`);
    else if (!m[4]) stack.push(m[2]!);
  }
  assert.equal(stack.length, 0, `unclosed tags: ${stack.join(',')}`);
  return 'fallback';
}

export function sampleVariation(objects: LogoObject[] = [], p: Partial<Variation> = {}): Variation {
  return createVariation({ objects, ...p });
}

export function sampleProject(objects: LogoObject[] = []): Project {
  return createProject('Test project', [sampleVariation(objects)]);
}
