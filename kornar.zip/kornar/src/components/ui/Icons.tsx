import { Circle, Minus, Square, Type } from 'lucide-react';
import type { ObjectType } from '../../types';

export function EllipseIcon({ size = 16 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <ellipse cx="12" cy="12" rx="10" ry="6" />
    </svg>
  );
}

export function ObjectIcon({ type, size = 16 }: { type: ObjectType; size?: number }) {
  switch (type) {
    case 'text':
      return <Type size={size} />;
    case 'rect':
      return <Square size={size} />;
    case 'circle':
      return <Circle size={size} />;
    case 'ellipse':
      return <EllipseIcon size={size} />;
    case 'line':
      return <Minus size={size} />;
  }
}

export const OBJECT_LABEL: Record<ObjectType, string> = { text: 'Text', rect: 'Rectangle', circle: 'Circle', ellipse: 'Ellipse', line: 'Line' };
