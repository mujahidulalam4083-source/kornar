import type { ReactNode } from 'react';

interface Props {
  icon: ReactNode;
  label: string;
  onClick?: () => void;
  shortcut?: string;
  active?: boolean;
  disabled?: boolean;
  danger?: boolean;
  className?: string;
  text?: string;
}

/** Icon button with an accessible name and a tooltip. Pass `text` to also show a visible label. */
export function IconButton({ icon, label, onClick, shortcut, active, disabled, danger, className = '', text }: Props) {
  return (
    <button
      type="button"
      className={`btn icon-btn${text ? ' with-text' : ''}${active ? ' is-active' : ''}${danger ? ' is-danger' : ''} ${className}`}
      title={shortcut ? `${label} (${shortcut})` : label}
      aria-label={label}
      aria-pressed={active === undefined ? undefined : active}
      disabled={disabled}
      onClick={onClick}
    >
      {icon}
      {text ? <span>{text}</span> : null}
    </button>
  );
}
