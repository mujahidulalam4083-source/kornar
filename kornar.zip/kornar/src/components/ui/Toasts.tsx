import { TriangleAlert, CircleCheck, Info, X } from 'lucide-react';
import { useStudio } from '../../studio';

export function Toasts() {
  const { toasts, dismissToast } = useStudio();
  return (
    <div className="toasts" aria-live="polite">
      {toasts.map((t) => (
        <div key={t.id} className={`toast toast-${t.kind}`} role={t.kind === 'error' ? 'alert' : 'status'}>
          {t.kind === 'success' ? <CircleCheck size={16} /> : t.kind === 'error' ? <TriangleAlert size={16} /> : <Info size={16} />}
          <span>{t.text}</span>
          <button type="button" className="toast-x" aria-label="Dismiss message" onClick={() => dismissToast(t.id)}>
            <X size={14} />
          </button>
        </div>
      ))}
    </div>
  );
}
