import { useId, useState, type KeyboardEvent, type ReactNode } from 'react';
import { RotateCcw } from 'lucide-react';
import { useStudio } from '../../studio';
import { normalizeHex, resolveColor } from '../../lib/color';
import { clamp, round } from '../../lib/util';

export function Section({ title, children, action }: { title: string; children: ReactNode; action?: ReactNode }) {
  return (
    <section className="section">
      <header className="section-head">
        <h3>{title}</h3>
        {action}
      </header>
      <div className="section-body">{children}</div>
    </section>
  );
}

export function Hint({ children, tone }: { children: ReactNode; tone?: 'warn' | 'error' }) {
  return <p className={`hint${tone ? ` hint-${tone}` : ''}`} role={tone === 'error' ? 'alert' : undefined}>{children}</p>;
}

interface FieldProps {
  label: string;
  htmlFor?: string;
  children: ReactNode;
  onReset?: () => void;
  canReset?: boolean;
  hint?: ReactNode;
}

/** Label + control + optional "reset to default" button. */
export function Field({ label, htmlFor, children, onReset, canReset, hint }: FieldProps) {
  return (
    <div className="field">
      <div className="field-head">
        <label htmlFor={htmlFor}>{label}</label>
        {onReset && canReset ? (
          <button type="button" className="reset-btn" title={`Reset ${label} to default`} aria-label={`Reset ${label} to default`} onClick={onReset}>
            <RotateCcw size={12} />
          </button>
        ) : null}
      </div>
      {children}
      {hint ? <div className="field-hint">{hint}</div> : null}
    </div>
  );
}

interface NumberFieldProps {
  label: string;
  value: number;
  onChange: (v: number) => void;
  min?: number;
  max?: number;
  step?: number;
  unit?: string;
  defaultValue?: number;
  slider?: boolean;
  sliderMin?: number;
  sliderMax?: number;
  precision?: number;
  hint?: ReactNode;
  disabled?: boolean;
}

export function NumberField({ label, value, onChange, min = -Infinity, max = Infinity, step = 1, unit, defaultValue, slider, sliderMin, sliderMax, precision = 2, hint, disabled }: NumberFieldProps) {
  const id = useId();
  const [draft, setDraft] = useState<string | null>(null);
  const shown = draft ?? String(round(value, precision));
  const parsed = draft === null ? value : draft.trim() === '' ? NaN : Number(draft);
  const invalid = draft !== null && !Number.isFinite(parsed);

  const onKey = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
      e.preventDefault();
      const dir = e.key === 'ArrowUp' ? 1 : -1;
      const next = clamp(round(value + dir * step * (e.shiftKey ? 10 : 1), precision), min, max);
      setDraft(null);
      onChange(next);
    } else if (e.key === 'Enter') {
      (e.target as HTMLInputElement).blur();
    }
  };

  return (
    <Field label={label} htmlFor={id} onReset={defaultValue !== undefined ? () => onChange(defaultValue) : undefined} canReset={defaultValue !== undefined && Math.abs(value - defaultValue) > 1e-9} hint={invalid ? <span className="text-error">Enter a number{Number.isFinite(min) && Number.isFinite(max) ? ` between ${min} and ${max}` : ''}.</span> : hint}>
      <div className="num-row">
        {slider ? (
          <input type="range" aria-label={`${label} slider`} min={sliderMin ?? min} max={sliderMax ?? max} step={step} value={clamp(value, sliderMin ?? min, sliderMax ?? max)} disabled={disabled} onChange={(e) => onChange(Number(e.target.value))} />
        ) : null}
        <div className={`num-input${invalid ? ' invalid' : ''}`}>
          <input
            id={id}
            type="text"
            inputMode="decimal"
            autoComplete="off"
            value={shown}
            disabled={disabled}
            aria-invalid={invalid || undefined}
            onChange={(e) => {
              setDraft(e.target.value);
              const n = Number(e.target.value);
              if (e.target.value.trim() !== '' && Number.isFinite(n)) onChange(clamp(n, min, max));
            }}
            onBlur={() => setDraft(null)}
            onKeyDown={onKey}
          />
          {unit ? <span className="unit">{unit}</span> : null}
        </div>
      </div>
    </Field>
  );
}

interface SegOption<T> {
  value: T;
  label: ReactNode;
  title?: string;
}

export function Segmented<T extends string | number>({ label, value, options, onChange, onReset, canReset, disabled }: { label: string; value: T; options: SegOption<T>[]; onChange: (v: T) => void; onReset?: () => void; canReset?: boolean; disabled?: boolean }) {
  const id = useId();
  return (
    <Field label={label} htmlFor={id} onReset={onReset} canReset={canReset}>
      <div className="segmented" role="radiogroup" aria-label={label} id={id}>
        {options.map((o) => (
          <button key={String(o.value)} type="button" role="radio" aria-checked={o.value === value} className={o.value === value ? 'is-active' : ''} title={o.title ?? (typeof o.label === 'string' ? o.label : undefined)} aria-label={o.title} disabled={disabled} onClick={() => onChange(o.value)}>
            {o.label}
          </button>
        ))}
      </div>
    </Field>
  );
}

export function Toggle({ label, checked, onChange, disabled, hint }: { label: string; checked: boolean; onChange: (v: boolean) => void; disabled?: boolean; hint?: string }) {
  const id = useId();
  return (
    <div className="toggle-row">
      <input id={id} type="checkbox" checked={checked} disabled={disabled} onChange={(e) => onChange(e.target.checked)} />
      <label htmlFor={id}>
        {label}
        {hint ? <small>{hint}</small> : null}
      </label>
    </div>
  );
}

export function TextField({ label, value, onChange, placeholder, onReset, canReset, maxLength, multiline, rows = 3, dir, disabled, hint, id: idProp }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string; onReset?: () => void; canReset?: boolean; maxLength?: number; multiline?: boolean; rows?: number; dir?: 'ltr' | 'rtl' | 'auto'; disabled?: boolean; hint?: ReactNode; id?: string }) {
  const gen = useId();
  const id = idProp ?? gen;
  return (
    <Field label={label} htmlFor={id} onReset={onReset} canReset={canReset} hint={hint}>
      {multiline ? (
        <textarea id={id} className="input" rows={rows} value={value} maxLength={maxLength} placeholder={placeholder} dir={dir} disabled={disabled} onChange={(e) => onChange(e.target.value)} />
      ) : (
        <input id={id} className="input" type="text" value={value} maxLength={maxLength} placeholder={placeholder} dir={dir} disabled={disabled} onChange={(e) => onChange(e.target.value)} />
      )}
    </Field>
  );
}

interface ColorFieldProps {
  label: string;
  value: string;
  onChange: (v: string) => void;
  /** Allow palette roles (primary / secondary / background). When false the value is always a hex colour. */
  allowRoles?: boolean;
  allowNone?: boolean;
  defaultValue?: string;
}

const ROLE_LABEL: Record<string, string> = { primary: 'Primary', secondary: 'Secondary', background: 'Background', none: 'None' };

export function ColorField({ label, value, onChange, allowRoles = true, allowNone = false, defaultValue }: ColorFieldProps) {
  const { variation } = useStudio();
  const id = useId();
  const isRole = ['primary', 'secondary', 'background', 'none'].includes(value);
  const resolved = (ref: string) => resolveColor(ref, { colors: variation.colors, colorMode: 'full' });
  const current = isRole ? (value === 'none' ? '#ffffff' : resolved(value)) : value;
  const [draft, setDraft] = useState<string | null>(null);
  const hexInvalid = draft !== null && normalizeHex(draft) === null;
  const roles = ['primary', 'secondary', 'background', ...(allowNone ? ['none'] : [])];

  return (
    <Field label={label} htmlFor={`${id}-hex`} onReset={defaultValue !== undefined ? () => onChange(defaultValue) : undefined} canReset={defaultValue !== undefined && value !== defaultValue}>
      {allowRoles ? (
        <div className="chips" role="group" aria-label={`${label} source`}>
          {roles.map((r) => (
            <button key={r} type="button" className={`chip${value === r ? ' is-active' : ''}`} aria-pressed={value === r} title={r === 'none' ? 'No paint' : `${ROLE_LABEL[r]} colour (follows the palette)`} onClick={() => onChange(r)}>
              <span className={`swatch${r === 'none' ? ' swatch-none' : ''}`} style={r === 'none' ? undefined : { background: resolved(r) }} />
              {ROLE_LABEL[r]}
            </button>
          ))}
          <button type="button" className={`chip${!isRole ? ' is-active' : ''}`} aria-pressed={!isRole} title="Pick a custom colour" onClick={() => {
              if (isRole) onChange(value === 'none' ? '#808080' : current);
            }}>
            <span className="swatch" style={{ background: !isRole ? value : 'conic-gradient(red, yellow, lime, aqua, blue, magenta, red)' }} />
            Custom
          </button>
        </div>
      ) : null}
      {!allowRoles || !isRole ? (
        <div className="color-row">
          <input type="color" aria-label={`${label} colour picker`} value={current.length === 7 ? current : '#000000'} onChange={(e) => onChange(e.target.value.toLowerCase())} />
          <input
            id={`${id}-hex`}
            className={`input mono${hexInvalid ? ' invalid' : ''}`}
            type="text"
            aria-label={`${label} hexadecimal value`}
            aria-invalid={hexInvalid || undefined}
            spellCheck={false}
            maxLength={7}
            value={draft ?? current}
            onChange={(e) => {
              setDraft(e.target.value);
              const n = normalizeHex(e.target.value);
              if (n) onChange(n);
            }}
            onBlur={() => setDraft(null)}
          />
        </div>
      ) : (
        <input id={`${id}-hex`} className="sr-only" readOnly value={value} aria-hidden="true" tabIndex={-1} />
      )}
      {hexInvalid ? <div className="field-hint text-error">Use a hex colour like #1a2b3c.</div> : null}
    </Field>
  );
}

export function SelectField<T extends string | number>({ label, value, options, onChange, onReset, canReset, disabled, hint }: { label: string; value: T; options: { value: T; label: string }[]; onChange: (v: T) => void; onReset?: () => void; canReset?: boolean; disabled?: boolean; hint?: ReactNode }) {
  const id = useId();
  return (
    <Field label={label} htmlFor={id} onReset={onReset} canReset={canReset} hint={hint}>
      <select id={id} className="input" value={String(value)} disabled={disabled} onChange={(e) => onChange((typeof value === 'number' ? Number(e.target.value) : e.target.value) as T)}>
        {options.map((o) => (
          <option key={String(o.value)} value={String(o.value)}>
            {o.label}
          </option>
        ))}
      </select>
    </Field>
  );
}
