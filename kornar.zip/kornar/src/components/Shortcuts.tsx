import { useEffect, useRef } from 'react';
import { useStudio } from '../studio';
import { getActiveVariation } from '../lib/reducer';

/** Global keyboard shortcuts. Renders nothing. */
export function Shortcuts() {
  const s = useStudio();
  const ref = useRef(s);
  ref.current = s;

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const st = ref.current;
      if (st.dialog || st.confirmReq) return;
      const t = e.target;
      const typing = t instanceof HTMLElement && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName));
      const mod = e.ctrlKey || e.metaKey;
      const key = e.key.toLowerCase();

      if (mod) {
        if (key === 's') {
          e.preventDefault();
          st.saveNow(true);
          return;
        }
        if (key === 'e') {
          e.preventDefault();
          st.openDialog('export');
          return;
        }
        if (typing) return; // keep native undo/copy/paste inside text fields
        if (key === 'z') {
          e.preventDefault();
          st.act({ type: e.shiftKey ? 'redo' : 'undo' });
        } else if (key === 'y') {
          e.preventDefault();
          st.act({ type: 'redo' });
        } else if (key === 'd') {
          e.preventDefault();
          st.duplicateSelected();
        } else if (key === 'a') {
          e.preventDefault();
          st.act({ type: 'select', ids: getActiveVariation(st.state).objects.filter((o) => o.visible).map((o) => o.id) });
        } else if (key === '0') {
          e.preventDefault();
          st.fit();
        } else if (key === '1') {
          e.preventDefault();
          st.setZoom(1);
        } else if (key === '=' || key === '+') {
          e.preventDefault();
          st.zoomAt(1.25);
        } else if (key === '-') {
          e.preventDefault();
          st.zoomAt(1 / 1.25);
        }
        return;
      }
      if (typing || e.altKey) return;

      const step = e.shiftKey ? 10 : 1;
      switch (e.key) {
        case 'Delete':
        case 'Backspace':
          if (st.state.selection.length) {
            e.preventDefault();
            st.deleteSelected();
          }
          return;
        case 'Escape':
          st.act({ type: 'select', ids: [] });
          return;
        case 'ArrowLeft':
        case 'ArrowRight':
        case 'ArrowUp':
        case 'ArrowDown':
          if (st.state.selection.length) {
            e.preventDefault();
            st.nudge(e.key === 'ArrowLeft' ? -step : e.key === 'ArrowRight' ? step : 0, e.key === 'ArrowUp' ? -step : e.key === 'ArrowDown' ? step : 0);
          }
          return;
        case '[':
        case ']': {
          const id = st.state.selection[0];
          if (id && st.state.selection.length === 1) st.act({ type: 'reorder', id, to: e.key === ']' ? 'up' : 'down' });
          return;
        }
        case '?':
          st.openDialog('help');
          return;
      }
      const letter = key;
      const add = { t: 'text', r: 'rect', c: 'circle', e: 'ellipse', l: 'line' } as const;
      if (letter in add) st.addObject(add[letter as keyof typeof add]);
      else if (letter === 'v') st.setTool('select');
      else if (letter === 'h') st.setTool('hand');
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  return null;
}
