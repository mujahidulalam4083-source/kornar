import { Download, FilePlus, CircleHelp, Moon, PanelLeft, PanelRight, Redo2, RotateCcw, Save, Sun, Undo2 } from 'lucide-react';
import { useStudio } from '../studio';
import { IconButton } from './ui/IconButton';

/** The golden "K" logo (public/kornar-mark.png, transparent background, shipped at native resolution). */
export function BrandMark() {
  return <img className="brand-mark" src="./kornar-mark.png" alt="" width={32} height={32} decoding="async" draggable={false} />;
}

export function TopBar() {
  const s = useStudio();
  const { project, act, state, dirty, saveError, prefs } = s;
  const chip = saveError ? { t: 'Save failed', c: 'error' } : dirty ? { t: prefs.autosave ? 'Saving...' : 'Unsaved', c: 'dirty' } : { t: 'Saved', c: 'saved' };

  return (
    <header className="topbar">
      <div className="topbar-left">
        <IconButton icon={<PanelLeft size={17} />} label="Toggle controls panel" active={s.leftOpen} onClick={() => s.togglePanel('left')} />
        <div className="brand" title="KORNAR">
          <BrandMark />
          <span className="brand-name">KORNAR</span>
        </div>
        <div className="title-wrap">
          <label htmlFor="project-name" className="sr-only">
            Project name
          </label>
          <input
            id="project-name"
            className="title-input"
            value={project.name}
            maxLength={80}
            spellCheck={false}
            onChange={(e) => act({ type: 'rename', name: e.target.value })}
            onBlur={(e) => !e.target.value.trim() && act({ type: 'rename', name: 'Untitled logo' })}
          />
          <span className={`save-chip save-${chip.c}`} role="status" title={saveError ?? undefined}>
            {chip.t}
          </span>
        </div>
      </div>

      <div className="topbar-actions">
        <IconButton icon={<Undo2 size={17} />} label="Undo" shortcut="Ctrl+Z" disabled={state.past.length === 0} onClick={() => act({ type: 'undo' })} />
        <IconButton icon={<Redo2 size={17} />} label="Redo" shortcut="Ctrl+Shift+Z" disabled={state.future.length === 0} onClick={() => act({ type: 'redo' })} />
        <span className="sep" />
        <IconButton icon={<FilePlus size={16} />} label="New project" text="New" className="hide-sm" onClick={() => s.openDialog('new')} />
        <IconButton icon={<Save size={16} />} label="Save project" shortcut="Ctrl+S" text="Save" className="hide-sm" onClick={() => s.saveNow(true)} />
        <IconButton icon={<RotateCcw size={16} />} label="Reset canvas" text="Reset" className="hide-sm" onClick={() => s.openDialog('reset')} />
        <button type="button" className="btn btn-primary" title="Export SVG or PNG (Ctrl+E)" onClick={() => s.openDialog('export')}>
          <Download size={16} /> Export
        </button>
        <span className="sep" />
        <IconButton icon={prefs.theme === 'dark' ? <Sun size={17} /> : <Moon size={17} />} label={prefs.theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme'} onClick={() => s.setPrefs({ theme: prefs.theme === 'dark' ? 'light' : 'dark' })} />
        <IconButton icon={<CircleHelp size={17} />} label="Help and keyboard shortcuts" shortcut="?" onClick={() => s.openDialog('help')} />
        <IconButton icon={<PanelRight size={17} />} label="Toggle layers and projects panel" active={s.rightOpen} onClick={() => s.togglePanel('right')} />
      </div>
    </header>
  );
}
