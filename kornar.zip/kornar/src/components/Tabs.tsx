import type { KeyboardEvent, ReactNode } from 'react';

interface Props<T extends string> {
  label: string;
  value: T;
  onChange: (v: T) => void;
  tabs: { id: T; label: string; icon: ReactNode }[];
  idPrefix: string;
}

/** Accessible tab list with arrow-key navigation. The matching panel must use id `${idPrefix}-panel`. */
export function Tabs<T extends string>({ label, value, onChange, tabs, idPrefix }: Props<T>) {
  const onKey = (e: KeyboardEvent<HTMLDivElement>) => {
    const i = tabs.findIndex((t) => t.id === value);
    let n = i;
    if (e.key === 'ArrowRight') n = (i + 1) % tabs.length;
    else if (e.key === 'ArrowLeft') n = (i - 1 + tabs.length) % tabs.length;
    else if (e.key === 'Home') n = 0;
    else if (e.key === 'End') n = tabs.length - 1;
    else return;
    e.preventDefault();
    onChange(tabs[n]!.id);
    (e.currentTarget.querySelectorAll('[role="tab"]')[n] as HTMLElement | undefined)?.focus();
  };
  return (
    <div className="tabs" role="tablist" aria-label={label} onKeyDown={onKey}>
      {tabs.map((t) => (
        <button key={t.id} id={`${idPrefix}-tab-${t.id}`} type="button" role="tab" aria-selected={t.id === value} aria-controls={`${idPrefix}-panel`} tabIndex={t.id === value ? 0 : -1} className={t.id === value ? 'is-active' : ''} onClick={() => onChange(t.id)} title={t.label}>
          {t.icon}
          <span>{t.label}</span>
        </button>
      ))}
    </div>
  );
}
