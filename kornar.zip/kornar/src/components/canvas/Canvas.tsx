import { useEffect, useMemo, useRef, useState, type MouseEvent as RMouseEvent, type PointerEvent as RPointerEvent } from 'react';
import { Hand, Maximize, MousePointer2, Redo2, Undo2, ZoomIn, ZoomOut } from 'lucide-react';
import { useStudio } from '../../studio';
import type { HandleId, LogoObject, ObjectPatch, ObjectType } from '../../types';
import { resolveBackground } from '../../lib/color';
import { angleFromPointer, centerOf, computeSnap, getAABB, getBounds, getFrame, r2, rectsIntersect, resizeObject, safeArea, selectionBounds, snapTargetsFor, type Guide, type Point, type Rect } from '../../lib/geometry';
import { Artwork } from './LogoSvg';
import { SelectionOverlay } from './SelectionOverlay';
import { IconButton } from '../ui/IconButton';
import { ObjectIcon, OBJECT_LABEL } from '../ui/Icons';

type Drag =
  | { kind: 'pan'; lastX: number; lastY: number }
  | { kind: 'move'; start: Point; originals: LogoObject[]; moved: boolean; key: string }
  | { kind: 'resize'; handle: HandleId; start: Point; original: LogoObject; key: string }
  | { kind: 'rotate'; original: LogoObject; key: string }
  | { kind: 'marquee'; start: Point; additive: boolean; base: string[] };

const ADD: ObjectType[] = ['text', 'rect', 'circle', 'ellipse', 'line'];

export function Canvas() {
  const s = useStudio();
  const { variation: v, state, act, view, stage, setStage, prefs, tool, setTool, selected, zoomAt, panBy } = s;
  const stageRef = useRef<HTMLDivElement>(null);
  const drag = useRef<Drag | null>(null);
  const [guides, setGuides] = useState<Guide[]>([]);
  const [marquee, setMarquee] = useState<Rect | null>(null);
  const [hoverId, setHoverId] = useState<string | null>(null);
  const [spaceDown, setSpaceDown] = useState(false);
  const [panning, setPanning] = useState(false);

  const z = view.zoom;
  const vw = stage.w / z;
  const vh = stage.h / z;
  const vx = view.cx - vw / 2;
  const vy = view.cy - vh / 2;

  // Track the stage size.
  useEffect(() => {
    const el = stageRef.current;
    if (!el) return;
    const measure = () => setStage({ w: Math.floor(el.clientWidth), h: Math.floor(el.clientHeight) });
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, [setStage]);

  // Wheel = zoom at the pointer (needs a non-passive listener to prevent page scroll).
  useEffect(() => {
    const el = stageRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const rect = el.getBoundingClientRect();
      if (e.shiftKey && !e.ctrlKey && !e.metaKey) {
        panBy(-(e.deltaX || e.deltaY), 0);
        return;
      }
      const unit = e.deltaMode === 1 ? 0.05 : e.deltaMode === 2 ? 0.5 : 0.0015;
      zoomAt(Math.exp(-e.deltaY * unit), { x: e.clientX - rect.left, y: e.clientY - rect.top });
    };
    el.addEventListener('wheel', onWheel, { passive: false });
    return () => el.removeEventListener('wheel', onWheel);
  }, [zoomAt, panBy]);

  // Space = temporary hand tool. Ignored inside text fields; when the pointer is over the canvas it also
  // wins over a focused toolbar button (otherwise Space would re-press that button instead of panning).
  const overStage = useRef(false);
  useEffect(() => {
    const isField = (t: EventTarget | null) => t instanceof HTMLElement && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName));
    const isButton = (t: EventTarget | null) => t instanceof HTMLElement && t.tagName === 'BUTTON';
    let consumed = false;
    const down = (e: KeyboardEvent) => {
      if (e.code !== 'Space' || isField(e.target) || (isButton(e.target) && !overStage.current)) return;
      e.preventDefault();
      consumed = true;
      setSpaceDown(true);
    };
    const up = (e: KeyboardEvent) => {
      if (e.code !== 'Space') return;
      if (consumed) e.preventDefault();
      consumed = false;
      setSpaceDown(false);
    };
    const blur = () => setSpaceDown(false);
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    window.addEventListener('blur', blur);
    return () => {
      window.removeEventListener('keydown', down);
      window.removeEventListener('keyup', up);
      window.removeEventListener('blur', blur);
    };
  }, []);

  const toCanvas = (e: { clientX: number; clientY: number }): Point => {
    const r = stageRef.current!.getBoundingClientRect();
    return { x: vx + (e.clientX - r.left) / z, y: vy + (e.clientY - r.top) / z };
  };

  const onPointerDown = (e: RPointerEvent<SVGSVGElement>) => {
    if (e.button === 2) return;
    const svg = e.currentTarget;
    const target = e.target as Element;
    const p = toCanvas(e);
    const key = `drag:${Date.now()}`;

    if (e.button === 1 || tool === 'hand' || spaceDown) {
      drag.current = { kind: 'pan', lastX: e.clientX, lastY: e.clientY };
      setPanning(true);
      svg.setPointerCapture(e.pointerId);
      e.preventDefault();
      return;
    }

    const handle = target.closest('[data-handle]')?.getAttribute('data-handle');
    if (handle && selected.length === 1 && !selected[0]!.locked) {
      drag.current = handle === 'rotate' ? { kind: 'rotate', original: selected[0]!, key } : { kind: 'resize', handle: handle as HandleId, start: p, original: selected[0]!, key };
      svg.setPointerCapture(e.pointerId);
      e.preventDefault();
      return;
    }

    const oid = target.closest('[data-oid]')?.getAttribute('data-oid');
    if (oid) {
      if (e.shiftKey || e.ctrlKey || e.metaKey) {
        act({ type: 'toggleSelect', id: oid });
        return;
      }
      let ids = state.selection;
      if (!ids.includes(oid)) {
        ids = [oid];
        act({ type: 'select', ids });
      }
      const originals = v.objects.filter((o) => ids.includes(o.id) && !o.locked);
      if (originals.length > 0) {
        drag.current = { kind: 'move', start: p, originals, moved: false, key };
        svg.setPointerCapture(e.pointerId);
      }
      e.preventDefault();
      return;
    }

    // Empty space: start a marquee selection.
    if (!e.shiftKey) act({ type: 'select', ids: [] });
    drag.current = { kind: 'marquee', start: p, additive: e.shiftKey, base: e.shiftKey ? state.selection : [] };
    setMarquee({ x: p.x, y: p.y, w: 0, h: 0 });
    svg.setPointerCapture(e.pointerId);
    e.preventDefault();
  };

  const onPointerMove = (e: RPointerEvent<SVGSVGElement>) => {
    const d = drag.current;
    if (!d) {
      const id = (e.target as Element).closest?.('[data-oid]')?.getAttribute('data-oid') ?? null;
      if (id !== hoverId) setHoverId(id);
      return;
    }
    const p = toCanvas(e);
    switch (d.kind) {
      case 'pan':
        panBy(e.clientX - d.lastX, e.clientY - d.lastY);
        d.lastX = e.clientX;
        d.lastY = e.clientY;
        break;

      case 'move': {
        let dx = p.x - d.start.x;
        let dy = p.y - d.start.y;
        if (!d.moved && Math.hypot(dx, dy) * z < 3) return;
        d.moved = true;
        if (e.shiftKey) {
          if (Math.abs(dx) > Math.abs(dy)) dy = 0;
          else dx = 0;
        }
        let out: Guide[] = [];
        if (prefs.snap && !e.altKey) {
          const b = selectionBounds(d.originals)!;
          const snap = computeSnap({ ...b, x: b.x + dx, y: b.y + dy }, snapTargetsFor(v, d.originals.map((o) => o.id), prefs.showGrid ? prefs.gridSize : undefined), 8 / z);
          dx += snap.dx;
          dy += snap.dy;
          out = snap.guides;
        }
        setGuides(out);
        const changes: Record<string, ObjectPatch> = {};
        for (const o of d.originals) changes[o.id] = { x: r2(o.x + dx), y: r2(o.y + dy) };
        act({ type: 'applyChanges', changes, coalesce: d.key, window: Infinity });
        break;
      }

      case 'resize': {
        const o = d.original;
        const keep = e.shiftKey || (o.type !== 'text' && o.type !== 'line' && o.lockAspect);
        act({ type: 'patchObjects', ids: [o.id], patch: resizeObject(o, d.handle, d.start, p, { keepAspect: keep, fromCenter: e.altKey }), coalesce: d.key, window: Infinity });
        break;
      }

      case 'rotate': {
        const c = centerOf(getBounds(d.original));
        act({ type: 'patchObjects', ids: [d.original.id], patch: { rotation: angleFromPointer(c, p, e.shiftKey) }, coalesce: d.key, window: Infinity });
        break;
      }

      case 'marquee': {
        const r: Rect = { x: Math.min(d.start.x, p.x), y: Math.min(d.start.y, p.y), w: Math.abs(p.x - d.start.x), h: Math.abs(p.y - d.start.y) };
        setMarquee(r);
        const hits = v.objects.filter((o) => o.visible && rectsIntersect(getAABB(o), r)).map((o) => o.id);
        act({ type: 'select', ids: d.additive ? [...new Set([...d.base, ...hits])] : hits });
        break;
      }
    }
  };

  const endDrag = (e: RPointerEvent<SVGSVGElement>) => {
    if (e.currentTarget.hasPointerCapture?.(e.pointerId)) e.currentTarget.releasePointerCapture(e.pointerId);
    drag.current = null;
    setGuides([]);
    setMarquee(null);
    setPanning(false);
  };

  const onDoubleClick = (e: RMouseEvent<SVGSVGElement>) => {
    const oid = (e.target as Element).closest('[data-oid]')?.getAttribute('data-oid');
    const o = oid ? v.objects.find((x) => x.id === oid) : null;
    if (o?.type === 'text') s.setLeftTab('type');
  };

  const hoverObj = hoverId ? v.objects.find((o) => o.id === hoverId && o.visible) ?? null : null;
  const bg = v.colors.transparentBackground ? 'url(#fm-checker)' : resolveBackground(v);
  const sa = safeArea(v);
  const chk = 10 / z;
  const cursor = panning ? 'grabbing' : tool === 'hand' || spaceDown ? 'grab' : 'default';
  const canUndo = state.past.length > 0;
  const canRedo = state.future.length > 0;

  const proxies = useMemo(
    () =>
      v.objects
        .filter((o) => o.visible)
        .map((o) => {
          const f = getFrame(o);
          const c = centerOf(f);
          const tf = o.rotation ? `rotate(${o.rotation} ${c.x} ${c.y})` : undefined;
          const common = { fill: 'transparent', style: { cursor: o.locked ? 'default' : 'move' } as const };
          if (o.type === 'line') {
            const t = Math.max(f.h, 14 / z);
            return (
              <g key={o.id} data-oid={o.id}>
                <rect x={f.x} y={c.y - t / 2} width={f.w} height={t} transform={tf} {...common} />
              </g>
            );
          }
          if (o.type === 'ellipse' || o.type === 'circle') {
            return (
              <g key={o.id} data-oid={o.id}>
                <ellipse cx={c.x} cy={c.y} rx={f.w / 2} ry={f.h / 2} transform={tf} {...common} />
              </g>
            );
          }
          return (
            <g key={o.id} data-oid={o.id}>
              <rect x={f.x} y={f.y} width={f.w} height={f.h} transform={tf} {...common} />
            </g>
          );
        }),
    [v.objects, z],
  );

  return (
    <div className="stage" ref={stageRef} data-cursor={cursor} onPointerEnter={() => (overStage.current = true)} onPointerLeave={() => (overStage.current = false)}>
      {stage.w > 0 ? (
        <svg
          className="stage-svg"
          width={stage.w}
          height={stage.h}
          viewBox={`${vx} ${vy} ${vw} ${vh}`}
          style={{ cursor }}
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={endDrag}
          onPointerCancel={endDrag}
          onPointerLeave={() => !drag.current && setHoverId(null)}
          onDoubleClick={onDoubleClick}
          onContextMenu={(e) => e.preventDefault()}
          role="application"
          aria-label={`Logo canvas, ${v.width} by ${v.height} pixels. ${v.objects.length} objects.`}
        >
          <defs>
            <pattern id="fm-checker" width={chk * 2} height={chk * 2} patternUnits="userSpaceOnUse">
              <rect width={chk * 2} height={chk * 2} style={{ fill: 'var(--checker-a)' }} />
              <rect width={chk} height={chk} style={{ fill: 'var(--checker-b)' }} />
              <rect x={chk} y={chk} width={chk} height={chk} style={{ fill: 'var(--checker-b)' }} />
            </pattern>
            <pattern id="fm-grid" width={prefs.gridSize} height={prefs.gridSize} patternUnits="userSpaceOnUse">
              <path d={`M ${prefs.gridSize} 0 L 0 0 0 ${prefs.gridSize}`} fill="none" style={{ stroke: 'var(--grid)' }} strokeWidth={1 / z} />
            </pattern>
            <clipPath id="fm-artboard-clip">
              <rect width={v.width} height={v.height} />
            </clipPath>
          </defs>

          <g className="artboard-shadow">
            <rect x={0} y={0} width={v.width} height={v.height} fill={bg} />
          </g>
          <g clipPath="url(#fm-artboard-clip)" pointerEvents="none">
            <Artwork variation={v} />
          </g>

          <g pointerEvents="none">
            {prefs.showGrid ? <rect width={v.width} height={v.height} fill="url(#fm-grid)" /> : null}
            <rect width={v.width} height={v.height} fill="none" style={{ stroke: 'var(--artboard-border)' }} strokeWidth={1 / z} />
            {prefs.showSafe && v.padding > 0 ? <rect x={sa.x} y={sa.y} width={sa.w} height={sa.h} fill="none" stroke="var(--guide-safe)" strokeWidth={1 / z} strokeDasharray={`${6 / z} ${4 / z}`} /> : null}
            {prefs.showCenter ? (
              <>
                <line x1={v.width / 2} y1={0} x2={v.width / 2} y2={v.height} stroke="var(--guide-center)" strokeWidth={1 / z} strokeDasharray={`${4 / z} ${4 / z}`} />
                <line x1={0} y1={v.height / 2} x2={v.width} y2={v.height / 2} stroke="var(--guide-center)" strokeWidth={1 / z} strokeDasharray={`${4 / z} ${4 / z}`} />
              </>
            ) : null}
          </g>

          <g>{proxies}</g>
          <SelectionOverlay selected={selected} hover={drag.current ? null : hoverObj} zoom={z} />

          <g pointerEvents="none">
            {guides.map((g, i) =>
              g.axis === 'x' ? <line key={i} x1={g.pos} y1={-40 / z} x2={g.pos} y2={v.height + 40 / z} stroke="var(--guide-snap)" strokeWidth={1 / z} /> : <line key={i} x1={-40 / z} y1={g.pos} x2={v.width + 40 / z} y2={g.pos} stroke="var(--guide-snap)" strokeWidth={1 / z} />,
            )}
            {marquee ? <rect x={marquee.x} y={marquee.y} width={marquee.w} height={marquee.h} fill="var(--accent-soft)" stroke="var(--accent)" strokeWidth={1 / z} /> : null}
          </g>
        </svg>
      ) : null}

      <div className="stage-toolbar" role="toolbar" aria-label="Canvas tools">
        <IconButton icon={<MousePointer2 size={16} />} label="Select tool" shortcut="V" active={tool === 'select'} onClick={() => setTool('select')} />
        <IconButton icon={<Hand size={16} />} label="Hand tool (pan)" shortcut="H" active={tool === 'hand'} onClick={() => setTool('hand')} />
        <span className="sep" />
        {ADD.map((t) => (
          <IconButton key={t} icon={<ObjectIcon type={t} size={16} />} label={`Add ${OBJECT_LABEL[t].toLowerCase()}`} onClick={() => s.addObject(t)} />
        ))}
        <span className="sep" />
        <IconButton icon={<Undo2 size={16} />} label="Undo" shortcut="Ctrl+Z" disabled={!canUndo} onClick={() => act({ type: 'undo' })} />
        <IconButton icon={<Redo2 size={16} />} label="Redo" shortcut="Ctrl+Shift+Z" disabled={!canRedo} onClick={() => act({ type: 'redo' })} />
      </div>

      <div className="zoom-controls" role="group" aria-label="Zoom">
        <IconButton icon={<ZoomOut size={16} />} label="Zoom out" shortcut="Ctrl+-" onClick={() => zoomAt(1 / 1.25)} />
        <button type="button" className="btn zoom-readout" title="Reset to 100%" aria-label={`Zoom ${Math.round(z * 100)} percent. Click to reset to 100 percent`} onClick={() => s.setZoom(1)}>
          {Math.round(z * 100)}%
        </button>
        <IconButton icon={<ZoomIn size={16} />} label="Zoom in" shortcut="Ctrl+=" onClick={() => zoomAt(1.25)} />
        <IconButton icon={<Maximize size={16} />} label="Fit canvas to window" shortcut="Ctrl+0" onClick={s.fit} />
      </div>

      {v.objects.length === 0 ? (
        <div className="stage-empty">
          <h3>Your canvas is empty</h3>
          <p>Add some text or a shape, or begin with a template.</p>
          <div className="btn-row">
            <button type="button" className="btn btn-primary" onClick={() => s.addObject('text')}>
              Add text
            </button>
            <button type="button" className="btn" onClick={() => s.addObject('rect')}>
              Add shape
            </button>
            <button type="button" className="btn" onClick={() => s.openDialog('new')}>
              Templates
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}
