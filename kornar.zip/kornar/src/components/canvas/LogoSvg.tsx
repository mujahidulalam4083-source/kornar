import type { ReactElement } from 'react';
import type { LogoObject, TextObject, Variation } from '../../types';
import { resolveBackground, resolveColor } from '../../lib/color';
import { fontStack } from '../../lib/fonts';
import { getBounds, centerOf } from '../../lib/geometry';
import { effectiveLetterSpacing, layoutText } from '../../lib/measure';

/**
 * The single source of truth for how a logo is drawn. The editor canvas, thumbnails, the SVG export
 * (via renderToStaticMarkup) and the PNG export all use these components, so they cannot drift apart.
 */

const n = (v: number): number => Math.round(v * 1000) / 1000;

type Ctx = Pick<Variation, 'colors' | 'colorMode'>;

function rotation(o: LogoObject): string | undefined {
  if (!o.rotation) return undefined;
  const c = centerOf(getBounds(o));
  return `rotate(${n(o.rotation)} ${n(c.x)} ${n(c.y)})`;
}

function paint(fillRef: string | null, strokeRef: string, strokeWidth: number, v: Ctx) {
  const fill = fillRef === null ? undefined : resolveColor(fillRef, v);
  const stroke = resolveColor(strokeRef, v);
  const hasStroke = stroke !== 'none' && strokeWidth > 0;
  return {
    fill,
    stroke: hasStroke ? stroke : undefined,
    strokeWidth: hasStroke ? n(strokeWidth) : undefined,
  };
}

function TextNode({ o, v }: { o: TextObject; v: Ctx }): ReactElement | null {
  const layout = layoutText(o);
  const rtl = o.direction === 'rtl';
  const ls = effectiveLetterSpacing(o);
  let ax = o.x;
  let anchor: 'start' | 'middle' | 'end' = 'start';
  if (o.align === 'center') {
    ax = o.x + layout.width / 2;
    anchor = 'middle';
  } else if (o.align === 'right') {
    ax = o.x + layout.width;
    anchor = rtl ? 'start' : 'end';
  } else {
    anchor = rtl ? 'end' : 'start';
  }
  const p = paint(o.fill, o.stroke, o.strokeWidth, v);
  const hasOutline = p.stroke !== undefined;
  return (
    <text
      fontFamily={fontStack(o.fontFamily)}
      fontSize={n(o.fontSize)}
      fontWeight={o.fontWeight}
      fontStyle={o.italic ? 'italic' : undefined}
      letterSpacing={ls ? n(ls) : undefined}
      textAnchor={anchor}
      direction={rtl ? 'rtl' : undefined}
      fill={p.fill}
      stroke={p.stroke}
      strokeWidth={p.strokeWidth}
      strokeLinejoin={hasOutline ? 'round' : undefined}
      paintOrder={hasOutline ? 'stroke fill' : undefined}
      opacity={o.opacity < 1 ? n(o.opacity) : undefined}
      transform={rotation(o)}
      xmlSpace="preserve"
    >
      {layout.lines.map((line, i) =>
        line === '' ? null : (
          <tspan key={i} x={n(ax)} y={n(o.y + layout.firstBaseline + i * layout.lineBox)}>
            {line}
          </tspan>
        ),
      )}
    </text>
  );
}

/** Draws one object. Returns null for hidden objects. */
export function ObjectNode({ obj: o, v }: { obj: LogoObject; v: Ctx }): ReactElement | null {
  if (!o.visible) return null;
  const common = { opacity: o.opacity < 1 ? n(o.opacity) : undefined, transform: rotation(o) };
  switch (o.type) {
    case 'text':
      return <TextNode o={o} v={v} />;
    case 'rect': {
      const p = paint(o.fill, o.stroke, o.strokeWidth, v);
      const r = Math.min(o.cornerRadius, o.width / 2, o.height / 2);
      return <rect x={n(o.x)} y={n(o.y)} width={n(o.width)} height={n(o.height)} rx={r > 0 ? n(r) : undefined} {...p} {...common} />;
    }
    case 'circle':
    case 'ellipse': {
      const p = paint(o.fill, o.stroke, o.strokeWidth, v);
      const cx = n(o.x + o.width / 2);
      const cy = n(o.y + o.height / 2);
      if (o.type === 'circle' && Math.abs(o.width - o.height) < 0.001) {
        return <circle cx={cx} cy={cy} r={n(o.width / 2)} {...p} {...common} />;
      }
      return <ellipse cx={cx} cy={cy} rx={n(o.width / 2)} ry={n(o.height / 2)} {...p} {...common} />;
    }
    case 'line': {
      const p = paint(null, o.stroke, o.strokeWidth, v);
      return <line x1={n(o.x)} y1={n(o.y)} x2={n(o.x + o.width)} y2={n(o.y)} strokeLinecap={o.lineCap === 'butt' ? undefined : o.lineCap} {...p} {...common} />;
    }
  }
}

export function Artwork({ variation }: { variation: Variation }): ReactElement {
  return (
    <>
      {variation.objects.map((o) => (
        <ObjectNode key={o.id} obj={o} v={variation} />
      ))}
    </>
  );
}

export interface ExportSvgProps {
  variation: Variation;
  width: number;
  height: number;
  includeBackground: boolean;
  title?: string;
}

/** A complete, standalone <svg> document element for export. viewBox always equals the design size. */
export function ExportSvg({ variation: v, width, height, includeBackground, title }: ExportSvgProps): ReactElement {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width={width} height={height} viewBox={`0 0 ${v.width} ${v.height}`}>
      {title ? <title>{title}</title> : null}
      {includeBackground ? <rect width={v.width} height={v.height} fill={resolveBackground(v)} /> : null}
      <Artwork variation={v} />
    </svg>
  );
}

/** Small non-interactive preview used for thumbnails (templates, variations). */
export function Thumbnail({ variation, className }: { variation: Variation; className?: string }): ReactElement {
  const bg = variation.colors.transparentBackground ? 'none' : resolveBackground(variation);
  return (
    <svg className={className} viewBox={`0 0 ${variation.width} ${variation.height}`} preserveAspectRatio="xMidYMid meet" role="img" aria-label={`${variation.name} preview`}>
      <rect width={variation.width} height={variation.height} fill={bg} />
      <Artwork variation={variation} />
    </svg>
  );
}
