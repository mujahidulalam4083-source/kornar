import type { HandleId, LogoObject } from '../../types';
import { centerOf, cursorForHandle, getAABB, getFrame, selectionBounds } from '../../lib/geometry';
import { round } from '../../lib/util';

const CORNERS: HandleId[] = ['nw', 'ne', 'se', 'sw'];
const ALL: HandleId[] = ['nw', 'n', 'ne', 'e', 'se', 's', 'sw', 'w'];

function handlePos(f: { x: number; y: number; w: number; h: number }, h: HandleId) {
  const x = h.includes('w') ? f.x : h.includes('e') ? f.x + f.w : f.x + f.w / 2;
  const y = h.includes('n') ? f.y : h.includes('s') ? f.y + f.h : f.y + f.h / 2;
  return { x, y };
}

interface Props {
  selected: LogoObject[];
  hover: LogoObject | null;
  zoom: number;
}

/** Editor-only chrome (never exported): outlines, resize/rotate handles and a size read-out. */
export function SelectionOverlay({ selected, hover, zoom }: Props) {
  const px = 1 / zoom;
  const hs = 9 * px;
  const outline = { fill: 'none', stroke: 'var(--accent)', strokeWidth: 1.5 * px, vectorEffect: 'non-scaling-stroke' as const };

  const hoverNode =
    hover && !selected.some((o) => o.id === hover.id) ? (
      (() => {
        const f = getFrame(hover);
        const c = centerOf(f);
        return <rect x={f.x} y={f.y} width={f.w} height={f.h} transform={hover.rotation ? `rotate(${hover.rotation} ${c.x} ${c.y})` : undefined} fill="none" stroke="var(--accent)" strokeOpacity={0.55} strokeWidth={1.25 * px} />;
      })()
    ) : null;

  if (selected.length === 0) return <g pointerEvents="none">{hoverNode}</g>;

  if (selected.length > 1) {
    const b = selectionBounds(selected)!;
    return (
      <g pointerEvents="none">
        {hoverNode}
        {selected.map((o) => {
          const f = getFrame(o);
          const c = centerOf(f);
          return <rect key={o.id} x={f.x} y={f.y} width={f.w} height={f.h} transform={o.rotation ? `rotate(${o.rotation} ${c.x} ${c.y})` : undefined} {...outline} strokeOpacity={0.6} strokeWidth={1 * px} />;
        })}
        <rect x={b.x} y={b.y} width={b.w} height={b.h} {...outline} strokeDasharray={`${5 * px} ${4 * px}`} />
      </g>
    );
  }

  const o = selected[0]!;
  const f = getFrame(o);
  const c = centerOf(f);
  const aabb = getAABB(o);
  const handles = o.locked ? [] : o.type === 'line' ? (['w', 'e'] as HandleId[]) : o.type === 'text' ? CORNERS : ALL;
  const label = o.type === 'line' ? `${round(o.width)} px` : o.type === 'text' ? `${round(f.w)} x ${round(f.h)}` : `${round(f.w)} x ${round(f.h)}`;
  const stem = 26 * px;

  return (
    <g>
      {hoverNode ? <g pointerEvents="none">{hoverNode}</g> : null}
      <g transform={o.rotation ? `rotate(${o.rotation} ${c.x} ${c.y})` : undefined}>
        <rect x={f.x} y={f.y} width={f.w} height={f.h} pointerEvents="none" {...outline} strokeDasharray={o.locked ? `${4 * px} ${3 * px}` : undefined} />
        {!o.locked ? (
          <>
            <line x1={c.x} y1={f.y} x2={c.x} y2={f.y - stem} stroke="var(--accent)" strokeWidth={1 * px} pointerEvents="none" />
            <circle data-handle="rotate" cx={c.x} cy={f.y - stem} r={5.5 * px} fill="var(--handle-fill)" stroke="var(--accent)" strokeWidth={1.5 * px} style={{ cursor: 'grab' }}>
              <title>Rotate (hold Shift for 15 degree steps)</title>
            </circle>
          </>
        ) : null}
        {handles.map((h) => {
          const p = handlePos(f, h);
          return <rect key={h} data-handle={h} x={p.x - hs / 2} y={p.y - hs / 2} width={hs} height={hs} rx={1.5 * px} fill="var(--handle-fill)" stroke="var(--accent)" strokeWidth={1.5 * px} style={{ cursor: cursorForHandle(h, o.rotation) }} />;
        })}
      </g>
      <g pointerEvents="none">
        <rect x={aabb.x + aabb.w / 2 - 36 * px} y={aabb.y + aabb.h + 10 * px} width={72 * px} height={18 * px} rx={4 * px} fill="var(--accent)" />
        <text x={aabb.x + aabb.w / 2} y={aabb.y + aabb.h + 23 * px} fontSize={11 * px} textAnchor="middle" fill="#fff" fontFamily="system-ui, sans-serif">
          {o.locked ? 'Locked' : label}
        </text>
      </g>
    </g>
  );
}
