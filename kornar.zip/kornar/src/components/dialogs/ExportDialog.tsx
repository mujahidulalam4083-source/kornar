import { useMemo, useState } from 'react';
import { Copy, Download, LoaderCircle } from 'lucide-react';
import { useStudio } from '../../studio';
import { Modal } from '../ui/Modal';
import { Hint, NumberField, Segmented, TextField, Toggle } from '../ui/Fields';
import { buildSvg, defaultFilename, downloadBlob, renderPng, safeFilename, validateExportSize } from '../../lib/exporter';
import { isFontAvailable } from '../../lib/fonts';
import { formatBytes } from '../../lib/util';
import { LIMITS } from '../../lib/model';

type Format = 'svg' | 'png';

export function ExportDialog() {
  const { variation, project, openDialog, toast, setLastExport } = useStudio();
  const [format, setFormat] = useState<Format>('svg');
  const [width, setWidth] = useState(variation.width);
  const [includeBg, setIncludeBg] = useState(!variation.colors.transparentBackground);
  const [customName, setCustomName] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<{ kind: 'success' | 'error'; text: string } | null>(null);

  const ratio = variation.height / variation.width;
  const height = Math.max(1, Math.round(width * ratio));
  const sizeError = validateExportSize(width, height);
  const autoName = defaultFilename(project.name, variation, format, width, height).replace(/\.(svg|png)$/, '');
  const filename = safeFilename(customName ?? autoName, format);

  const fontsUsed = useMemo(() => {
    const fams = new Set<string>();
    for (const o of variation.objects) if (o.type === 'text' && o.visible) fams.add(o.fontFamily);
    return [...fams].map((f) => ({ family: f, ok: isFontAvailable(f) }));
  }, [variation]);
  const missing = fontsUsed.filter((f) => !f.ok);

  const pickFormat = (f: Format) => {
    setFormat(f);
    setWidth(f === 'png' ? Math.min(variation.width * 2, LIMITS.maxExport) : variation.width);
    setStatus(null);
  };

  const opts = { width, height, includeBackground: includeBg, title: `${project.name} - ${variation.name}` };

  const run = async () => {
    if (sizeError) {
      setStatus({ kind: 'error', text: sizeError });
      return;
    }
    setBusy(true);
    setStatus(null);
    try {
      const blob = format === 'svg' ? new Blob([buildSvg(variation, opts)], { type: 'image/svg+xml;charset=utf-8' }) : await renderPng(variation, opts);
      downloadBlob(blob, filename);
      const summary = `${filename} (${formatBytes(blob.size)}${format === 'png' ? `, ${width}x${height}px` : ''})`;
      setLastExport(summary);
      setStatus({ kind: 'success', text: `Download started: ${summary}. Look in your browser's Downloads folder.` });
      toast('success', `Export ready: ${summary}`);
    } catch (e) {
      const text = e instanceof Error ? e.message : 'Export failed.';
      setStatus({ kind: 'error', text });
      toast('error', `Export failed: ${text}`);
    } finally {
      setBusy(false);
    }
  };

  const copySvg = async () => {
    try {
      await navigator.clipboard.writeText(buildSvg(variation, opts));
      setStatus({ kind: 'success', text: 'SVG code copied to the clipboard.' });
    } catch {
      setStatus({ kind: 'error', text: 'The browser blocked clipboard access. Use the Export button instead.' });
    }
  };

  return (
    <Modal
      wide
      title={`Export "${variation.name}"`}
      onClose={() => openDialog(null)}
      footer={
        <>
          <button type="button" className="btn" onClick={() => openDialog(null)}>
            Close
          </button>
          {format === 'svg' ? (
            <button type="button" className="btn" onClick={copySvg} disabled={busy}>
              <Copy size={14} /> Copy SVG code
            </button>
          ) : null}
          <button type="button" className="btn btn-primary" onClick={run} disabled={busy || !!sizeError}>
            {busy ? <LoaderCircle size={14} className="spin" /> : <Download size={14} />} {busy ? 'Rendering...' : `Export ${format.toUpperCase()}`}
          </button>
        </>
      }
    >
      <div className="export-grid">
        <div>
          <Segmented<Format> label="Format" value={format} onChange={pickFormat} options={[{ value: 'svg', label: 'SVG (vector)', title: 'SVG vector file' }, { value: 'png', label: 'PNG (image)', title: 'PNG raster image' }]} />
          <div className="two-col">
            <NumberField label="Width (px)" value={width} min={16} max={LIMITS.maxExport} step={format === 'png' ? 100 : 10} precision={0} onChange={(v) => setWidth(Math.round(v))} />
            <div className="field">
              <div className="field-head">
                <span className="label-like">Height (px)</span>
              </div>
              <div className="readout" aria-live="polite">{height}</div>
            </div>
          </div>
          <div className="chips" role="group" aria-label="Scale presets">
            {[1, 2, 3, 4].map((m) => (
              <button key={m} type="button" className={`chip${width === Math.round(variation.width * m) ? ' is-active' : ''}`} onClick={() => setWidth(Math.min(LIMITS.maxExport, Math.round(variation.width * m)))}>
                {m}x
              </button>
            ))}
          </div>
          <Hint>Height follows the canvas proportions ({variation.width} x {variation.height}) so nothing is cropped or letterboxed. Change the canvas size in the Layout tab for a different shape.</Hint>
          {sizeError ? <Hint tone="error">{sizeError}</Hint> : null}
          <Toggle label="Include background" checked={includeBg} onChange={setIncludeBg} hint={includeBg ? 'Background colour is painted behind the logo.' : 'Transparent background (alpha channel preserved).'} />
          <TextField label="File name" value={customName ?? autoName} onChange={setCustomName} maxLength={100} hint={<>Saved as <code>{filename}</code></>} />
        </div>
        <div className="export-notes">
          {format === 'svg' ? (
            <>
              <h4>About SVG text</h4>
              <p>
                Text stays live and editable in the SVG. If someone opens the file on a computer without the same font, their viewer will substitute another font and spacing may change. For artwork that must look identical everywhere, export PNG, or open the SVG in Inkscape / Illustrator and convert the text to outlines (Inkscape: <em>Path &rarr; Object to Path</em>, Illustrator: <em>Type &rarr; Create Outlines</em>).
              </p>
              <p>KORNAR does not convert text to outlines itself. Exporting never changes your project.</p>
            </>
          ) : (
            <>
              <h4>About PNG</h4>
              <p>The PNG is rendered from your design alone (not a screenshot of the app) using the fonts installed on this computer, so it matches the canvas exactly. {includeBg ? '' : 'Transparent areas are preserved.'}</p>
              <p>Maximum size is {LIMITS.maxExport} x {LIMITS.maxExport} px.</p>
            </>
          )}
          {fontsUsed.length > 0 ? (
            <>
              <h4>Fonts in this design</h4>
              <ul className="font-list">
                {fontsUsed.map((f) => (
                  <li key={f.family} className={f.ok ? '' : 'text-warn'}>
                    {f.family} - {f.ok ? 'installed' : 'not installed here (a fallback font is used)'}
                  </li>
                ))}
              </ul>
              {missing.length > 0 ? <Hint tone="warn">The export will use fallback fonts for the ones above, exactly as the canvas does.</Hint> : null}
            </>
          ) : null}
        </div>
      </div>
      {status ? (
        <div className={`status-box status-${status.kind}`} role={status.kind === 'error' ? 'alert' : 'status'}>
          {status.text}
        </div>
      ) : null}
    </Modal>
  );
}
