import { useMemo, useState } from 'react';
import { useStudio } from '../../studio';
import { Modal } from '../ui/Modal';
import { TEMPLATES } from '../../lib/templates';
import { Thumbnail } from '../canvas/LogoSvg';
import { TextField } from '../ui/Fields';
import { FilePlus } from 'lucide-react';
import { createBlankProject } from '../../lib/model';

const blank = createBlankProject().variations[0]!;

export function NewProjectDialog() {
  const { openDialog, newProject } = useStudio();
  const [name, setName] = useState('');
  const [choice, setChoice] = useState('minimal-wordmark');
  const close = () => openDialog(null);
  const thumbs = useMemo(() => TEMPLATES.map((t) => t.build().variations[0]!), []);

  return (
    <Modal
      wide
      title="New project"
      onClose={close}
      footer={
        <>
          <button type="button" className="btn" onClick={close}>
            Cancel
          </button>
          <button
            type="button"
            className="btn btn-primary"
            onClick={() => {
              close();
              newProject(choice, name.trim() || undefined);
            }}
          >
            Create project
          </button>
        </>
      }
    >
      <TextField label="Project name (optional)" value={name} onChange={setName} maxLength={80} placeholder="Untitled logo" />
      <p className="modal-text">Pick a starting point. Every template is built from editable text and shapes, not images.</p>
      <div className="template-grid" role="radiogroup" aria-label="Starting point">
        <button type="button" role="radio" aria-checked={choice === 'blank'} className={`template-card${choice === 'blank' ? ' is-active' : ''}`} onClick={() => setChoice('blank')}>
          <div className="template-thumb template-blank">
            <FilePlus size={28} />
          </div>
          <strong>Blank canvas</strong>
          <small>Start from scratch</small>
          <span className="sr-only">{blank.width} by {blank.height}</span>
        </button>
        {TEMPLATES.map((t, i) => (
          <button key={t.id} type="button" role="radio" aria-checked={choice === t.id} className={`template-card${choice === t.id ? ' is-active' : ''}`} onClick={() => setChoice(t.id)}>
            <div className="template-thumb">
              <Thumbnail variation={thumbs[i]!} />
            </div>
            <strong>{t.name}</strong>
            <small>{t.description}</small>
          </button>
        ))}
      </div>
    </Modal>
  );
}
