import { useStudio } from '../../studio';
import { Modal } from '../ui/Modal';
import { TEMPLATES } from '../../lib/templates';

export function ResetDialog() {
  const { openDialog, resetCanvas, variation, project } = useStudio();
  const tpl = TEMPLATES.find((t) => t.id === project.templateId);
  const close = () => openDialog(null);
  return (
    <Modal
      title="Reset canvas"
      onClose={close}
      initialFocus="[data-autofocus]"
      footer={
        <>
          <button type="button" className="btn" data-autofocus onClick={close}>
            Cancel
          </button>
          {tpl ? (
            <button
              type="button"
              className="btn"
              onClick={() => {
                close();
                resetCanvas('template');
              }}
            >
              Restore "{tpl.name}"
            </button>
          ) : null}
          <button
            type="button"
            className="btn btn-danger"
            onClick={() => {
              close();
              resetCanvas('clear');
            }}
          >
            Clear canvas
          </button>
        </>
      }
    >
      <p className="modal-text">
        This only affects the <strong>{variation.name}</strong> variation; your other variations are untouched. You can undo it afterwards with Ctrl+Z.
      </p>
      <ul className="plain-list">
        {tpl ? (
          <li>
            <strong>Restore starter design</strong> replaces this variation with the original "{tpl.name}" artwork and colours.
          </li>
        ) : null}
        <li>
          <strong>Clear canvas</strong> removes every object and resets the canvas size and colours to the defaults.
        </li>
      </ul>
    </Modal>
  );
}
