import { useState } from 'react';
import { useStudio } from '../../studio';
import { Modal } from '../ui/Modal';
import { Download, Layers, MousePointer2, Palette } from 'lucide-react';

const STEPS = [
  { icon: <Palette size={28} />, title: 'Welcome to KORNAR', body: 'Design flexible logos with live text and vector shapes. A starter design is already on the canvas - change anything, or use New to pick another template or a blank canvas.' },
  { icon: <MousePointer2 size={28} />, title: 'Edit directly on the canvas', body: 'Click to select, drag to move, use the handles to resize and the round handle to rotate. Shift-click or drag a box to select several objects. Scroll to zoom, hold Space and drag (or use the hand tool) to pan.' },
  { icon: <Layers size={28} />, title: 'Panels do the fine tuning', body: 'The left panel holds Design, Type, Color and Layout controls. The right panel manages layers, logo variations (horizontal, stacked, icon-only, dark...) and your saved projects. Every control has a reset button and every change can be undone with Ctrl+Z.' },
  { icon: <Download size={28} />, title: 'Save and export', body: 'Projects autosave in this browser (and you can export them as JSON to keep or share). Use Export for SVG or high-resolution PNG, with or without a background. Press ? any time for keyboard shortcuts.' },
];

export function OnboardingDialog() {
  const { openDialog, setPrefs } = useStudio();
  const [i, setI] = useState(0);
  const step = STEPS[i]!;
  const finish = () => {
    setPrefs({ onboardingSeen: true });
    openDialog(null);
  };
  return (
    <Modal
      title="Quick tour"
      onClose={finish}
      footer={
        <>
          <button type="button" className="btn" onClick={finish}>
            Skip
          </button>
          <span className="spacer" />
          <span className="step-dots" aria-label={`Step ${i + 1} of ${STEPS.length}`}>
            {STEPS.map((_, n) => (
              <span key={n} className={n === i ? 'is-active' : ''} />
            ))}
          </span>
          <button type="button" className="btn" disabled={i === 0} onClick={() => setI(i - 1)}>
            Back
          </button>
          {i < STEPS.length - 1 ? (
            <button type="button" className="btn btn-primary" onClick={() => setI(i + 1)}>
              Next
            </button>
          ) : (
            <button type="button" className="btn btn-primary" onClick={finish}>
              Start designing
            </button>
          )}
        </>
      }
    >
      <div className="tour">
        <div className="tour-icon">{step.icon}</div>
        <h3>{step.title}</h3>
        <p>{step.body}</p>
      </div>
    </Modal>
  );
}
