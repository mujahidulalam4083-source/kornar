import { useStudio } from '../../studio';
import { Modal } from '../ui/Modal';

const ROWS: [string, string][] = [
  ['Ctrl + Z', 'Undo'],
  ['Ctrl + Shift + Z  /  Ctrl + Y', 'Redo'],
  ['Ctrl + S', 'Save project in this browser'],
  ['Ctrl + E', 'Export'],
  ['Ctrl + D', 'Duplicate selection'],
  ['Ctrl + A', 'Select all'],
  ['Delete / Backspace', 'Delete selection'],
  ['Arrow keys (Shift = 10 px)', 'Nudge selection'],
  ['T  R  C  E  L', 'Add text, rectangle, circle, ellipse, line'],
  ['V  /  H', 'Select tool / hand tool'],
  ['Space + drag', 'Pan the canvas'],
  ['Mouse wheel', 'Zoom at the pointer'],
  ['Ctrl + 0  /  Ctrl + 1', 'Fit canvas / 100% zoom'],
  ['Ctrl + =  /  Ctrl + -', 'Zoom in / out'],
  [']  /  [', 'Bring forward / send backward'],
  ['Shift while dragging', 'Constrain move axis, keep proportions, snap rotation to 15 degrees'],
  ['Alt while dragging', 'Temporarily disable snapping (resize: scale from centre)'],
  ['Esc', 'Deselect'],
  ['?', 'Show this help'],
];

export function HelpDialog() {
  const { openDialog } = useStudio();
  return (
    <Modal
      title="Keyboard shortcuts"
      onClose={() => openDialog(null)}
      footer={
        <>
          <button type="button" className="btn" onClick={() => openDialog('onboarding')}>
            Replay quick tour
          </button>
          <span className="spacer" />
          <button type="button" className="btn btn-primary" onClick={() => openDialog(null)}>
            Done
          </button>
        </>
      }
    >
      <table className="shortcuts">
        <tbody>
          {ROWS.map(([k, d]) => (
            <tr key={k}>
              <th scope="row">
                <kbd>{k}</kbd>
              </th>
              <td>{d}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="hint">Shortcuts are ignored while you are typing in a text box.</p>
    </Modal>
  );
}
