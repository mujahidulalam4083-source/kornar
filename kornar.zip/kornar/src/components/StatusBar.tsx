import { useStudio } from '../studio';
import { formatTime } from '../lib/util';

export function StatusBar() {
  const { variation: v, view, selected, dirty, saveError, lastSavedAt, lastExport, prefs, project } = useStudio();
  const sel = selected.length === 0 ? 'No selection' : selected.length === 1 ? `Selected: ${selected[0]!.name}` : `${selected.length} objects selected`;
  const save = saveError ? 'Not saved' : dirty ? (prefs.autosave ? 'Saving...' : 'Unsaved changes') : lastSavedAt ? `Saved ${formatTime(lastSavedAt)}` : 'Saved';
  return (
    <footer className="statusbar">
      <span title="Canvas size">{v.width} x {v.height} px</span>
      <span title="Zoom level">{Math.round(view.zoom * 100)}%</span>
      <span className="status-sel">{sel}</span>
      <span className="spacer" />
      <span className="status-variation" title="Active variation">{project.name} / {v.name}</span>
      <span className={saveError ? 'text-error' : ''}>{save}</span>
      <span title="Most recent export" className="status-export">{lastExport ? `Exported: ${lastExport}` : 'No exports yet'}</span>
    </footer>
  );
}
