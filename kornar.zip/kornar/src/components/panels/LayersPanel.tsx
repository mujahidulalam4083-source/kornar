import { ChevronDown, ChevronUp, Copy, Eye, EyeOff, Lock, Trash2, Unlock } from 'lucide-react';
import { useStudio } from '../../studio';
import { ObjectIcon } from '../ui/Icons';
import { IconButton } from '../ui/IconButton';
import { AddObjects } from './DesignTab';

export function LayersPanel() {
  const { variation, state, act, openDialog } = useStudio();
  const list = [...variation.objects].reverse();

  if (list.length === 0) {
    return (
      <>
        <div className="empty-state">
          <p>
            <strong>No layers yet</strong>
          </p>
          <p>Add text or a shape to begin, or start from a template.</p>
          <button type="button" className="btn" onClick={() => openDialog('new')}>
            Browse templates
          </button>
        </div>
        <AddObjects />
      </>
    );
  }

  return (
    <ul className="layers" aria-label="Layers (top of the list is the front)">
      {list.map((o, idx) => {
        const selected = state.selection.includes(o.id);
        const atTop = idx === 0;
        const atBottom = idx === list.length - 1;
        return (
          <li key={o.id} className={`layer${selected ? ' is-selected' : ''}${o.visible ? '' : ' is-hidden'}`}>
            <button
              type="button"
              className="layer-main"
              aria-pressed={selected}
              onClick={(e) => (e.shiftKey || e.ctrlKey || e.metaKey ? act({ type: 'toggleSelect', id: o.id }) : act({ type: 'select', ids: [o.id] }))}
              title={`${o.name} - click to select, Shift-click to add to the selection`}
            >
              <ObjectIcon type={o.type} size={14} />
              <span className="layer-name">{o.name}</span>
            </button>
            <div className="layer-actions">
              <IconButton icon={o.visible ? <Eye size={14} /> : <EyeOff size={14} />} label={o.visible ? `Hide ${o.name}` : `Show ${o.name}`} onClick={() => act({ type: 'patchObjects', ids: [o.id], patch: { visible: !o.visible } })} />
              <IconButton icon={o.locked ? <Lock size={14} /> : <Unlock size={14} />} label={o.locked ? `Unlock ${o.name}` : `Lock ${o.name}`} active={o.locked} onClick={() => act({ type: 'patchObjects', ids: [o.id], patch: { locked: !o.locked } })} />
              <IconButton icon={<ChevronUp size={14} />} label={`Bring ${o.name} forward`} disabled={atTop} onClick={() => act({ type: 'reorder', id: o.id, to: 'up' })} />
              <IconButton icon={<ChevronDown size={14} />} label={`Send ${o.name} backward`} disabled={atBottom} onClick={() => act({ type: 'reorder', id: o.id, to: 'down' })} />
              <IconButton icon={<Copy size={14} />} label={`Duplicate ${o.name}`} onClick={() => act({ type: 'duplicateObjects', ids: [o.id] })} />
              <IconButton icon={<Trash2 size={14} />} label={`Delete ${o.name}`} danger disabled={o.locked} onClick={() => act({ type: 'deleteObjects', ids: [o.id] })} />
            </div>
          </li>
        );
      })}
    </ul>
  );
}
