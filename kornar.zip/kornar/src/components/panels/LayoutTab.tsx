import { useState } from 'react';
import { AlignCenterHorizontal, AlignCenterVertical, AlignEndHorizontal, AlignEndVertical, AlignHorizontalSpaceBetween, AlignStartHorizontal, AlignStartVertical, AlignVerticalSpaceBetween, RotateCw } from 'lucide-react';
import { useStudio } from '../../studio';
import { Hint, NumberField, Section, Segmented, Toggle } from '../ui/Fields';
import { IconButton } from '../ui/IconButton';
import { ASPECT_PRESETS, LIMITS } from '../../lib/model';
import { alignChanges, distributeChanges, fitObjects, safeArea, selectionBounds, translateObjects, type AlignMode } from '../../lib/geometry';
import { clamp } from '../../lib/util';

type Target = 'auto' | 'canvas' | 'safe' | 'selection';

export function LayoutTab() {
  const { variation: v, selected, act, prefs, setPrefs, toast } = useStudio();
  const [target, setTarget] = useState<Target>('auto');
  const [gap, setGap] = useState(24);
  const movable = selected.filter((o) => !o.locked);
  const effective: Exclude<Target, 'auto'> = target === 'auto' ? (selected.length > 1 ? 'selection' : 'canvas') : target;

  const area = () => {
    if (effective === 'canvas') return { x: 0, y: 0, w: v.width, h: v.height };
    if (effective === 'safe') return safeArea(v);
    return selectionBounds(movable)!;
  };
  const align = (mode: AlignMode) => {
    if (movable.length === 0) return;
    act({ type: 'applyChanges', changes: alignChanges(movable, mode, area()) });
  };
  const distribute = (axis: 'h' | 'v', g?: number) => {
    if (movable.length < (g === undefined ? 3 : 2)) return;
    act({ type: 'applyChanges', changes: distributeChanges(movable, axis, g) });
  };

  const setSize = (width: number, height: number, key: string) => act({ type: 'setCanvas', width, height, recenter: true, coalesce: `canvas:${key}` });
  const applyRatio = (ratio: number) => {
    let w = v.width;
    let h = Math.round(w / ratio);
    if (h > LIMITS.maxCanvas) {
      h = LIMITS.maxCanvas;
      w = Math.round(h * ratio);
    }
    setSize(clamp(w, LIMITS.minCanvas, LIMITS.maxCanvas), clamp(h, LIMITS.minCanvas, LIMITS.maxCanvas), 'ratio');
  };
  const currentRatio = ASPECT_PRESETS.find((p) => Math.abs(v.width / v.height - p.ratio) < 0.005)?.id;

  const content = v.objects.filter((o) => o.visible);
  const fitContent = () => {
    if (content.length === 0) return toast('info', 'There is nothing to fit yet.');
    const fitted = new Map(fitObjects(content, safeArea(v)).map((o) => [o.id, o]));
    act({ type: 'replaceObjects', objects: v.objects.map((o) => fitted.get(o.id) ?? o) });
  };
  const centerContent = () => {
    const b = selectionBounds(content);
    if (!b) return toast('info', 'There is nothing to centre yet.');
    const dx = v.width / 2 - (b.x + b.w / 2);
    const dy = v.height / 2 - (b.y + b.h / 2);
    const moved = new Map(translateObjects(content, dx, dy).map((o) => [o.id, o]));
    act({ type: 'replaceObjects', objects: v.objects.map((o) => moved.get(o.id) ?? o) });
  };

  return (
    <>
      <Section title="Canvas size">
        <div className="two-col">
          <NumberField label="Width" value={v.width} min={LIMITS.minCanvas} max={LIMITS.maxCanvas} precision={0} unit="px" defaultValue={1200} onChange={(w) => setSize(w, v.height, 'w')} />
          <NumberField label="Height" value={v.height} min={LIMITS.minCanvas} max={LIMITS.maxCanvas} precision={0} unit="px" defaultValue={800} onChange={(h) => setSize(v.width, h, 'h')} />
        </div>
        <div className="chips" role="group" aria-label="Aspect ratio presets">
          {ASPECT_PRESETS.map((p) => (
            <button key={p.id} type="button" className={`chip${currentRatio === p.id ? ' is-active' : ''}`} aria-pressed={currentRatio === p.id} title={`Set ${p.label} (keeps the width)`} onClick={() => applyRatio(p.ratio)}>
              {p.label}
            </button>
          ))}
          <IconButton icon={<RotateCw size={14} />} label="Swap width and height" onClick={() => setSize(v.height, v.width, 'swap')} />
        </div>
        <Hint>Your artwork stays centred when the canvas size changes.</Hint>
      </Section>

      <Section title="Safe area & content">
        <NumberField label="Padding (safe area)" value={v.padding} min={0} max={Math.max(0, Math.min(v.width, v.height) / 2 - 8)} precision={0} unit="px" slider sliderMax={Math.max(10, Math.round(Math.min(v.width, v.height) / 4))} defaultValue={60} onChange={(p) => act({ type: 'setCanvas', padding: p, coalesce: 'padding' })} />
        <div className="btn-row">
          <button type="button" className="btn" onClick={fitContent}>
            Fit content to safe area
          </button>
          <button type="button" className="btn" onClick={centerContent}>
            Centre content
          </button>
        </div>
      </Section>

      <Section title="Align & distribute">
        <Segmented<Target>
          label="Align relative to"
          value={target}
          onChange={setTarget}
          options={[
            { value: 'auto', label: 'Auto', title: 'Canvas for one object, the selection for several' },
            { value: 'canvas', label: 'Canvas' },
            { value: 'safe', label: 'Safe area' },
            { value: 'selection', label: 'Selection' },
          ]}
        />
        <div className="icon-row" role="toolbar" aria-label="Align">
          <IconButton icon={<AlignStartVertical size={16} />} label="Align left" disabled={movable.length === 0} onClick={() => align('left')} />
          <IconButton icon={<AlignCenterVertical size={16} />} label="Align horizontal centres" disabled={movable.length === 0} onClick={() => align('hcenter')} />
          <IconButton icon={<AlignEndVertical size={16} />} label="Align right" disabled={movable.length === 0} onClick={() => align('right')} />
          <span className="sep" />
          <IconButton icon={<AlignStartHorizontal size={16} />} label="Align top" disabled={movable.length === 0} onClick={() => align('top')} />
          <IconButton icon={<AlignCenterHorizontal size={16} />} label="Align vertical centres" disabled={movable.length === 0} onClick={() => align('vcenter')} />
          <IconButton icon={<AlignEndHorizontal size={16} />} label="Align bottom" disabled={movable.length === 0} onClick={() => align('bottom')} />
        </div>
        <div className="icon-row" role="toolbar" aria-label="Distribute">
          <IconButton icon={<AlignHorizontalSpaceBetween size={16} />} label="Distribute horizontally (3+ objects)" disabled={movable.length < 3} onClick={() => distribute('h')} />
          <IconButton icon={<AlignVerticalSpaceBetween size={16} />} label="Distribute vertically (3+ objects)" disabled={movable.length < 3} onClick={() => distribute('v')} />
        </div>
        <NumberField label="Exact spacing" value={gap} min={-5000} max={5000} unit="px" onChange={setGap} />
        <div className="btn-row">
          <button type="button" className="btn" disabled={movable.length < 2} onClick={() => distribute('h', gap)}>
            Space horizontally
          </button>
          <button type="button" className="btn" disabled={movable.length < 2} onClick={() => distribute('v', gap)}>
            Space vertically
          </button>
        </div>
        {movable.length === 0 ? <Hint>Select one or more unlocked objects to align them.</Hint> : null}
      </Section>

      <Section title="Guides">
        <Toggle label="Grid" checked={prefs.showGrid} onChange={(v2) => setPrefs({ showGrid: v2 })} />
        <NumberField label="Grid size" value={prefs.gridSize} min={2} max={500} precision={0} unit="px" defaultValue={20} onChange={(g) => setPrefs({ gridSize: Math.round(g) })} />
        <Toggle label="Snap to guides, grid and objects" checked={prefs.snap} onChange={(v2) => setPrefs({ snap: v2 })} hint="Hold Alt while dragging to snap temporarily off." />
        <Toggle label="Centre guides" checked={prefs.showCenter} onChange={(v2) => setPrefs({ showCenter: v2 })} />
        <Toggle label="Safe-area guide" checked={prefs.showSafe} onChange={(v2) => setPrefs({ showSafe: v2 })} />
      </Section>
    </>
  );
}
