import { ChevronDown, ChevronUp, ChevronsDown, ChevronsUp, Copy, Eye, EyeOff, Lock, Trash2, Unlock } from 'lucide-react';
import { useStudio } from '../../studio';
import type { LogoObject, ObjectPatch, ObjectType } from '../../types';
import { ColorField, Hint, NumberField, Section, Segmented, TextField, Toggle } from '../ui/Fields';
import { IconButton } from '../ui/IconButton';
import { ObjectIcon, OBJECT_LABEL } from '../ui/Icons';
import { DEFAULT_SHAPE } from '../../lib/model';
import { getBounds } from '../../lib/geometry';
import { round } from '../../lib/util';

const ADD: ObjectType[] = ['text', 'rect', 'circle', 'ellipse', 'line'];
const SHORTCUT: Record<ObjectType, string> = { text: 'T', rect: 'R', circle: 'C', ellipse: 'E', line: 'L' };

export function AddObjects() {
  const { addObject } = useStudio();
  return (
    <Section title="Add to canvas">
      <div className="add-grid">
        {ADD.map((t) => (
          <button key={t} type="button" className="add-btn" title={`Add ${OBJECT_LABEL[t].toLowerCase()} (${SHORTCUT[t]})`} onClick={() => addObject(t)}>
            <ObjectIcon type={t} size={18} />
            <span>{OBJECT_LABEL[t]}</span>
          </button>
        ))}
      </div>
    </Section>
  );
}

export function DesignTab() {
  const { selected, act, setLeftTab, deleteSelected, duplicateSelected } = useStudio();
  const ids = selected.map((o) => o.id);
  const first = selected[0];
  const one: LogoObject | null = selected.length === 1 ? selected[0]! : null;
  const locked = !!one?.locked;

  const patch = (p: ObjectPatch, key: string) => act({ type: 'patchObjects', ids, patch: p, coalesce: `${key}:${ids.join('|')}` });

  if (!first) {
    return (
      <>
        <AddObjects />
        <div className="empty-state">
          <p>
            <strong>Nothing selected</strong>
          </p>
          <p>Click an object on the canvas or in the Layers panel to edit its position, size and colours. Drag on empty space to select several.</p>
        </div>
      </>
    );
  }

  const setW = (w: number) => {
    if (!one || one.type === 'text') return;
    if (one.type === 'line') return patch({ width: w }, 'w');
    const keep = one.type === 'circle' || one.lockAspect;
    patch(keep ? { width: w, height: round(w * (one.width > 0 ? one.height / one.width : 1), 2) } : { width: w }, 'w');
  };
  const setH = (h: number) => {
    if (!one || one.type === 'text' || one.type === 'line') return;
    const keep = one.type === 'circle' || one.lockAspect;
    patch(keep ? { height: h, width: round(h * (one.height > 0 ? one.width / one.height : 1), 2) } : { height: h }, 'h');
  };

  const hasFill = selected.some((o) => o.type !== 'line');
  const hasShape = selected.some((o) => o.type !== 'text');
  const fillVal = first.type === 'line' ? 'none' : first.fill;
  const strokeVal = first.stroke;
  const strokeWidth = first.strokeWidth;

  return (
    <>
      <AddObjects />
      <Section title={one ? `${OBJECT_LABEL[one.type]}` : `${selected.length} objects selected`}>
        <div className="icon-row" role="toolbar" aria-label="Object actions">
          <IconButton icon={<Copy size={15} />} label="Duplicate" shortcut="Ctrl+D" onClick={duplicateSelected} />
          {one ? (
            <>
              <IconButton icon={one.locked ? <Unlock size={15} /> : <Lock size={15} />} label={one.locked ? 'Unlock' : 'Lock'} onClick={() => act({ type: 'patchObjects', ids, patch: { locked: !one.locked } })} />
              <IconButton icon={one.visible ? <EyeOff size={15} /> : <Eye size={15} />} label={one.visible ? 'Hide' : 'Show'} onClick={() => act({ type: 'patchObjects', ids, patch: { visible: !one.visible } })} />
              <IconButton icon={<ChevronUp size={15} />} label="Bring forward" shortcut="]" onClick={() => act({ type: 'reorder', id: one.id, to: 'up' })} />
              <IconButton icon={<ChevronDown size={15} />} label="Send backward" shortcut="[" onClick={() => act({ type: 'reorder', id: one.id, to: 'down' })} />
              <IconButton icon={<ChevronsUp size={15} />} label="Bring to front" onClick={() => act({ type: 'reorder', id: one.id, to: 'top' })} />
              <IconButton icon={<ChevronsDown size={15} />} label="Send to back" onClick={() => act({ type: 'reorder', id: one.id, to: 'bottom' })} />
            </>
          ) : null}
          <IconButton icon={<Trash2 size={15} />} label="Delete" shortcut="Del" danger onClick={deleteSelected} />
        </div>
        {locked ? <Hint tone="warn">This object is locked. Unlock it to change its properties.</Hint> : null}
      </Section>

      <fieldset className="plain-fieldset" disabled={locked}>
        {one ? (
          <Section title="Position & size">
            <TextField label="Name" value={one.name} maxLength={80} onChange={(v) => act({ type: 'patchObjects', ids, patch: { name: v }, coalesce: `name:${one.id}` })} />
            <div className="two-col">
              <NumberField label="X" value={one.x} step={1} unit="px" onChange={(v) => patch({ x: v }, 'x')} />
              <NumberField label="Y" value={one.y} step={1} unit="px" onChange={(v) => patch({ y: v }, 'y')} />
            </div>
            {one.type === 'text' ? (
              <Hint>
                Text size is {round(getBounds(one).w)} x {round(getBounds(one).h)} px. Change it with the font size in the Type tab, or drag a corner handle on the canvas.{' '}
                <button type="button" className="link-btn" onClick={() => setLeftTab('type')}>
                  Open Type tab
                </button>
              </Hint>
            ) : one.type === 'line' ? (
              <NumberField label="Length" value={one.width} min={1} max={20000} unit="px" onChange={setW} />
            ) : (
              <>
                <div className="two-col">
                  <NumberField label="Width" value={one.width} min={1} max={20000} unit="px" onChange={setW} />
                  <NumberField label="Height" value={one.height} min={1} max={20000} unit="px" onChange={setH} />
                </div>
                <Toggle label={one.type === 'circle' ? 'Always a perfect circle' : 'Keep proportions when resizing'} checked={one.type === 'circle' ? true : one.lockAspect} disabled={one.type === 'circle'} onChange={(v) => patch({ lockAspect: v }, 'aspect')} />
              </>
            )}
            <NumberField label="Rotation" value={one.rotation} min={-360} max={360} step={1} unit="deg" defaultValue={0} slider sliderMin={0} sliderMax={360} onChange={(v) => patch({ rotation: v }, 'rot')} />
          </Section>
        ) : null}

        <Section title="Appearance">
          {first.type === 'text' && selected.every((o) => o.type === 'text') ? (
            <Hint>
              Text colour, outline and typography live in the{' '}
              <button type="button" className="link-btn" onClick={() => setLeftTab('type')}>
                Type tab
              </button>
              .
            </Hint>
          ) : (
            <>
              {hasFill ? <ColorField label="Fill" value={fillVal} allowNone defaultValue={DEFAULT_SHAPE.fill} onChange={(v) => patch({ fill: v }, 'fill')} /> : null}
              {hasShape ? (
                <>
                  <ColorField label="Stroke" value={strokeVal} allowNone defaultValue="none" onChange={(v) => patch({ stroke: v }, 'stroke')} />
                  <NumberField label="Stroke width" value={strokeWidth} min={0} max={200} step={1} unit="px" slider sliderMax={60} defaultValue={first.type === 'line' ? 6 : 0} onChange={(v) => patch({ strokeWidth: v }, 'sw')} />
                </>
              ) : null}
            </>
          )}
          {one && one.type === 'rect' ? <NumberField label="Corner radius" value={one.cornerRadius} min={0} max={2000} unit="px" slider sliderMax={200} defaultValue={0} onChange={(v) => patch({ cornerRadius: v }, 'cr')} /> : null}
          {one && one.type === 'line' ? (
            <Segmented label="Line ends" value={one.lineCap} onChange={(v) => patch({ lineCap: v }, 'cap')} options={[{ value: 'butt', label: 'Flat' }, { value: 'round', label: 'Round' }, { value: 'square', label: 'Square' }]} />
          ) : null}
          <NumberField label="Opacity" value={Math.round(first.opacity * 100)} min={0} max={100} step={1} unit="%" slider defaultValue={100} onChange={(v) => patch({ opacity: v / 100 }, 'op')} />
        </Section>
      </fieldset>
      {selected.length > 1 ? <Hint>Use the Layout tab to align and distribute these objects.</Hint> : null}
    </>
  );
}
