import { Copy, Trash2 } from 'lucide-react';
import { useStudio } from '../../studio';
import { Hint, Section, TextField } from '../ui/Fields';
import { IconButton } from '../ui/IconButton';
import { Thumbnail } from '../canvas/LogoSvg';
import { VARIATION_PRESETS } from '../../lib/variations';
import { cloneVariation } from '../../lib/model';

const KIND_LABEL: Record<string, string> = { primary: 'Primary', horizontal: 'Horizontal', stacked: 'Stacked', icon: 'Icon', wordmark: 'Wordmark', light: 'Light', dark: 'Dark', mono: 'Mono', custom: 'Custom' };

export function VariationsPanel() {
  const { project, state, act, variation, confirm, addVariationFromPreset } = useStudio();

  const remove = async (id: string, name: string) => {
    const ok = await confirm({ title: 'Delete variation?', message: `"${name}" and everything on it will be removed from this project. You can undo this with Ctrl+Z.`, confirmLabel: 'Delete variation', danger: true });
    if (ok) act({ type: 'deleteVariation', id });
  };

  return (
    <>
      <Section title="Variations">
        <ul className="variations">
          {project.variations.map((v) => {
            const active = v.id === state.activeId;
            return (
              <li key={v.id} className={`variation${active ? ' is-active' : ''}`}>
                <button type="button" className="variation-main" aria-pressed={active} onClick={() => act({ type: 'setActiveVariation', id: v.id })} title={`Edit ${v.name}`}>
                  <span className="variation-thumb">
                    <Thumbnail variation={v} />
                  </span>
                  <span className="variation-meta">
                    <strong>{v.name}</strong>
                    <small>
                      {KIND_LABEL[v.kind] ?? v.kind} - {v.width} x {v.height}
                    </small>
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
        <div className="variation-edit">
          <TextField label="Rename selected variation" value={variation.name} maxLength={60} onChange={(name) => act({ type: 'renameVariation', id: variation.id, name })} />
          <div className="icon-row">
            <IconButton icon={<Copy size={15} />} label="Duplicate variation" text="Duplicate" onClick={() => act({ type: 'addVariation', variation: cloneVariation(variation, `${variation.name} copy`) })} />
            <IconButton icon={<Trash2 size={15} />} label="Delete variation" text="Delete" danger disabled={project.variations.length <= 1} onClick={() => remove(variation.id, variation.name)} />
          </div>
        </div>
      </Section>

      <Section title="Create from current">
        <div className="preset-grid">
          {VARIATION_PRESETS.map((p) => (
            <button key={p.kind} type="button" className="preset-btn" title={p.description} onClick={() => addVariationFromPreset(p.kind)}>
              <strong>{p.label}</strong>
              <small>{p.description}</small>
            </button>
          ))}
        </div>
        <Hint>Each variation keeps its own canvas, colours and objects. Automatic layouts are only a starting point - edit them by hand whenever you like.</Hint>
      </Section>
    </>
  );
}
