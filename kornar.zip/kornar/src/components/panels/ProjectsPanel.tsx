import { useRef } from 'react';
import { Copy, Download, FilePlus, FolderOpen, Save, Trash2, Upload } from 'lucide-react';
import { useStudio } from '../../studio';
import { Hint, Section, Toggle } from '../ui/Fields';
import { IconButton } from '../ui/IconButton';
import { formatDate, formatTime } from '../../lib/util';

export function ProjectsPanel() {
  const s = useStudio();
  const fileRef = useRef<HTMLInputElement>(null);

  const status = s.saveError ? `Not saved: ${s.saveError}` : s.dirty ? (s.prefs.autosave ? 'Unsaved changes - autosaving...' : 'Unsaved changes') : s.lastSavedAt ? `All changes saved at ${formatTime(s.lastSavedAt)}` : 'Saved in this browser';

  return (
    <>
      <Section title="This project">
        <p className={`save-status${s.saveError ? ' text-error' : ''}`} role="status">
          {status}
        </p>
        <Toggle label="Autosave in this browser" checked={s.prefs.autosave} onChange={(v) => s.setPrefs({ autosave: v })} />
        <div className="btn-row">
          <button type="button" className="btn btn-primary" onClick={() => s.saveNow(true)}>
            <Save size={14} /> Save now
          </button>
          <button type="button" className="btn" onClick={() => s.openDialog('new')}>
            <FilePlus size={14} /> New
          </button>
        </div>
        <div className="btn-row">
          <button type="button" className="btn" onClick={s.exportProjectJson}>
            <Download size={14} /> Export JSON
          </button>
          <button type="button" className="btn" onClick={() => fileRef.current?.click()}>
            <Upload size={14} /> Import JSON
          </button>
          <input
            ref={fileRef}
            type="file"
            accept=".json,application/json"
            hidden
            aria-label="Import project JSON file"
            onChange={(e) => {
              const f = e.target.files?.[0];
              e.target.value = '';
              if (f) void s.importProjectFile(f);
            }}
          />
        </div>
        {!s.persistent ? <Hint tone="warn">Browser storage is unavailable here (private window or blocked), so projects will be lost when the tab closes. Use Export JSON to keep your work.</Hint> : null}
      </Section>

      <Section title={`Saved projects (${s.savedProjects.length})`}>
        {s.savedProjects.length === 0 ? <Hint>Nothing saved yet. Your project is saved automatically while Autosave is on.</Hint> : null}
        <ul className="projects">
          {s.savedProjects.map((m) => {
            const current = m.id === s.project.id;
            return (
              <li key={m.id} className={`project${current ? ' is-current' : ''}`}>
                <div className="project-meta">
                  <strong>{m.name}</strong>
                  <small>
                    {current ? 'Open now - ' : ''}
                    {formatDate(m.updatedAt)}
                  </small>
                </div>
                <div className="project-actions">
                  <IconButton icon={<FolderOpen size={14} />} label={`Open ${m.name}`} disabled={current} onClick={() => void s.openProject(m.id)} />
                  <IconButton icon={<Copy size={14} />} label={`Duplicate ${m.name}`} onClick={() => s.duplicateProject(m.id)} />
                  <IconButton icon={<Trash2 size={14} />} label={`Delete ${m.name}`} danger onClick={() => void s.deleteProject(m.id)} />
                </div>
              </li>
            );
          })}
        </ul>
        <Hint>Projects are stored only in this browser on this computer. Export JSON to back them up or move them elsewhere.</Hint>
      </Section>
    </>
  );
}
