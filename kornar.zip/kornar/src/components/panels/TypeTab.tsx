import { useState } from 'react';
import { AlignCenter, AlignLeft, AlignRight, Italic } from 'lucide-react';
import { useStudio } from '../../studio';
import type { ObjectPatch, TextObject } from '../../types';
import { ColorField, Hint, NumberField, Section, SelectField, Segmented, TextField } from '../ui/Fields';
import { AddObjects } from './DesignTab';
import { DEFAULT_TEXT } from '../../lib/model';
import { FONT_LIST, isFontAvailable, sanitizeFamily } from '../../lib/fonts';
import { hasCursiveScript } from '../../lib/measure';

const WEIGHTS = [
  { value: 100, label: '100 - Thin' },
  { value: 200, label: '200 - Extra light' },
  { value: 300, label: '300 - Light' },
  { value: 400, label: '400 - Regular' },
  { value: 500, label: '500 - Medium' },
  { value: 600, label: '600 - Semibold' },
  { value: 700, label: '700 - Bold' },
  { value: 800, label: '800 - Extra bold' },
  { value: 900, label: '900 - Black' },
];

export function TypeTab() {
  const { selected, act, addObject } = useStudio();
  const texts = selected.filter((o): o is TextObject => o.type === 'text');
  const first = texts[0];
  const [custom, setCustom] = useState('');

  if (!first) {
    return (
      <div className="empty-state">
        <p>
          <strong>No text selected</strong>
        </p>
        <p>Select a text object to edit its font, size, spacing and alignment, or add a new one.</p>
        <button type="button" className="btn btn-primary" onClick={() => addObject('text')}>
          Add text
        </button>
        <AddObjects />
      </div>
    );
  }

  const ids = texts.map((o) => o.id);
  const locked = texts.every((o) => o.locked);
  const single = texts.length === 1;
  const patch = (p: ObjectPatch, key: string) => act({ type: 'patchObjects', ids, patch: p, coalesce: `${key}:${ids.join('|')}` });

  const known = FONT_LIST.some((f) => f.family === first.fontFamily);
  const fontOptions = [
    ...(known ? [] : [{ value: first.fontFamily, label: `${first.fontFamily} (custom)` }]),
    ...FONT_LIST.map((f) => ({ value: f.family, label: `${f.family}${isFontAvailable(f.family) ? '' : ' - not installed'}${f.scripts ? `  [${f.scripts}]` : ''}` })),
  ];
  const available = isFontAvailable(first.fontFamily);
  const cursive = hasCursiveScript(first.text);

  const applyCustom = () => {
    const fam = sanitizeFamily(custom);
    if (fam) {
      patch({ fontFamily: fam }, 'font');
      setCustom('');
    }
  };

  return (
    <fieldset className="plain-fieldset" disabled={locked}>
      {locked ? <Hint tone="warn">This text is locked. Unlock it in the Design tab or Layers panel to edit.</Hint> : null}
      <Section title="Text">
        <TextField
          label="Content"
          multiline
          rows={3}
          value={single ? first.text : ''}
          disabled={!single}
          placeholder={single ? 'Type your logo text. Press Enter for a new line.' : 'Select one text object to edit its content'}
          onChange={(v) => patch({ text: v }, 'text')}
          dir={first.direction}
          maxLength={2000}
        />
        <Segmented
          label="Transform"
          value={first.transform}
          onChange={(v) => patch({ transform: v }, 'transform')}
          onReset={() => patch({ transform: 'none' }, 'transform')}
          canReset={first.transform !== 'none'}
          options={[
            { value: 'none', label: 'Aa', title: 'As typed' },
            { value: 'uppercase', label: 'AA', title: 'UPPERCASE' },
            { value: 'lowercase', label: 'aa', title: 'lowercase' },
          ]}
        />
      </Section>

      <Section title="Font">
        <SelectField label="Family" value={first.fontFamily} options={fontOptions} onChange={(v) => patch({ fontFamily: v }, 'font')} onReset={() => patch({ fontFamily: DEFAULT_TEXT.fontFamily }, 'font')} canReset={first.fontFamily !== DEFAULT_TEXT.fontFamily} />
        {!available ? (
          <Hint tone="warn">
            "{first.fontFamily}" is not installed on this computer, so a fallback font is shown (and exported). Install the font, or pick another one.
          </Hint>
        ) : null}
        <div className="inline-add">
          <input className="input" type="text" value={custom} placeholder="Other installed font name" aria-label="Custom font family name" maxLength={64} onChange={(e) => setCustom(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && applyCustom()} />
          <button type="button" className="btn" onClick={applyCustom} disabled={!sanitizeFamily(custom)}>
            Use
          </button>
        </div>
        <NumberField label="Size" value={first.fontSize} min={4} max={2000} step={1} unit="px" slider sliderMin={8} sliderMax={400} defaultValue={DEFAULT_TEXT.fontSize} onChange={(v) => patch({ fontSize: v }, 'size')} />
        <SelectField label="Weight" value={first.fontWeight} options={WEIGHTS} onChange={(v) => patch({ fontWeight: v }, 'weight')} onReset={() => patch({ fontWeight: DEFAULT_TEXT.fontWeight }, 'weight')} canReset={first.fontWeight !== DEFAULT_TEXT.fontWeight} hint="Only weights the font actually provides will look different." />
        <Segmented
          label="Style"
          value={first.italic ? 'italic' : 'normal'}
          onChange={(v) => patch({ italic: v === 'italic' }, 'italic')}
          options={[
            { value: 'normal', label: 'Upright' },
            { value: 'italic', label: <Italic size={14} />, title: 'Italic' },
          ]}
        />
      </Section>

      <Section title="Spacing & alignment">
        <NumberField label="Letter spacing" value={first.letterSpacing} min={-50} max={300} step={0.5} unit="px" slider sliderMin={-20} sliderMax={100} defaultValue={DEFAULT_TEXT.letterSpacing} disabled={cursive} onChange={(v) => patch({ letterSpacing: v }, 'ls')} hint={cursive ? 'Disabled for Arabic text: spacing would break the joined letters.' : undefined} />
        <NumberField label="Line height" value={first.lineHeight} min={0.3} max={4} step={0.05} slider sliderMin={0.6} sliderMax={2.5} precision={2} defaultValue={DEFAULT_TEXT.lineHeight} onChange={(v) => patch({ lineHeight: v }, 'lh')} />
        <Segmented
          label="Alignment"
          value={first.align}
          onChange={(v) => patch({ align: v }, 'align')}
          onReset={() => patch({ align: 'center' }, 'align')}
          canReset={first.align !== 'center'}
          options={[
            { value: 'left', label: <AlignLeft size={15} />, title: 'Align left' },
            { value: 'center', label: <AlignCenter size={15} />, title: 'Align centre' },
            { value: 'right', label: <AlignRight size={15} />, title: 'Align right' },
          ]}
        />
        <Segmented
          label="Text direction"
          value={first.direction}
          onChange={(v) => patch({ direction: v }, 'dir')}
          options={[
            { value: 'ltr', label: 'LTR', title: 'Left to right' },
            { value: 'rtl', label: 'RTL', title: 'Right to left (Arabic, Hebrew, ...)' },
          ]}
        />
      </Section>

      <Section title="Colour & outline">
        <ColorField label="Text colour" value={first.fill} allowNone={false} defaultValue="primary" onChange={(v) => patch({ fill: v }, 'tfill')} />
        <ColorField label="Outline colour" value={first.stroke} allowNone defaultValue="none" onChange={(v) => patch({ stroke: v }, 'tstroke')} />
        <NumberField label="Outline width" value={first.strokeWidth} min={0} max={100} step={0.5} unit="px" slider sliderMax={20} defaultValue={0} disabled={first.stroke === 'none'} onChange={(v) => patch({ strokeWidth: v }, 'tsw')} hint={first.stroke === 'none' ? 'Choose an outline colour first.' : undefined} />
        <NumberField label="Opacity" value={Math.round(first.opacity * 100)} min={0} max={100} unit="%" slider defaultValue={100} onChange={(v) => patch({ opacity: v / 100 }, 'op')} />
      </Section>
      <Hint>Arabic-inspired work: type Arabic text, switch direction to RTL and pick an Arabic-capable font (Tahoma, Segoe UI, Arial, Traditional Arabic...). KORNAR does not generate calligraphy; combine your own text with the geometric shapes.</Hint>
    </fieldset>
  );
}
