import { useState } from 'react';
import { useStudio } from '../../studio';
import type { ColorMode } from '../../types';
import { ColorField, Hint, Section, Toggle } from '../ui/Fields';
import { PALETTES } from '../../lib/palettes';
import { DEFAULT_COLORS } from '../../lib/model';
import { contrastRatio } from '../../lib/color';

const MODES: { value: ColorMode; label: string; title: string }[] = [
  { value: 'full', label: 'Full colour', title: 'Use the palette colours' },
  { value: 'mono', label: 'Monochrome', title: 'Everything in the primary colour' },
  { value: 'bw', label: 'Black / white', title: 'Black logo on white' },
  { value: 'bw-inverted', label: 'White / black', title: 'White logo on black' },
];

export function ColorTab() {
  const { variation, act } = useStudio();
  const c = variation.colors;
  const [allVariations, setAllVariations] = useState(false);
  const set = (patch: Partial<typeof c>, key: string) => act({ type: 'setColors', patch, allVariations, coalesce: `col:${key}:${allVariations}` });
  const ratio = contrastRatio(c.primary, c.background);

  return (
    <>
      <Section title="Colour version">
        <div className="mode-grid" role="radiogroup" aria-label="Colour version">
          {MODES.map((m) => (
            <button key={m.value} type="button" role="radio" aria-checked={variation.colorMode === m.value} title={m.title} className={`mode-btn${variation.colorMode === m.value ? ' is-active' : ''}`} onClick={() => act({ type: 'setColorMode', mode: m.value })}>
              <span className={`mode-sw mode-${m.value}`} aria-hidden="true" />
              {m.label}
            </button>
          ))}
        </div>
        {variation.colorMode !== 'full' ? <Hint>Palette colours are kept - switch back to Full colour to see them again. This version is what gets exported.</Hint> : null}
      </Section>

      <Section title="Brand colours">
        <ColorField label="Background" value={c.background} allowRoles={false} defaultValue={DEFAULT_COLORS.background} onChange={(v) => set({ background: v }, 'bg')} />
        <ColorField label="Primary" value={c.primary} allowRoles={false} defaultValue={DEFAULT_COLORS.primary} onChange={(v) => set({ primary: v }, 'pri')} />
        <ColorField label="Secondary / accent" value={c.secondary} allowRoles={false} defaultValue={DEFAULT_COLORS.secondary} onChange={(v) => set({ secondary: v }, 'sec')} />
        <Toggle label="Transparent background" checked={c.transparentBackground} onChange={(v) => set({ transparentBackground: v }, 'tr')} hint="Shows a checkerboard on the canvas and exports without a background by default." />
        {ratio < 3 ? <Hint tone="warn">Primary and background have low contrast ({ratio.toFixed(1)}:1). The logo may be hard to read.</Hint> : <Hint>Primary / background contrast: {ratio.toFixed(1)}:1</Hint>}
      </Section>

      <Section title="Palettes">
        <Toggle label="Apply to all variations" checked={allVariations} onChange={setAllVariations} />
        <div className="palette-grid">
          {PALETTES.map((p) => {
            const active = p.background === c.background && p.primary === c.primary && p.secondary === c.secondary;
            return (
              <button key={p.id} type="button" className={`palette${active ? ' is-active' : ''}`} aria-pressed={active} title={`Apply ${p.name}`} onClick={() => act({ type: 'setColors', patch: { background: p.background, primary: p.primary, secondary: p.secondary }, allVariations })}>
                <span className="palette-strip" aria-hidden="true">
                  <i style={{ background: p.background }} />
                  <i style={{ background: p.primary }} />
                  <i style={{ background: p.secondary }} />
                </span>
                <span>{p.name}</span>
              </button>
            );
          })}
        </div>
        <Hint>Objects that use Primary / Secondary / Background follow the palette. Objects with a custom colour keep it.</Hint>
      </Section>
    </>
  );
}
