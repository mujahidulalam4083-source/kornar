import { createContext, useCallback, useContext, useEffect, useMemo, useReducer, useRef, useState, type ReactNode } from 'react';
import type { LogoObject, ObjectPatch, ObjectType, Prefs, Project, Variation, VariationKind } from './types';
import { createEditorState, getActiveVariation, reducer, type Action, type EditorState } from './lib/reducer';
import { ConfirmDialog } from './components/dialogs/ConfirmDialog';
import { ProjectStore, createBrowserStore, type ProjectMeta } from './lib/storage';
import { buildTemplate } from './lib/templates';
import { cloneVariation, createBlankProject, createObjectAt, createVariation } from './lib/model';
import { deriveVariation } from './lib/variations';
import { parseProjectJson, serializeProject } from './lib/validate';
import { downloadText, safeFilename } from './lib/exporter';
import { uid } from './lib/id';
import { clamp, formatBytes, slugify } from './lib/util';

export type LeftTab = 'design' | 'type' | 'color' | 'layout';
export type RightTab = 'layers' | 'variations' | 'projects';
export type DialogId = 'new' | 'export' | 'help' | 'onboarding' | 'reset' | null;
export type ToastKind = 'success' | 'error' | 'info';

export interface Toast {
  id: number;
  kind: ToastKind;
  text: string;
}
export interface ConfirmOptions {
  title: string;
  message: string;
  confirmLabel?: string;
  danger?: boolean;
}
export interface ViewState {
  zoom: number;
  cx: number;
  cy: number;
}

export const MIN_ZOOM = 0.05;
export const MAX_ZOOM = 8;

export interface Studio {
  state: EditorState;
  project: Project;
  variation: Variation;
  selected: LogoObject[];
  act: (a: Action) => void;
  // ui
  leftTab: LeftTab;
  setLeftTab: (t: LeftTab) => void;
  rightTab: RightTab;
  setRightTab: (t: RightTab) => void;
  leftOpen: boolean;
  rightOpen: boolean;
  togglePanel: (side: 'left' | 'right') => void;
  tool: 'select' | 'hand';
  setTool: (t: 'select' | 'hand') => void;
  dialog: DialogId;
  openDialog: (d: DialogId) => void;
  prefs: Prefs;
  setPrefs: (p: Partial<Prefs>) => void;
  // view
  view: ViewState;
  stage: { w: number; h: number };
  setStage: (s: { w: number; h: number }) => void;
  fit: () => void;
  zoomAt: (factor: number, anchor?: { x: number; y: number }) => void;
  setZoom: (z: number) => void;
  panBy: (dx: number, dy: number) => void;
  // feedback
  toasts: Toast[];
  toast: (kind: ToastKind, text: string) => void;
  dismissToast: (id: number) => void;
  confirmReq: { opts: ConfirmOptions; resolve: (v: boolean) => void } | null;
  confirm: (opts: ConfirmOptions) => Promise<boolean>;
  // persistence
  dirty: boolean;
  saveError: string | null;
  lastSavedAt: number | null;
  persistent: boolean;
  savedProjects: ProjectMeta[];
  saveNow: (manual: boolean) => boolean;
  newProject: (templateId: string, name?: string) => void;
  openProject: (id: string) => Promise<void>;
  duplicateProject: (id?: string) => void;
  deleteProject: (id: string) => Promise<void>;
  importProjectFile: (file: File) => Promise<void>;
  exportProjectJson: () => void;
  lastExport: string | null;
  setLastExport: (s: string) => void;
  // actions
  addObject: (type: ObjectType) => void;
  deleteSelected: () => void;
  duplicateSelected: () => void;
  nudge: (dx: number, dy: number) => void;
  addVariationFromPreset: (kind: VariationKind) => void;
  resetCanvas: (mode: 'clear' | 'template') => void;
}

const Ctx = createContext<Studio | null>(null);

export function useStudio(): Studio {
  const s = useContext(Ctx);
  if (!s) throw new Error('useStudio must be used inside <StudioProvider>');
  return s;
}

function bootProject(store: ProjectStore): Project {
  const id = store.getCurrentId();
  if (id) {
    const r = store.load(id);
    if (r.ok) return r.value;
  }
  return buildTemplate('minimal-wordmark') ?? createBlankProject();
}

const isCompact = () => typeof window !== 'undefined' && window.matchMedia('(max-width: 1100px)').matches;

export function StudioProvider({ children }: { children: ReactNode }) {
  const [{ store, persistent }] = useState(createBrowserStore);
  const [initial] = useState(() => bootProject(store));
  const [state, dispatch] = useReducer(reducer, initial, (p) => createEditorState(p));
  const stateRef = useRef(state);
  stateRef.current = state;

  const [prefs, setPrefsState] = useState<Prefs>(() => store.getPrefs());
  const [leftTab, setLeftTab] = useState<LeftTab>('design');
  const [rightTab, setRightTab] = useState<RightTab>('layers');
  const [leftOpen, setLeftOpen] = useState(() => !isCompact());
  const [rightOpen, setRightOpen] = useState(() => !isCompact());
  const [tool, setTool] = useState<'select' | 'hand'>('select');
  const [dialog, setDialog] = useState<DialogId>(() => (store.getPrefs().onboardingSeen ? null : 'onboarding'));
  const [view, setView] = useState<ViewState>({ zoom: 1, cx: 0, cy: 0 });
  const [stage, setStageState] = useState({ w: 0, h: 0 });
  const [fitPending, setFitPending] = useState(true);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [confirmReq, setConfirmReq] = useState<Studio['confirmReq']>(null);
  const [savedProject, setSavedProject] = useState<Project | null>(() => {
    const id = store.getCurrentId();
    return id && store.list().some((m) => m.id === id) ? initial : null;
  });
  const [saveError, setSaveError] = useState<string | null>(null);
  const [lastSavedAt, setLastSavedAt] = useState<number | null>(null);
  const [savedProjects, setSavedProjects] = useState<ProjectMeta[]>(() => store.list());
  const [lastExport, setLastExport] = useState<string | null>(null);
  const toastId = useRef(1);

  const variation = getActiveVariation(state);
  const selected = useMemo(() => variation.objects.filter((o) => state.selection.includes(o.id)), [variation, state.selection]);

  const act = useCallback((a: Action) => dispatch({ ...a, t: Date.now() } as Action), []);

  // ---- feedback -----------------------------------------------------------------------------
  const dismissToast = useCallback((id: number) => setToasts((t) => t.filter((x) => x.id !== id)), []);
  const toast = useCallback(
    (kind: ToastKind, text: string) => {
      const id = toastId.current++;
      setToasts((t) => [...t.slice(-3), { id, kind, text }]);
      window.setTimeout(() => dismissToast(id), kind === 'error' ? 8000 : 4000);
    },
    [dismissToast],
  );
  const confirm = useCallback((opts: ConfirmOptions) => new Promise<boolean>((resolve) => setConfirmReq({ opts, resolve })), []);

  // ---- prefs / theme ------------------------------------------------------------------------
  const setPrefs = useCallback(
    (p: Partial<Prefs>) =>
      setPrefsState((cur) => {
        const next = { ...cur, ...p };
        store.setPrefs(next);
        return next;
      }),
    [store],
  );
  useEffect(() => {
    document.documentElement.dataset.theme = prefs.theme;
  }, [prefs.theme]);

  useEffect(() => {
    const mq = window.matchMedia('(max-width: 1100px)');
    const on = () => {
      setLeftOpen(!mq.matches);
      setRightOpen(!mq.matches);
    };
    mq.addEventListener('change', on);
    return () => mq.removeEventListener('change', on);
  }, []);

  const togglePanel = useCallback((side: 'left' | 'right') => {
    const compact = isCompact();
    if (side === 'left') {
      setLeftOpen((o) => !o);
      if (compact) setRightOpen(false);
    } else {
      setRightOpen((o) => !o);
      if (compact) setLeftOpen(false);
    }
  }, []);

  // ---- persistence --------------------------------------------------------------------------
  const dirty = state.project !== savedProject;
  const refreshList = useCallback(() => setSavedProjects(store.list()), [store]);

  const saveNow = useCallback(
    (manual: boolean): boolean => {
      const s = stateRef.current;
      const toSave: Project = { ...s.project, activeVariationId: s.activeId };
      const r = store.save(toSave);
      if (r.ok) {
        store.setCurrentId(toSave.id);
        setSavedProject(s.project);
        setSaveError(null);
        setLastSavedAt(r.value.savedAt);
        refreshList();
        if (manual) toast('success', `Saved "${toSave.name}" in this browser (${formatBytes(r.value.bytes)}).`);
        return true;
      }
      setSaveError(r.error);
      toast('error', `Not saved: ${r.error}`);
      return false;
    },
    [store, toast, refreshList],
  );

  useEffect(() => {
    if (!prefs.autosave || !dirty) return;
    const id = window.setTimeout(() => saveNow(false), 700);
    return () => window.clearTimeout(id);
  }, [prefs.autosave, dirty, state.project, saveNow]);

  // Warn before closing the tab with unsaved work.
  useEffect(() => {
    const on = (e: BeforeUnloadEvent) => {
      if (stateRef.current.project !== savedProjectRef.current) {
        e.preventDefault();
        e.returnValue = '';
      }
    };
    window.addEventListener('beforeunload', on);
    return () => window.removeEventListener('beforeunload', on);
  }, []);
  const savedProjectRef = useRef(savedProject);
  savedProjectRef.current = savedProject;

  /** Makes sure current work is safe before replacing it. Returns false if the user cancels. */
  const ensureSafe = useCallback(async (): Promise<boolean> => {
    if (stateRef.current.project === savedProjectRef.current) return true;
    if (saveNow(false)) return true;
    return confirm({ title: 'Discard unsaved changes?', message: 'The current project could not be saved to this browser. Continue and lose these changes? (You can cancel and export it as JSON first.)', confirmLabel: 'Discard changes', danger: true });
  }, [saveNow, confirm]);

  const adopt = useCallback(
    (project: Project, saved: boolean) => {
      dispatch({ type: 'load', project });
      setSavedProject(saved ? project : null);
      setSaveError(null);
      store.setCurrentId(project.id);
      setFitPending(true);
      setTool('select');
    },
    [store],
  );

  /** Saves a brand-new project right away and opens it. */
  const persistAndOpen = useCallback(
    (project: Project) => {
      const r = store.save(project);
      if (r.ok) setLastSavedAt(r.value.savedAt);
      else toast('error', `The project was created but could not be saved: ${r.error}`);
      adopt(project, r.ok);
      refreshList();
    },
    [store, toast, adopt, refreshList],
  );

  const newProject = useCallback(
    (templateId: string, name?: string) => {
      void (async () => {
        if (!(await ensureSafe())) return;
        const p = templateId === 'blank' ? createBlankProject(name || 'Untitled logo') : buildTemplate(templateId);
        if (!p) {
          toast('error', 'That template could not be found.');
          return;
        }
        const named = name ? { ...p, name: name.slice(0, 80) } : p;
        persistAndOpen(named);
        setLeftTab('design');
        toast('success', `Created "${named.name}".`);
      })();
    },
    [ensureSafe, persistAndOpen, toast],
  );

  const openProject = useCallback(
    async (id: string) => {
      if (id === stateRef.current.project.id) return;
      if (!(await ensureSafe())) return;
      const r = store.load(id);
      if (!r.ok) {
        toast('error', r.error);
        return;
      }
      adopt(r.value, true);
    },
    [ensureSafe, store, adopt, toast],
  );

  const duplicateProject = useCallback(
    (id?: string) => {
      const s = stateRef.current;
      let source: Project | null = null;
      if (!id || id === s.project.id) source = { ...s.project, activeVariationId: s.activeId };
      else {
        const r = store.load(id);
        if (r.ok) source = r.value;
        else toast('error', r.error);
      }
      if (!source) return;
      void (async () => {
        if (!(await ensureSafe())) return;
        const now = Date.now();
        const copy: Project = { ...structuredClone(source!), id: uid(), name: `${source!.name} copy`.slice(0, 80), createdAt: now, updatedAt: now };
        persistAndOpen(copy);
        toast('success', `Duplicated as "${copy.name}".`);
      })();
    },
    [store, toast, ensureSafe, persistAndOpen],
  );

  const deleteProject = useCallback(
    async (id: string) => {
      const meta = store.list().find((m) => m.id === id);
      const ok = await confirm({ title: 'Delete saved project?', message: `"${meta?.name ?? 'This project'}" will be permanently removed from this browser. Export it as JSON first if you might need it.`, confirmLabel: 'Delete project', danger: true });
      if (!ok) return;
      const r = store.remove(id);
      if (!r.ok) {
        toast('error', r.error);
        return;
      }
      refreshList();
      if (id === stateRef.current.project.id) {
        const next = store.list()[0];
        const loaded = next ? store.load(next.id) : null;
        if (loaded && loaded.ok) adopt(loaded.value, true);
        else persistAndOpen(buildTemplate('minimal-wordmark') ?? createBlankProject());
      }
      toast('info', 'Project deleted.');
    },
    [store, confirm, toast, refreshList, adopt, persistAndOpen],
  );

  const importProjectFile = useCallback(
    async (file: File) => {
      if (file.size > 5 * 1024 * 1024) {
        toast('error', 'Import failed: the file is larger than 5 MB.');
        return;
      }
      let text: string;
      try {
        text = await file.text();
      } catch {
        toast('error', 'Import failed: the file could not be read.');
        return;
      }
      const r = parseProjectJson(text);
      if (!r.ok) {
        toast('error', `Import failed: ${r.error}`);
        return;
      }
      if (!(await ensureSafe())) return;
      const now = Date.now();
      const p: Project = { ...r.value, id: uid(), createdAt: now, updatedAt: now };
      persistAndOpen(p);
      toast('success', `Imported "${p.name}" (${p.variations.length} variation${p.variations.length === 1 ? '' : 's'}).`);
    },
    [toast, ensureSafe, persistAndOpen],
  );

  const exportProjectJson = useCallback(() => {
    const s = stateRef.current;
    try {
      const filename = safeFilename(`${slugify(s.project.name, 'logo')}.kornar`, 'json');
      const bytes = downloadText(serializeProject({ ...s.project, activeVariationId: s.activeId }), filename, 'application/json');
      setLastExport(`${filename} (${formatBytes(bytes)})`);
      toast('success', `Project file download started: ${filename}`);
    } catch {
      toast('error', 'Could not create the project file.');
    }
  }, [toast]);

  // ---- view ---------------------------------------------------------------------------------
  const setStage = useCallback((s: { w: number; h: number }) => setStageState((cur) => (cur.w === s.w && cur.h === s.h ? cur : s)), []);

  const stageRef = useRef(stage);
  stageRef.current = stage;
  const fit = useCallback(() => {
    const st = stageRef.current;
    if (st.w <= 0 || st.h <= 0) return;
    const v = getActiveVariation(stateRef.current);
    const zoom = clamp(Math.min((st.w - 96) / v.width, (st.h - 96) / v.height), MIN_ZOOM, MAX_ZOOM);
    setView({ zoom, cx: v.width / 2, cy: v.height / 2 });
  }, []);

  useEffect(() => {
    if (fitPending && stage.w > 0) {
      fit();
      setFitPending(false);
    }
  }, [fitPending, stage.w, stage.h, state.activeId, fit]);
  useEffect(() => setFitPending(true), [state.activeId]);

  const zoomAt = useCallback(
    (factor: number, anchor?: { x: number; y: number }) => {
      setView((v) => {
        const z = clamp(v.zoom * factor, MIN_ZOOM, MAX_ZOOM);
        if (z === v.zoom) return v;
        const a = anchor ?? { x: stage.w / 2, y: stage.h / 2 };
        const px = v.cx - stage.w / (2 * v.zoom) + a.x / v.zoom;
        const py = v.cy - stage.h / (2 * v.zoom) + a.y / v.zoom;
        return { zoom: z, cx: px - a.x / z + stage.w / (2 * z), cy: py - a.y / z + stage.h / (2 * z) };
      });
    },
    [stage.w, stage.h],
  );
  const setZoom = useCallback((z: number) => zoomAt(clamp(z, MIN_ZOOM, MAX_ZOOM) / view.zoom), [zoomAt, view.zoom]);
  const panBy = useCallback((dx: number, dy: number) => setView((v) => ({ ...v, cx: v.cx - dx / v.zoom, cy: v.cy - dy / v.zoom })), []);

  // ---- editing helpers ----------------------------------------------------------------------
  const addObject = useCallback(
    (type: ObjectType) => {
      const v = getActiveVariation(stateRef.current);
      act({ type: 'addObject', object: createObjectAt(type, v.width / 2, v.height / 2, v.objects) });
      setTool('select');
      setLeftTab(type === 'text' ? 'type' : 'design');
    },
    [act],
  );

  const deleteSelected = useCallback(() => {
    const s = stateRef.current;
    const v = getActiveVariation(s);
    const ids = v.objects.filter((o) => s.selection.includes(o.id) && !o.locked).map((o) => o.id);
    if (ids.length === 0) {
      if (s.selection.length > 0) toast('info', 'Locked objects cannot be deleted. Unlock them first.');
      return;
    }
    act({ type: 'deleteObjects', ids });
  }, [act, toast]);

  const duplicateSelected = useCallback(() => {
    const s = stateRef.current;
    if (s.selection.length) act({ type: 'duplicateObjects', ids: s.selection });
  }, [act]);

  const nudge = useCallback(
    (dx: number, dy: number) => {
      const s = stateRef.current;
      const v = getActiveVariation(s);
      const changes: Record<string, ObjectPatch> = {};
      for (const o of v.objects) if (s.selection.includes(o.id) && !o.locked) changes[o.id] = { x: o.x + dx, y: o.y + dy };
      if (Object.keys(changes).length) act({ type: 'applyChanges', changes, coalesce: 'nudge', window: 700 });
    },
    [act],
  );

  const addVariationFromPreset = useCallback(
    (kind: VariationKind) => {
      const s = stateRef.current;
      const r = deriveVariation(getActiveVariation(s), kind);
      if (!r.ok) {
        toast('error', r.error);
        return;
      }
      act({ type: 'addVariation', variation: r.variation });
      setRightTab('variations');
      toast('success', `Added "${r.variation.name}". ${r.note ?? ''}`.trim());
    },
    [act, toast],
  );

  const resetCanvas = useCallback(
    (mode: 'clear' | 'template') => {
      const s = stateRef.current;
      const cur = getActiveVariation(s);
      if (mode === 'template' && s.project.templateId) {
        const t = buildTemplate(s.project.templateId);
        if (t) {
          act({ type: 'replaceVariation', variation: { ...cloneVariation(t.variations[0]!), name: cur.name, kind: cur.kind } });
          toast('success', 'Restored the starter design. Undo (Ctrl+Z) brings your version back.');
          return;
        }
      }
      act({ type: 'replaceVariation', variation: createVariation({ name: cur.name, kind: cur.kind }) });
      toast('success', 'Canvas cleared. Undo (Ctrl+Z) brings it back.');
    },
    [act, toast],
  );

  // Switch between Type and Design tabs when the selection changes to a different kind of object.
  const selKey = state.selection.join(',');
  useEffect(() => {
    if (state.selection.length !== 1) return;
    const o = variation.objects.find((x) => x.id === state.selection[0]);
    if (!o) return;
    setLeftTab((t) => (o.type === 'text' && t === 'design' ? 'type' : o.type !== 'text' && t === 'type' ? 'design' : t));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selKey]);

  const value: Studio = {
    state, project: state.project, variation, selected, act,
    leftTab, setLeftTab, rightTab, setRightTab, leftOpen, rightOpen, togglePanel, tool, setTool,
    dialog, openDialog: setDialog, prefs, setPrefs,
    view, stage, setStage, fit, zoomAt, setZoom, panBy,
    toasts, toast, dismissToast, confirmReq, confirm,
    dirty, saveError, lastSavedAt, persistent, savedProjects,
    saveNow, newProject, openProject, duplicateProject, deleteProject, importProjectFile, exportProjectJson,
    lastExport, setLastExport,
    addObject, deleteSelected, duplicateSelected, nudge, addVariationFromPreset, resetCanvas,
  };

  return (
    <Ctx.Provider value={value}>
      {children}
      <ConfirmBridge req={confirmReq} close={() => setConfirmReq(null)} />
    </Ctx.Provider>
  );
}

/** Rendered by the provider so any component can call confirm() without mounting its own dialog. */
function ConfirmBridge({ req, close }: { req: Studio['confirmReq']; close: () => void }) {
  if (!req) return null;
  const done = (v: boolean) => {
    req.resolve(v);
    close();
  };
  return <ConfirmDialog {...req.opts} onConfirm={() => done(true)} onCancel={() => done(false)} />;
}
