import type { ReactNode } from 'react';
import { FolderOpen, LayoutGrid, Layers, Palette, Shapes, SlidersHorizontal, Type } from 'lucide-react';
import { StudioProvider, useStudio, type LeftTab, type RightTab } from './studio';
import { TopBar } from './components/TopBar';
import { StatusBar } from './components/StatusBar';
import { Shortcuts } from './components/Shortcuts';
import { Tabs } from './components/Tabs';
import { Canvas } from './components/canvas/Canvas';
import { DesignTab } from './components/panels/DesignTab';
import { TypeTab } from './components/panels/TypeTab';
import { ColorTab } from './components/panels/ColorTab';
import { LayoutTab } from './components/panels/LayoutTab';
import { LayersPanel } from './components/panels/LayersPanel';
import { VariationsPanel } from './components/panels/VariationsPanel';
import { ProjectsPanel } from './components/panels/ProjectsPanel';
import { Toasts } from './components/ui/Toasts';
import { NewProjectDialog } from './components/dialogs/NewProjectDialog';
import { ExportDialog } from './components/dialogs/ExportDialog';
import { OnboardingDialog } from './components/dialogs/OnboardingDialog';
import { HelpDialog } from './components/dialogs/HelpDialog';
import { ResetDialog } from './components/dialogs/ResetDialog';

const LEFT_TABS: { id: LeftTab; label: string; icon: ReactNode }[] = [
  { id: 'design', label: 'Design', icon: <SlidersHorizontal size={16} /> },
  { id: 'type', label: 'Type', icon: <Type size={16} /> },
  { id: 'color', label: 'Color', icon: <Palette size={16} /> },
  { id: 'layout', label: 'Layout', icon: <LayoutGrid size={16} /> },
];
const RIGHT_TABS: { id: RightTab; label: string; icon: ReactNode }[] = [
  { id: 'layers', label: 'Layers', icon: <Layers size={16} /> },
  { id: 'variations', label: 'Variations', icon: <Shapes size={16} /> },
  { id: 'projects', label: 'Projects', icon: <FolderOpen size={16} /> },
];

function Shell() {
  const s = useStudio();
  return (
    <div className="app">
      <TopBar />
      <div className="workspace">
        <aside className="panel panel-left" hidden={!s.leftOpen} aria-label="Customization controls">
          <Tabs label="Customization" idPrefix="left" value={s.leftTab} onChange={s.setLeftTab} tabs={LEFT_TABS} />
          <div className="panel-scroll" role="tabpanel" id="left-panel" aria-labelledby={`left-tab-${s.leftTab}`}>
            {s.leftTab === 'design' ? <DesignTab /> : s.leftTab === 'type' ? <TypeTab /> : s.leftTab === 'color' ? <ColorTab /> : <LayoutTab />}
          </div>
        </aside>

        <main className="canvas-area" aria-label="Logo canvas">
          <Canvas />
        </main>

        <aside className="panel panel-right" hidden={!s.rightOpen} aria-label="Layers, variations and projects">
          <Tabs label="Project panels" idPrefix="right" value={s.rightTab} onChange={s.setRightTab} tabs={RIGHT_TABS} />
          <div className="panel-scroll" role="tabpanel" id="right-panel" aria-labelledby={`right-tab-${s.rightTab}`}>
            {s.rightTab === 'layers' ? <LayersPanel /> : s.rightTab === 'variations' ? <VariationsPanel /> : <ProjectsPanel />}
          </div>
        </aside>

        {(s.leftOpen || s.rightOpen) && <button type="button" className="scrim" aria-label="Close panels" onClick={() => (s.leftOpen ? s.togglePanel('left') : s.togglePanel('right'))} />}
      </div>
      <StatusBar />
      <Toasts />
      {s.dialog === 'new' && <NewProjectDialog />}
      {s.dialog === 'export' && <ExportDialog />}
      {s.dialog === 'onboarding' && <OnboardingDialog />}
      {s.dialog === 'help' && <HelpDialog />}
      {s.dialog === 'reset' && <ResetDialog />}
      <Shortcuts />
    </div>
  );
}

export default function App() {
  return (
    <StudioProvider>
      <Shell />
    </StudioProvider>
  );
}
