import type {
  ColorMode,
  ColorSettings,
  LineCap,
  LogoObject,
  Project,
  Result,
  TextAlign,
  TextDirection,
  TextTransform,
  Variation,
  VariationKind,
} from '../types';
import { normalizeColorRef, normalizeHex } from './color';
import { sanitizeFamily } from './fonts';
import { uid } from './id';
import { DEFAULT_COLORS, DEFAULT_TEXT, LIMITS } from './model';
import { clamp, isFiniteNumber } from './util';

/**
 * Validation for untrusted project data (imported files, corrupted storage).
 * Data is only ever treated as plain values: it is rebuilt field by field from a whitelist,
 * numbers are clamped, strings are length-limited and nothing is evaluated.
 */

class ValidationError extends Error {}

const fail = (msg: string): never => {
  throw new ValidationError(msg);
};

const isObj = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v);

function num(v: unknown, path: string, min: number, max: number, def?: number): number {
  if (v === undefined && def !== undefined) return def;
  if (!isFiniteNumber(v)) return fail(`${path} must be a number.`);
  return clamp(v, min, max);
}

function str(v: unknown, path: string, max: number, def?: string): string {
  if (v === undefined && def !== undefined) return def;
  if (typeof v !== 'string') return fail(`${path} must be text.`);
  return v.slice(0, max);
}

function bool(v: unknown, def: boolean): boolean {
  return typeof v === 'boolean' ? v : def;
}

function oneOf<T extends string>(v: unknown, allowed: readonly T[], path: string, def?: T): T {
  if (v === undefined && def !== undefined) return def;
  if (typeof v === 'string' && (allowed as readonly string[]).includes(v)) return v as T;
  return fail(`${path} must be one of: ${allowed.join(', ')}.`);
}

function colorRef(v: unknown, path: string, def: string): string {
  if (v === undefined) return def;
  const n = normalizeColorRef(v);
  if (!n) return fail(`${path} is not a valid colour.`);
  return n;
}

function hex(v: unknown, path: string, def: string): string {
  if (v === undefined) return def;
  const n = typeof v === 'string' ? normalizeHex(v) : null;
  if (!n) return fail(`${path} must be a hex colour like #1a2b3c.`);
  return n;
}

const KINDS: readonly VariationKind[] = ['primary', 'horizontal', 'stacked', 'icon', 'wordmark', 'light', 'dark', 'mono', 'custom'];
const MODES: readonly ColorMode[] = ['full', 'mono', 'bw', 'bw-inverted'];
const ALIGNS: readonly TextAlign[] = ['left', 'center', 'right'];
const TRANSFORMS: readonly TextTransform[] = ['none', 'uppercase', 'lowercase'];
const DIRECTIONS: readonly TextDirection[] = ['ltr', 'rtl'];
const CAPS: readonly LineCap[] = ['butt', 'round', 'square'];

function parseObject(raw: unknown, path: string): LogoObject {
  if (!isObj(raw)) return fail(`${path} must be an object.`);
  const type = oneOf(raw.type, ['text', 'rect', 'circle', 'ellipse', 'line'] as const, `${path}.type`);
  const base = {
    id: typeof raw.id === 'string' && raw.id.length > 0 && raw.id.length <= 80 ? raw.id : uid(),
    name: str(raw.name, `${path}.name`, 80, type),
    x: num(raw.x, `${path}.x`, -100000, 100000, 0),
    y: num(raw.y, `${path}.y`, -100000, 100000, 0),
    rotation: num(raw.rotation, `${path}.rotation`, -3600, 3600, 0),
    opacity: num(raw.opacity, `${path}.opacity`, 0, 1, 1),
    visible: bool(raw.visible, true),
    locked: bool(raw.locked, false),
  };
  switch (type) {
    case 'text':
      return {
        ...base,
        type,
        text: str(raw.text, `${path}.text`, LIMITS.maxTextLength, ''),
        fontFamily: sanitizeFamily(str(raw.fontFamily, `${path}.fontFamily`, 80, DEFAULT_TEXT.fontFamily)) || DEFAULT_TEXT.fontFamily,
        fontSize: num(raw.fontSize, `${path}.fontSize`, 1, 5000, DEFAULT_TEXT.fontSize),
        fontWeight: Math.round(num(raw.fontWeight, `${path}.fontWeight`, 100, 900, DEFAULT_TEXT.fontWeight) / 100) * 100,
        italic: bool(raw.italic, false),
        letterSpacing: num(raw.letterSpacing, `${path}.letterSpacing`, -500, 1000, 0),
        lineHeight: num(raw.lineHeight, `${path}.lineHeight`, 0.3, 5, DEFAULT_TEXT.lineHeight),
        align: oneOf(raw.align, ALIGNS, `${path}.align`, 'center'),
        transform: oneOf(raw.transform, TRANSFORMS, `${path}.transform`, 'none'),
        direction: oneOf(raw.direction, DIRECTIONS, `${path}.direction`, 'ltr'),
        fill: colorRef(raw.fill, `${path}.fill`, 'primary'),
        stroke: colorRef(raw.stroke, `${path}.stroke`, 'none'),
        strokeWidth: num(raw.strokeWidth, `${path}.strokeWidth`, 0, 500, 0),
      };
    case 'line':
      return {
        ...base,
        type,
        width: num(raw.width, `${path}.width`, 0, 100000, 300),
        stroke: colorRef(raw.stroke, `${path}.stroke`, 'primary'),
        strokeWidth: num(raw.strokeWidth, `${path}.strokeWidth`, 0, 500, 6),
        lineCap: oneOf(raw.lineCap, CAPS, `${path}.lineCap`, 'round'),
      };
    default: {
      const shape = {
        ...base,
        width: num(raw.width, `${path}.width`, 0, 100000, 100),
        height: num(raw.height, `${path}.height`, 0, 100000, 100),
        fill: colorRef(raw.fill, `${path}.fill`, 'primary'),
        stroke: colorRef(raw.stroke, `${path}.stroke`, 'none'),
        strokeWidth: num(raw.strokeWidth, `${path}.strokeWidth`, 0, 500, 0),
        lockAspect: bool(raw.lockAspect, type === 'circle'),
      };
      if (type === 'rect') return { ...shape, type, cornerRadius: num(raw.cornerRadius, `${path}.cornerRadius`, 0, 100000, 0) };
      return { ...shape, type };
    }
  }
}

function parseColors(raw: unknown, path: string): ColorSettings {
  if (raw === undefined) return { ...DEFAULT_COLORS };
  if (!isObj(raw)) return fail(`${path} must be an object.`);
  return {
    background: hex(raw.background, `${path}.background`, DEFAULT_COLORS.background),
    primary: hex(raw.primary, `${path}.primary`, DEFAULT_COLORS.primary),
    secondary: hex(raw.secondary, `${path}.secondary`, DEFAULT_COLORS.secondary),
    transparentBackground: bool(raw.transparentBackground, false),
  };
}

function parseVariation(raw: unknown, path: string): Variation {
  if (!isObj(raw)) return fail(`${path} must be an object.`);
  if (!Array.isArray(raw.objects)) return fail(`${path}.objects must be a list.`);
  if (raw.objects.length > LIMITS.maxObjects) return fail(`${path} has more than ${LIMITS.maxObjects} objects.`);
  const width = Math.round(num(raw.width, `${path}.width`, LIMITS.minCanvas, LIMITS.maxCanvas));
  const height = Math.round(num(raw.height, `${path}.height`, LIMITS.minCanvas, LIMITS.maxCanvas));
  const objects = raw.objects.map((o, i) => parseObject(o, `${path}.objects[${i}]`));
  const seen = new Set<string>();
  for (const o of objects) {
    if (seen.has(o.id)) (o as { id: string }).id = uid();
    seen.add(o.id);
  }
  return {
    id: typeof raw.id === 'string' && raw.id.length > 0 && raw.id.length <= 80 ? raw.id : uid(),
    name: str(raw.name, `${path}.name`, 60, 'Variation'),
    kind: oneOf(raw.kind, KINDS, `${path}.kind`, 'custom'),
    width,
    height,
    padding: Math.round(num(raw.padding, `${path}.padding`, 0, Math.max(0, Math.min(width, height) / 2 - 8), 0)),
    colors: parseColors(raw.colors, `${path}.colors`),
    colorMode: oneOf(raw.colorMode, MODES, `${path}.colorMode`, 'full'),
    objects,
  };
}

/** Validates an arbitrary value as a project. Accepts a bare project or the `{ project }` file wrapper. */
export function parseProject(input: unknown): Result<Project> {
  try {
    let raw = input;
    if (isObj(raw) && isObj(raw.project) && raw.app !== undefined) raw = raw.project;
    if (!isObj(raw)) return fail('The file does not contain a project object.');
    if (raw.schemaVersion !== undefined && raw.schemaVersion !== 1) {
      return fail(`Unsupported project version (${String(raw.schemaVersion)}). This app understands version 1.`);
    }
    if (!Array.isArray(raw.variations) || raw.variations.length === 0) return fail('The project has no variations.');
    if (raw.variations.length > LIMITS.maxVariations) return fail(`The project has more than ${LIMITS.maxVariations} variations.`);
    const variations = raw.variations.map((v, i) => parseVariation(v, `variations[${i}]`));
    const ids = new Set<string>();
    for (const v of variations) {
      if (ids.has(v.id)) v.id = uid();
      ids.add(v.id);
    }
    const now = Date.now();
    const active = typeof raw.activeVariationId === 'string' && variations.some((v) => v.id === raw.activeVariationId) ? (raw.activeVariationId as string) : variations[0]!.id;
    const project: Project = {
      schemaVersion: 1,
      id: typeof raw.id === 'string' && raw.id.length > 0 && raw.id.length <= 80 ? raw.id : uid(),
      name: str(raw.name, 'name', 80, 'Imported logo') || 'Imported logo',
      createdAt: num(raw.createdAt, 'createdAt', 0, 8.64e15, now),
      updatedAt: num(raw.updatedAt, 'updatedAt', 0, 8.64e15, now),
      activeVariationId: active,
      variations,
    };
    if (typeof raw.templateId === 'string') project.templateId = raw.templateId.slice(0, 40);
    return { ok: true, value: project };
  } catch (e) {
    if (e instanceof ValidationError) return { ok: false, error: e.message };
    return { ok: false, error: 'The project data could not be read.' };
  }
}

/** Parses JSON text from an untrusted source (never evaluates it). */
export function parseProjectJson(text: string): Result<Project> {
  if (text.length > LIMITS.maxImportBytes) return { ok: false, error: 'The file is too large (limit 5 MB).' };
  let data: unknown;
  try {
    data = JSON.parse(text);
  } catch {
    return { ok: false, error: 'The file is not valid JSON.' };
  }
  return parseProject(data);
}

export function serializeProject(project: Project): string {
  return JSON.stringify({ app: 'KORNAR', schemaVersion: 1, exportedAt: new Date().toISOString(), project }, null, 2);
}
