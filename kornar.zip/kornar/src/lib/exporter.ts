import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import type { Variation } from '../types';
import { ExportSvg } from '../components/canvas/LogoSvg';
import { LIMITS } from './model';
import { slugify } from './util';

export interface BuildSvgOptions {
  width: number;
  height: number;
  includeBackground: boolean;
  title?: string;
}

/** Inserts line breaks between elements (never inside <text>, where whitespace would matter). */
export function prettyPrintSvg(markup: string): string {
  return markup
    .replace(/^(<svg\b[^>]*>)/, '$1\n')
    .replace(/(<\/(?:title|rect|circle|ellipse|line|text)>|\/>)(?=<)/g, '$1\n')
    .replace(/(<(?:title|rect|circle|ellipse|line|text)\b)/g, '  $1');
}

/** Builds clean, standalone SVG markup for a variation. */
export function buildSvg(variation: Variation, opts: BuildSvgOptions): string {
  const markup = renderToStaticMarkup(
    createElement(ExportSvg, { variation, width: opts.width, height: opts.height, includeBackground: opts.includeBackground, title: opts.title }),
  );
  return `<?xml version="1.0" encoding="UTF-8"?>\n${prettyPrintSvg(markup)}\n`;
}

export function validateExportSize(width: number, height: number): string | null {
  if (!Number.isFinite(width) || !Number.isFinite(height)) return 'Enter a valid width and height.';
  if (width < 16 || height < 16) return 'Width and height must be at least 16 px.';
  if (width > LIMITS.maxExport || height > LIMITS.maxExport) return `Width and height can be at most ${LIMITS.maxExport} px.`;
  return null;
}

/** Windows-safe filename (no reserved characters, no trailing dots/spaces). */
export function safeFilename(name: string, ext: string): string {
  const base = name.replace(/[<>:"/\\|?*\u0000-\u001f]/g, '').replace(/[. ]+$/g, '').trim() || 'logo';
  const withoutExt = base.toLowerCase().endsWith(`.${ext}`) ? base.slice(0, -(ext.length + 1)) : base;
  return `${withoutExt.slice(0, 120)}.${ext}`;
}

export function defaultFilename(projectName: string, variation: Variation, ext: 'svg' | 'png' | 'json', w?: number, h?: number): string {
  const parts = [slugify(projectName, 'logo'), slugify(variation.name, 'variation')];
  if (ext === 'png' && w && h) parts.push(`${w}x${h}`);
  return safeFilename(parts.join('-'), ext);
}

/** Rasterises the logo (not the app UI) by drawing the exported SVG onto an offscreen canvas. */
export async function renderPng(variation: Variation, opts: BuildSvgOptions): Promise<Blob> {
  const sizeError = validateExportSize(opts.width, opts.height);
  if (sizeError) throw new Error(sizeError);
  const svg = buildSvg(variation, opts);
  const img = new Image();
  await new Promise<void>((resolve, reject) => {
    img.onload = () => resolve();
    img.onerror = () => reject(new Error('The browser could not render the design to an image.'));
    img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  });
  const canvas = document.createElement('canvas');
  canvas.width = opts.width;
  canvas.height = opts.height;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas drawing is not available in this browser.');
  ctx.drawImage(img, 0, 0, opts.width, opts.height);
  const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, 'image/png'));
  if (!blob) throw new Error('PNG encoding failed. The image may be too large for this browser - try a smaller size.');
  return blob;
}

export function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.rel = 'noopener';
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 15000);
}

export function downloadText(text: string, filename: string, mime: string): number {
  const blob = new Blob([text], { type: `${mime};charset=utf-8` });
  downloadBlob(blob, filename);
  return blob.size;
}
