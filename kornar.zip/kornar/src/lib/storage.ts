import type { Prefs, Project, Result } from '../types';
import { parseProject } from './validate';

export interface KeyValueStore {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem(key: string): void;
}

export interface ProjectMeta {
  id: string;
  name: string;
  updatedAt: number;
}

export const DEFAULT_PREFS: Prefs = {
  theme: 'light',
  autosave: true,
  onboardingSeen: false,
  showGrid: false,
  showCenter: true,
  showSafe: true,
  snap: true,
  gridSize: 20,
};

const NS = 'kornar:v1:';
/** Prefix used by releases that shipped before the product was renamed. Only read by the migration below. */
const LEGACY_NS = 'fleximark:v1:';
const INDEX_KEY = NS + 'index';
const CURRENT_KEY = NS + 'current';
const PREFS_KEY = NS + 'prefs';
const projectKey = (id: string) => NS + 'project:' + id;

function describeError(e: unknown): string {
  const name = e instanceof Error ? e.name : '';
  if (name === 'QuotaExceededError' || name === 'NS_ERROR_DOM_QUOTA_REACHED') {
    return 'Browser storage is full. Delete saved projects you no longer need or export the project as JSON.';
  }
  if (name === 'SecurityError') return 'Browser storage is blocked (private mode or site settings).';
  return 'Browser storage is unavailable.';
}

/**
 * One-time move of data saved under the old key prefix to the current one, so a rename never strands
 * anyone's saved projects. Safe to call on every start: it does nothing once the new index exists, never
 * overwrites new data, and leaves the old data untouched unless every project was copied and verified.
 */
export function migrateLegacyData(store: KeyValueStore): { migrated: number; failed: boolean } {
  const none = { migrated: 0, failed: false };
  try {
    if (store.getItem(INDEX_KEY) !== null) return none;
    const legacyIndexRaw = store.getItem(LEGACY_NS + 'index');
    if (legacyIndexRaw === null) return none;
    let entries: ProjectMeta[] = [];
    try {
      const data: unknown = JSON.parse(legacyIndexRaw);
      if (Array.isArray(data)) entries = data.filter((m): m is ProjectMeta => !!m && typeof m.id === 'string' && typeof m.name === 'string' && typeof m.updatedAt === 'number');
    } catch {
      /* unreadable index: nothing to migrate */
    }
    const copied: ProjectMeta[] = [];
    const written: string[] = [];
    try {
      for (const m of entries) {
        const raw = store.getItem(LEGACY_NS + 'project:' + m.id);
        if (raw === null) continue;
        store.setItem(projectKey(m.id), raw);
        written.push(projectKey(m.id));
        if (store.getItem(projectKey(m.id)) !== raw) throw new Error('verify failed');
        copied.push(m);
      }
      store.setItem(INDEX_KEY, JSON.stringify(copied));
      written.push(INDEX_KEY);
      for (const key of ['current', 'prefs']) {
        const raw = store.getItem(LEGACY_NS + key);
        if (raw !== null && store.getItem(NS + key) === null) store.setItem(NS + key, raw);
      }
    } catch {
      for (const k of written) {
        try {
          store.removeItem(k);
        } catch {
          /* best effort rollback; the old data is still intact and migration is retried next start */
        }
      }
      return { migrated: 0, failed: true };
    }
    for (const m of entries) store.removeItem(LEGACY_NS + 'project:' + m.id);
    for (const key of ['index', 'current', 'prefs']) store.removeItem(LEGACY_NS + key);
    return { migrated: copied.length, failed: false };
  } catch {
    return { migrated: 0, failed: true };
  }
}

/** Persistent project storage on top of a localStorage-like store. All methods are failure-safe. */
export class ProjectStore {
  constructor(private store: KeyValueStore) {}

  list(): ProjectMeta[] {
    try {
      const raw = this.store.getItem(INDEX_KEY);
      if (!raw) return [];
      const data: unknown = JSON.parse(raw);
      if (!Array.isArray(data)) return [];
      return data
        .filter((m): m is ProjectMeta => !!m && typeof m.id === 'string' && typeof m.name === 'string' && typeof m.updatedAt === 'number')
        .sort((a, b) => b.updatedAt - a.updatedAt);
    } catch {
      return [];
    }
  }

  load(id: string): Result<Project> {
    try {
      const raw = this.store.getItem(projectKey(id));
      if (!raw) return { ok: false, error: 'Saved project not found.' };
      const parsed = parseProject(JSON.parse(raw));
      if (!parsed.ok) return { ok: false, error: `Saved project is damaged: ${parsed.error}` };
      return parsed;
    } catch {
      return { ok: false, error: 'Saved project could not be read.' };
    }
  }

  /** Writes the project and reads it back; only returns ok when the stored copy matches. */
  save(project: Project): Result<{ savedAt: number; bytes: number }> {
    try {
      const json = JSON.stringify(project);
      this.store.setItem(projectKey(project.id), json);
      if (this.store.getItem(projectKey(project.id)) !== json) {
        return { ok: false, error: 'Saving could not be verified. Your browser may be blocking storage.' };
      }
      const index = this.list().filter((m) => m.id !== project.id);
      index.push({ id: project.id, name: project.name, updatedAt: project.updatedAt });
      const indexJson = JSON.stringify(index);
      this.store.setItem(INDEX_KEY, indexJson);
      if (this.store.getItem(INDEX_KEY) !== indexJson) return { ok: false, error: 'Saving the project list failed.' };
      return { ok: true, value: { savedAt: Date.now(), bytes: json.length } };
    } catch (e) {
      return { ok: false, error: describeError(e) };
    }
  }

  remove(id: string): Result<true> {
    try {
      this.store.removeItem(projectKey(id));
      const index = this.list().filter((m) => m.id !== id);
      this.store.setItem(INDEX_KEY, JSON.stringify(index));
      if (this.getCurrentId() === id) this.store.removeItem(CURRENT_KEY);
      return { ok: true, value: true };
    } catch (e) {
      return { ok: false, error: describeError(e) };
    }
  }

  getCurrentId(): string | null {
    try {
      return this.store.getItem(CURRENT_KEY);
    } catch {
      return null;
    }
  }

  setCurrentId(id: string): void {
    try {
      this.store.setItem(CURRENT_KEY, id);
    } catch {
      /* non-critical */
    }
  }

  getPrefs(): Prefs {
    try {
      const raw = this.store.getItem(PREFS_KEY);
      if (!raw) return { ...DEFAULT_PREFS };
      const data = JSON.parse(raw) as Partial<Prefs>;
      return {
        theme: data.theme === 'dark' ? 'dark' : data.theme === 'light' ? 'light' : DEFAULT_PREFS.theme,
        autosave: typeof data.autosave === 'boolean' ? data.autosave : DEFAULT_PREFS.autosave,
        onboardingSeen: data.onboardingSeen === true,
        showGrid: data.showGrid === true,
        showCenter: typeof data.showCenter === 'boolean' ? data.showCenter : DEFAULT_PREFS.showCenter,
        showSafe: typeof data.showSafe === 'boolean' ? data.showSafe : DEFAULT_PREFS.showSafe,
        snap: typeof data.snap === 'boolean' ? data.snap : DEFAULT_PREFS.snap,
        gridSize: typeof data.gridSize === 'number' && data.gridSize >= 2 && data.gridSize <= 500 ? data.gridSize : DEFAULT_PREFS.gridSize,
      };
    } catch {
      return { ...DEFAULT_PREFS };
    }
  }

  setPrefs(p: Prefs): void {
    try {
      this.store.setItem(PREFS_KEY, JSON.stringify(p));
    } catch {
      /* non-critical */
    }
  }
}

/** Real browser storage, or an in-memory fallback when localStorage is blocked. */
export function createBrowserStore(): { store: ProjectStore; persistent: boolean } {
  try {
    const ls = window.localStorage;
    const probe = NS + 'probe';
    ls.setItem(probe, '1');
    ls.removeItem(probe);
    migrateLegacyData(ls);
    return { store: new ProjectStore(ls), persistent: true };
  } catch {
    const mem = new Map<string, string>();
    return {
      persistent: false,
      store: new ProjectStore({
        getItem: (k) => mem.get(k) ?? null,
        setItem: (k, v) => void mem.set(k, v),
        removeItem: (k) => void mem.delete(k),
      }),
    };
  }
}
