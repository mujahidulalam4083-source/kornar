export type GenericFamily = 'sans-serif' | 'serif' | 'monospace' | 'cursive';

export interface FontDef {
  family: string;
  generic: GenericFamily;
  /** Scripts the font is commonly known to cover (informational only). */
  scripts?: string;
  /** Not shipped with Windows/macOS: the user must install it. */
  optional?: boolean;
}

export const FONT_LIST: FontDef[] = [
  { family: 'sans-serif', generic: 'sans-serif', scripts: 'System default' },
  { family: 'serif', generic: 'serif', scripts: 'System default' },
  { family: 'monospace', generic: 'monospace', scripts: 'System default' },
  { family: 'Arial', generic: 'sans-serif', scripts: 'Latin, Arabic' },
  { family: 'Arial Black', generic: 'sans-serif', scripts: 'Latin' },
  { family: 'Segoe UI', generic: 'sans-serif', scripts: 'Latin, Arabic' },
  { family: 'Tahoma', generic: 'sans-serif', scripts: 'Latin, Arabic' },
  { family: 'Verdana', generic: 'sans-serif', scripts: 'Latin' },
  { family: 'Trebuchet MS', generic: 'sans-serif', scripts: 'Latin' },
  { family: 'Bahnschrift', generic: 'sans-serif', scripts: 'Latin' },
  { family: 'Century Gothic', generic: 'sans-serif', scripts: 'Latin' },
  { family: 'Calibri', generic: 'sans-serif', scripts: 'Latin' },
  { family: 'Impact', generic: 'sans-serif', scripts: 'Latin' },
  { family: 'Georgia', generic: 'serif', scripts: 'Latin' },
  { family: 'Times New Roman', generic: 'serif', scripts: 'Latin, Arabic' },
  { family: 'Palatino Linotype', generic: 'serif', scripts: 'Latin' },
  { family: 'Cambria', generic: 'serif', scripts: 'Latin' },
  { family: 'Garamond', generic: 'serif', scripts: 'Latin' },
  { family: 'Courier New', generic: 'monospace', scripts: 'Latin' },
  { family: 'Consolas', generic: 'monospace', scripts: 'Latin' },
  { family: 'Nirmala UI', generic: 'sans-serif', scripts: 'Bengali, Indic' },
  { family: 'Vrinda', generic: 'sans-serif', scripts: 'Bengali' },
  { family: 'Shonar Bangla', generic: 'sans-serif', scripts: 'Bengali' },
  { family: 'Sakkal Majalla', generic: 'sans-serif', scripts: 'Arabic' },
  { family: 'Traditional Arabic', generic: 'serif', scripts: 'Arabic' },
  { family: 'Arabic Typesetting', generic: 'serif', scripts: 'Arabic' },
  { family: 'Inter', generic: 'sans-serif', scripts: 'Latin', optional: true },
  { family: 'Montserrat', generic: 'sans-serif', scripts: 'Latin', optional: true },
  { family: 'Playfair Display', generic: 'serif', scripts: 'Latin', optional: true },
  { family: 'Amiri', generic: 'serif', scripts: 'Arabic, Latin', optional: true },
  { family: 'Noto Naskh Arabic', generic: 'serif', scripts: 'Arabic', optional: true },
  { family: 'Cairo', generic: 'sans-serif', scripts: 'Arabic, Latin', optional: true },
];

const GENERIC_NAMES = ['sans-serif', 'serif', 'monospace', 'cursive', 'system-ui'];

/** Removes characters that could break out of a CSS/SVG font-family value. */
export function sanitizeFamily(family: string): string {
  return family.replace(/["'\\;{}<>()]/g, '').replace(/\s+/g, ' ').trim().slice(0, 64);
}

export function genericFor(family: string): GenericFamily {
  const found = FONT_LIST.find((f) => f.family.toLowerCase() === family.toLowerCase());
  if (found) return found.generic;
  if (family === 'serif' || family === 'monospace' || family === 'cursive') return family;
  return 'sans-serif';
}

/** CSS font-family value with a safe generic fallback, e.g. `'Arial', sans-serif`. */
export function fontStack(family: string): string {
  const clean = sanitizeFamily(family) || 'sans-serif';
  if (GENERIC_NAMES.includes(clean)) return clean;
  return `'${clean}', ${genericFor(clean)}`;
}

const availabilityCache = new Map<string, boolean>();
let probeCtx: CanvasRenderingContext2D | null | undefined;

function getProbe(): CanvasRenderingContext2D | null {
  if (probeCtx !== undefined) return probeCtx;
  if (typeof document === 'undefined') {
    probeCtx = null;
    return probeCtx;
  }
  try {
    probeCtx = document.createElement('canvas').getContext('2d');
  } catch {
    probeCtx = null;
  }
  return probeCtx;
}

/**
 * Detects whether a font family is installed by comparing text widths against generic fallbacks.
 * (document.fonts.check() reports true for unknown families, so it cannot be used here.)
 * Returns true when detection is not possible (e.g. non-browser environment).
 */
export function isFontAvailable(family: string): boolean {
  const clean = sanitizeFamily(family);
  if (!clean || GENERIC_NAMES.includes(clean)) return true;
  const cached = availabilityCache.get(clean);
  if (cached !== undefined) return cached;
  const ctx = getProbe();
  if (!ctx) return true;
  const sample = 'mmmmmmmmmmlliWWW0123456789';
  let available = false;
  for (const base of ['monospace', 'serif', 'sans-serif']) {
    ctx.font = `72px ${base}`;
    const baseWidth = ctx.measureText(sample).width;
    ctx.font = `72px '${clean}', ${base}`;
    if (ctx.measureText(sample).width !== baseWidth) {
      available = true;
      break;
    }
  }
  availabilityCache.set(clean, available);
  return available;
}

export function clearFontCache(): void {
  availabilityCache.clear();
}
