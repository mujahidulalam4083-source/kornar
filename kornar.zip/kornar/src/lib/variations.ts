import type { LogoObject, Variation, VariationKind } from '../types';
import { ensureContrast } from './color';
import { cloneVariation } from './model';
import { fitObjects, safeArea, selectionBounds, translateObjects, scaleObject, r2 } from './geometry';
import { clamp } from './util';

export interface VariationPreset {
  kind: VariationKind;
  label: string;
  description: string;
}

export const VARIATION_PRESETS: VariationPreset[] = [
  { kind: 'custom', label: 'Copy of current', description: 'An exact duplicate you can edit freely.' },
  { kind: 'horizontal', label: 'Horizontal', description: 'Symbol on the left, text on the right.' },
  { kind: 'stacked', label: 'Stacked', description: 'Symbol on top, text below, centred.' },
  { kind: 'icon', label: 'Icon only', description: 'Keeps every non-text object and fits it to the canvas.' },
  { kind: 'wordmark', label: 'Wordmark only', description: 'Keeps only the text and fits it to the canvas.' },
  { kind: 'light', label: 'Light background', description: 'White background with colours checked for contrast.' },
  { kind: 'dark', label: 'Dark background', description: 'Dark background with colours checked for contrast.' },
  { kind: 'mono', label: 'Monochrome', description: 'Everything painted in the primary colour.' },
];

export type DeriveResult = { ok: true; variation: Variation; note?: string } | { ok: false; error: string };

const NAMES: Record<VariationKind, string> = {
  primary: 'Primary',
  horizontal: 'Horizontal',
  stacked: 'Stacked',
  icon: 'Icon only',
  wordmark: 'Wordmark only',
  light: 'Light background',
  dark: 'Dark background',
  mono: 'Monochrome',
  custom: 'Copy',
};

const LAYOUT_NOTE = 'Automatic layouts are a starting point - fine-tune positions manually if needed.';
const COLOR_NOTE = 'Objects that use custom (non-palette) colours keep them; adjust those manually if needed.';

function fitInto(v: Variation, objects: LogoObject[]): LogoObject[] {
  return fitObjects(objects, safeArea(v));
}

/** Builds a new variation from `source` for the requested kind. Never mutates `source`. */
export function deriveVariation(source: Variation, kind: VariationKind): DeriveResult {
  const clone = cloneVariation(source, kind === 'custom' ? `${source.name} copy` : NAMES[kind]);
  clone.kind = kind;
  const texts = clone.objects.filter((o) => o.type === 'text' && o.visible);
  const symbols = clone.objects.filter((o) => o.type !== 'text' && o.visible);

  switch (kind) {
    case 'custom':
    case 'primary':
      return { ok: true, variation: clone };

    case 'mono':
      return { ok: true, variation: { ...clone, colorMode: 'mono' } };

    case 'light': {
      const bg = '#ffffff';
      const colors = {
        ...clone.colors,
        background: bg,
        primary: ensureContrast(source.colors.primary, bg, '#111827'),
        secondary: ensureContrast(source.colors.secondary, bg, '#4f46e5'),
        transparentBackground: false,
      };
      return { ok: true, variation: { ...clone, colors, colorMode: 'full' }, note: COLOR_NOTE };
    }

    case 'dark': {
      const bg = '#0f1115';
      const colors = {
        ...clone.colors,
        background: bg,
        primary: ensureContrast(source.colors.primary, bg, '#ffffff'),
        secondary: ensureContrast(source.colors.secondary, bg, '#a5b4fc'),
        transparentBackground: false,
      };
      return { ok: true, variation: { ...clone, colors, colorMode: 'full' }, note: COLOR_NOTE };
    }

    case 'wordmark': {
      if (texts.length === 0) return { ok: false, error: 'This variation has no text to build a wordmark from.' };
      const objects = fitInto(clone, texts);
      return { ok: true, variation: { ...clone, objects }, note: LAYOUT_NOTE };
    }

    case 'icon': {
      if (symbols.length === 0) return { ok: false, error: 'This variation has no shapes to build an icon from.' };
      const objects = fitInto(clone, symbols);
      return { ok: true, variation: { ...clone, objects }, note: LAYOUT_NOTE };
    }

    case 'horizontal':
    case 'stacked': {
      if (texts.length === 0 || symbols.length === 0) {
        return { ok: false, error: `A ${NAMES[kind].toLowerCase()} layout needs both text and shapes. Add the missing part first, or edit this variation by hand.` };
      }
      const hidden = clone.objects.filter((o) => !o.visible);
      const sb = selectionBounds(symbols)!;
      const tb = selectionBounds(texts)!;
      const gap = Math.max(24, Math.round(Math.max(sb.h, 1) * 0.12));
      const horizontal = kind === 'horizontal';
      const totalW = horizontal ? sb.w + gap + tb.w : Math.max(sb.w, tb.w);
      const totalH = horizontal ? Math.max(sb.h, tb.h) : sb.h + gap + tb.h;
      const pad = clamp(Math.round(Math.max(totalW, totalH) * 0.1), 24, 200);
      const width = Math.round(totalW + pad * 2);
      const height = Math.round(totalH + pad * 2);
      // Target positions of each group's top-left corner, relative to the new canvas.
      const sTarget = horizontal ? { x: pad, y: pad + (totalH - sb.h) / 2 } : { x: pad + (totalW - sb.w) / 2, y: pad };
      const tTarget = horizontal ? { x: pad + sb.w + gap, y: pad + (totalH - tb.h) / 2 } : { x: pad + (totalW - tb.w) / 2, y: pad + sb.h + gap };
      const movedSymbols = translateObjects(symbols, sTarget.x - sb.x, sTarget.y - sb.y);
      let movedTexts = translateObjects(texts, tTarget.x - tb.x, tTarget.y - tb.y);
      if (!horizontal) movedTexts = movedTexts.map((o) => (o.type === 'text' ? { ...o, align: 'center' as const } : o));
      const byId = new Map<string, LogoObject>([...movedSymbols, ...movedTexts].map((o) => [o.id, o]));
      const objects = [...clone.objects.filter((o) => o.visible).map((o) => byId.get(o.id) ?? o), ...hidden];
      return { ok: true, variation: { ...clone, width, height, padding: pad, objects }, note: LAYOUT_NOTE };
    }
  }
}

/** Scales a whole variation (content + canvas) by a factor. Handy for "make it bigger" helpers. */
export function scaleVariation(v: Variation, s: number): Variation {
  const objects = v.objects.map((o) => scaleObject(o, s, { x: 0, y: 0 }, { x: 0, y: 0 }));
  return { ...v, width: Math.round(v.width * s), height: Math.round(v.height * s), padding: r2(v.padding * s), objects };
}
