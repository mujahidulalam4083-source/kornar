import type { TextObject, TextTransform } from '../types';
import { fontStack } from './fonts';

/**
 * Text layout. SVG has no way to ask for a text box size, so the editor measures with a canvas 2D
 * context. In non-browser environments (unit tests) a deterministic estimate is used instead.
 */

const REF_SIZE = 100;
let ctx: CanvasRenderingContext2D | null | undefined;

function getCtx(): CanvasRenderingContext2D | null {
  if (ctx !== undefined) return ctx;
  if (typeof document === 'undefined') {
    ctx = null;
    return ctx;
  }
  try {
    ctx = document.createElement('canvas').getContext('2d');
  } catch {
    ctx = null;
  }
  return ctx;
}

const widthCache = new Map<string, number>();
const metricCache = new Map<string, { ascent: number; descent: number }>();

export function applyTextTransform(text: string, t: TextTransform): string {
  if (t === 'uppercase') return text.toUpperCase();
  if (t === 'lowercase') return text.toLowerCase();
  return text;
}

/** Arabic-script ranges. Letter-spacing breaks cursive joining, so it is disabled for these. */
const CURSIVE = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/;
export function hasCursiveScript(text: string): boolean {
  return CURSIVE.test(text);
}

export function effectiveLetterSpacing(o: Pick<TextObject, 'text' | 'letterSpacing'>): number {
  return hasCursiveScript(o.text) ? 0 : o.letterSpacing;
}

export function textLines(o: Pick<TextObject, 'text' | 'transform'>): string[] {
  return applyTextTransform(o.text, o.transform).split(/\r?\n/);
}

export function cssFont(o: Pick<TextObject, 'italic' | 'fontWeight' | 'fontFamily'>, size: number): string {
  return `${o.italic ? 'italic ' : ''}${o.fontWeight} ${size}px ${fontStack(o.fontFamily)}`;
}

function rawWidthAtRef(o: TextObject, line: string): number {
  const c = getCtx();
  if (!c) return [...line].length * REF_SIZE * 0.56;
  const key = `${o.fontFamily}|${o.fontWeight}|${o.italic}|${line}`;
  const hit = widthCache.get(key);
  if (hit !== undefined) return hit;
  c.font = cssFont(o, REF_SIZE);
  const w = c.measureText(line).width;
  if (widthCache.size > 5000) widthCache.clear();
  widthCache.set(key, w);
  return w;
}

function metricsAtRef(o: TextObject): { ascent: number; descent: number } {
  const c = getCtx();
  const fallback = { ascent: 0.8 * REF_SIZE, descent: 0.2 * REF_SIZE };
  if (!c) return fallback;
  const key = `${o.fontFamily}|${o.fontWeight}|${o.italic}`;
  const hit = metricCache.get(key);
  if (hit) return hit;
  c.font = cssFont(o, REF_SIZE);
  const m = c.measureText('Hgأ');
  const ascent = typeof m.fontBoundingBoxAscent === 'number' ? m.fontBoundingBoxAscent : fallback.ascent;
  const descent = typeof m.fontBoundingBoxDescent === 'number' ? m.fontBoundingBoxDescent : fallback.descent;
  const out = { ascent: ascent > 0 ? ascent : fallback.ascent, descent: descent > 0 ? descent : fallback.descent };
  metricCache.set(key, out);
  return out;
}

export interface TextLayout {
  lines: string[];
  widths: number[];
  width: number;
  height: number;
  lineBox: number;
  /** Distance from the box top to the first baseline. */
  firstBaseline: number;
}

export function layoutText(o: TextObject): TextLayout {
  const lines = textLines(o);
  const ls = effectiveLetterSpacing(o);
  const size = Math.max(o.fontSize, 1);
  const widths = lines.map((line) => {
    const chars = [...line].length;
    return (rawWidthAtRef(o, line) * size) / REF_SIZE + ls * chars;
  });
  const lineBox = size * o.lineHeight;
  const m = metricsAtRef(o);
  const asc = (m.ascent * size) / REF_SIZE;
  const desc = (m.descent * size) / REF_SIZE;
  const halfLeading = (lineBox - (asc + desc)) / 2;
  return {
    lines,
    widths,
    width: Math.max(...widths, size * 0.4),
    height: lines.length * lineBox,
    lineBox,
    firstBaseline: halfLeading + asc,
  };
}
