import type {
  CircleObject,
  ColorSettings,
  EllipseObject,
  LineObject,
  LogoObject,
  ObjectType,
  Project,
  RectObject,
  TextObject,
  Variation,
  VariationKind,
} from '../types';
import { uid } from './id';
import { placeCentered } from './geometry';

export const LIMITS = {
  minCanvas: 16,
  maxCanvas: 8000,
  maxExport: 8192,
  maxObjects: 500,
  maxVariations: 30,
  maxTextLength: 2000,
  maxHistory: 100,
  maxImportBytes: 5 * 1024 * 1024,
} as const;

export const DEFAULT_COLORS: ColorSettings = {
  background: '#ffffff',
  primary: '#111827',
  secondary: '#4f46e5',
  transparentBackground: false,
};

export const DEFAULT_TEXT = {
  text: 'Your Logo',
  fontFamily: 'Arial',
  fontSize: 96,
  fontWeight: 700,
  italic: false,
  letterSpacing: 0,
  lineHeight: 1.1,
  align: 'center',
  transform: 'none',
  direction: 'ltr',
  fill: 'primary',
  stroke: 'none',
  strokeWidth: 0,
} as const;

export const DEFAULT_SHAPE = {
  fill: 'primary',
  stroke: 'none',
  strokeWidth: 0,
  opacity: 1,
  rotation: 0,
} as const;

export const ASPECT_PRESETS: { id: string; label: string; ratio: number }[] = [
  { id: '1:1', label: '1:1', ratio: 1 },
  { id: '4:3', label: '4:3', ratio: 4 / 3 },
  { id: '3:2', label: '3:2', ratio: 3 / 2 },
  { id: '16:9', label: '16:9', ratio: 16 / 9 },
  { id: '2:1', label: '2:1', ratio: 2 },
  { id: '3:1', label: '3:1', ratio: 3 },
  { id: '4:5', label: '4:5', ratio: 4 / 5 },
  { id: '9:16', label: '9:16', ratio: 9 / 16 },
];

const base = (name: string) => ({ id: uid(), name, x: 0, y: 0, rotation: 0, opacity: 1, visible: true, locked: false });

export function createText(p: Partial<TextObject> = {}): TextObject {
  return { ...base('Text'), ...DEFAULT_TEXT, type: 'text', ...p } as TextObject;
}

export function createRect(p: Partial<RectObject> = {}): RectObject {
  return { ...base('Rectangle'), ...DEFAULT_SHAPE, type: 'rect', width: 240, height: 160, cornerRadius: 0, lockAspect: false, ...p } as RectObject;
}

export function createCircle(p: Partial<CircleObject> = {}): CircleObject {
  return { ...base('Circle'), ...DEFAULT_SHAPE, fill: 'secondary', type: 'circle', width: 180, height: 180, lockAspect: true, ...p } as CircleObject;
}

export function createEllipse(p: Partial<EllipseObject> = {}): EllipseObject {
  return { ...base('Ellipse'), ...DEFAULT_SHAPE, type: 'ellipse', width: 260, height: 150, lockAspect: false, ...p } as EllipseObject;
}

export function createLine(p: Partial<LineObject> = {}): LineObject {
  return { ...base('Line'), type: 'line', width: 300, stroke: 'primary', strokeWidth: 6, lineCap: 'round', ...p } as LineObject;
}

export function nextName(baseName: string, objects: LogoObject[]): string {
  const taken = new Set(objects.map((o) => o.name));
  if (!taken.has(baseName)) return baseName;
  let i = 2;
  while (taken.has(`${baseName} ${i}`)) i++;
  return `${baseName} ${i}`;
}

/** Creates a new object of the given type centred on (cx, cy). */
export function createObjectAt(type: ObjectType, cx: number, cy: number, existing: LogoObject[]): LogoObject {
  const factory = { text: createText, rect: createRect, circle: createCircle, ellipse: createEllipse, line: createLine }[type];
  const obj = factory() as LogoObject;
  const named = { ...obj, name: nextName(obj.name, existing) } as LogoObject;
  const off = (existing.length % 6) * 12;
  return placeCentered(named, cx + off, cy + off);
}

export function createVariation(p: Partial<Variation> = {}): Variation {
  return {
    id: uid(),
    name: 'Primary',
    kind: 'primary' as VariationKind,
    width: 1200,
    height: 800,
    padding: 60,
    colors: { ...DEFAULT_COLORS },
    colorMode: 'full',
    objects: [],
    ...p,
  };
}

export function createProject(name: string, variations: Variation[], templateId?: string): Project {
  const now = Date.now();
  return {
    schemaVersion: 1,
    id: uid(),
    name,
    createdAt: now,
    updatedAt: now,
    ...(templateId ? { templateId } : {}),
    activeVariationId: variations[0]!.id,
    variations,
  };
}

export function createBlankProject(name = 'Untitled logo'): Project {
  return createProject(name, [createVariation()], 'blank');
}

/** Deep-clones objects/variations assigning fresh ids. */
export function cloneObject<T extends LogoObject>(o: T): T {
  return { ...structuredClone(o), id: uid() };
}

export function cloneVariation(v: Variation, name = v.name): Variation {
  return { ...structuredClone(v), id: uid(), name, objects: v.objects.map(cloneObject) };
}
