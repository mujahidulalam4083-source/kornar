import type { LogoObject, Project, Variation } from '../types';
import { createCircle, createLine, createProject, createRect, createText, createVariation } from './model';
import { getBounds, placeCentered } from './geometry';
import { layoutText } from './measure';

/**
 * Original, fully editable starter designs. Everything is built from the same text/shape objects the
 * editor exposes - nothing is a flattened image. Colours reference the palette roles, so switching
 * palettes recolours the whole design.
 */

export interface Template {
  id: string;
  name: string;
  description: string;
  build: () => Project;
}

const centerX = (o: LogoObject, cx: number): LogoObject => ({ ...o, x: cx - getBounds(o).w / 2 });

function wordmark(): Project {
  const v = createVariation({
    width: 1200,
    height: 600,
    padding: 80,
    colors: { background: '#f7f5f0', primary: '#1a1a1a', secondary: '#c8553d', transparentBackground: false },
  });
  const word = createText({ name: 'Wordmark', text: 'lumena', fontFamily: 'Arial', fontSize: 170, fontWeight: 400, letterSpacing: 6, lineHeight: 1, align: 'left' });
  const wb = getBounds(word);
  const dot = 34;
  const gap = 22;
  const total = wb.w + gap + dot;
  const x = 600 - total / 2;
  const y = 215;
  const placedWord = { ...word, x, y };
  const baseline = y + layoutText(placedWord).firstBaseline;
  const accent = createCircle({ name: 'Accent dot', width: dot, height: dot, x: x + wb.w + gap, y: baseline - dot, fill: 'secondary' });
  const tag = createText({ name: 'Descriptor', text: 'DESIGN STUDIO', fontSize: 28, fontWeight: 400, letterSpacing: 14, fill: 'secondary', lineHeight: 1.1 });
  const placedTag = centerX({ ...tag, y: y + wb.h + 18 }, 600);
  v.objects = [placedWord, accent, placedTag];
  return createProject('Minimal wordmark', [v], 'minimal-wordmark');
}

function boldTypographic(): Project {
  const v = createVariation({
    width: 1200,
    height: 600,
    padding: 80,
    colors: { background: '#111827', primary: '#f3f4f6', secondary: '#a3e635', transparentBackground: false },
  });
  const text = createText({ name: 'Wordmark', text: 'FORM\nWORK', fontFamily: 'Arial Black', fontSize: 190, fontWeight: 900, letterSpacing: -4, lineHeight: 0.88, align: 'left' });
  const tb = getBounds(text);
  const barW = 26;
  const gap = 34;
  const total = barW + gap + tb.w;
  const x0 = 600 - total / 2;
  const y0 = 120;
  const bar = createRect({ name: 'Accent bar', x: x0, y: y0 + 8, width: barW, height: tb.h - 16, fill: 'secondary' });
  const t = { ...text, x: x0 + barW + gap, y: y0 };
  const sub = createText({ name: 'Descriptor', text: 'TYPE FOUNDRY  /  EST. 2024', fontFamily: 'Arial', fontSize: 26, fontWeight: 700, letterSpacing: 9, fill: 'secondary', align: 'left' });
  v.objects = [bar, t, { ...sub, x: x0 + barW + gap, y: y0 + tb.h + 28 }];
  return createProject('Bold typographic logo', [v], 'bold-typographic');
}

function geometricSymbol(): Project {
  const v = createVariation({
    width: 1000,
    height: 1000,
    padding: 80,
    colors: { background: '#eaf4f8', primary: '#0b3c5d', secondary: '#1d9bf0', transparentBackground: false },
  });
  const a = createCircle({ name: 'Circle left', width: 320, height: 320, x: 500 - 60 - 160, y: 380 - 160, fill: 'primary' });
  const b = createCircle({ name: 'Circle right', width: 320, height: 320, x: 500 + 60 - 160, y: 380 - 160, fill: 'secondary', opacity: 0.92 });
  const gem = createRect({ name: 'Cut-out diamond', width: 120, height: 120, x: 440, y: 320, rotation: 45, fill: 'background', lockAspect: true });
  const word = createText({ name: 'Wordmark', text: 'orbit', fontSize: 120, fontWeight: 700, letterSpacing: 18, transform: 'uppercase', lineHeight: 1 });
  const rule = createLine({ name: 'Rule', width: 120, strokeWidth: 8, stroke: 'secondary', x: 440, y: 800 });
  v.objects = [a, b, gem, placeCentered({ ...word, y: 0 }, 500, 650), rule];
  return createProject('Geometric symbol', [v], 'geometric-symbol');
}

function circularBadge(): Project {
  const v = createVariation({
    width: 1000,
    height: 1000,
    padding: 80,
    colors: { background: '#f2efe6', primary: '#1f4d3a', secondary: '#d9a441', transparentBackground: false },
  });
  const ring = (name: string, d: number, extra: object) => createCircle({ name, width: d, height: d, x: 500 - d / 2, y: 500 - d / 2, fill: 'none', ...extra });
  const outer = ring('Outer ring', 760, { stroke: 'primary', strokeWidth: 14 });
  const thin = ring('Thin ring', 690, { stroke: 'secondary', strokeWidth: 4 });
  const disc = ring('Disc', 600, { fill: 'primary' });
  const big = createText({ name: 'Name', text: 'BREW', fontFamily: 'Arial Black', fontSize: 150, fontWeight: 900, letterSpacing: 4, lineHeight: 1, fill: 'background' });
  const amp = createText({ name: 'Amp', text: '& CO', fontFamily: 'Georgia', fontSize: 84, fontWeight: 700, italic: true, lineHeight: 1, fill: 'secondary' });
  const since = createText({ name: 'Since', text: 'SINCE 2024', fontFamily: 'Arial', fontSize: 34, fontWeight: 700, letterSpacing: 12, lineHeight: 1, fill: 'background' });
  const hs = [big, amp, since].map((o) => getBounds(o).h);
  const gaps = 10;
  const total = hs[0]! + hs[1]! + hs[2]! + gaps * 2 + 24;
  let y = 500 - total / 2;
  const items: LogoObject[] = [];
  items.push(centerX({ ...big, y }, 500));
  y += hs[0]! + gaps;
  items.push(centerX({ ...amp, y }, 500));
  y += hs[1]! + gaps + 24;
  const sinceBox = getBounds(since);
  items.push(centerX({ ...since, y }, 500));
  const lineLen = 70;
  const ly = y + sinceBox.h / 2;
  items.push(createLine({ name: 'Rule left', x: 500 - sinceBox.w / 2 - 24 - lineLen, y: ly, width: lineLen, strokeWidth: 4, stroke: 'secondary' }));
  items.push(createLine({ name: 'Rule right', x: 500 + sinceBox.w / 2 + 24, y: ly, width: lineLen, strokeWidth: 4, stroke: 'secondary' }));
  v.objects = [outer, thin, disc, ...items];
  return createProject('Circular badge', [v], 'circular-badge');
}

function arabicInspired(): Project {
  const v = createVariation({
    width: 1000,
    height: 1000,
    padding: 60,
    colors: { background: '#0b1b3a', primary: '#e8c872', secondary: '#ffffff', transparentBackground: false },
  });
  const cx = 500;
  const cy = 400;
  const sq = (name: string, size: number, rot: number, stroke: string, sw: number) =>
    createRect({ name, width: size, height: size, x: cx - size / 2, y: cy - size / 2, rotation: rot, fill: 'none', stroke, strokeWidth: sw, lockAspect: true });
  const ring = (name: string, d: number, stroke: string, sw: number) =>
    createCircle({ name, width: d, height: d, x: cx - d / 2, y: cy - d / 2, fill: 'none', stroke, strokeWidth: sw });
  const arabic = createText({
    name: 'Arabic text',
    text: 'نجمة',
    fontFamily: 'Tahoma',
    fontSize: 120,
    fontWeight: 700,
    direction: 'rtl',
    lineHeight: 1.1,
    fill: 'primary',
  });
  const latin = createText({ name: 'Latin text', text: 'NAJMA', fontFamily: 'Arial', fontSize: 28, fontWeight: 400, letterSpacing: 18, fill: 'secondary', lineHeight: 1 });
  v.objects = [
    ring('Outer ring', 720, 'secondary', 3),
    sq('Star square A', 440, 0, 'primary', 10),
    sq('Star square B', 440, 45, 'primary', 10),
    ring('Inner ring', 300, 'primary', 6),
    sq('Core square A', 150, 0, 'secondary', 4),
    sq('Core square B', 150, 45, 'secondary', 4),
    createCircle({ name: 'Centre dot', width: 36, height: 36, x: cx - 18, y: cy - 18, fill: 'primary' }),
    centerX({ ...arabic, y: 780 }, cx),
    centerX({ ...latin, y: 915 }, cx),
  ];
  return createProject('Arabic-inspired geometric mark', [v], 'arabic-geometric');
}

function editorial(): Project {
  const v = createVariation({
    width: 1200,
    height: 600,
    padding: 80,
    colors: { background: '#f6ebe0', primary: '#1f1a17', secondary: '#b4532a', transparentBackground: false },
  });
  const kicker = createText({ name: 'Kicker', text: 'VOL. 07  -  QUARTERLY REVIEW', fontFamily: 'Arial', fontSize: 24, fontWeight: 700, letterSpacing: 10, fill: 'secondary', align: 'left', lineHeight: 1 });
  const title = createText({ name: 'Title', text: 'Atlas', fontFamily: 'Georgia', fontSize: 230, fontWeight: 400, italic: true, letterSpacing: -4, lineHeight: 1, align: 'left' });
  const foot = createText({ name: 'Tagline', text: 'Essays on design & place', fontFamily: 'Georgia', fontSize: 36, fontWeight: 400, italic: true, lineHeight: 1, align: 'left' });
  const kb = getBounds(kicker);
  const tb = getBounds(title);
  const fb = getBounds(foot);
  const w = Math.max(tb.w + 50, kb.w, fb.w);
  const total = kb.h + 22 + 3 + 6 + tb.h + 6 + fb.h;
  const x = 600 - w / 2;
  let y = 300 - total / 2;
  const items: LogoObject[] = [];
  items.push({ ...kicker, x, y });
  y += kb.h + 22;
  items.push(createLine({ name: 'Rule', x, y, width: w, strokeWidth: 3, stroke: 'primary', lineCap: 'butt' }));
  y += 3 + 6;
  items.push({ ...title, x, y });
  items.push(createRect({ name: 'Accent square', width: 30, height: 30, x: x + tb.w + 14, y: y + layoutText(title).firstBaseline - 30, fill: 'secondary' }));
  y += tb.h + 6;
  items.push({ ...foot, x, y });
  v.objects = items;
  return createProject('Modern editorial identity', [v], 'modern-editorial');
}

export const TEMPLATES: Template[] = [
  { id: 'minimal-wordmark', name: 'Minimal wordmark', description: 'Light lowercase type with a single accent dot.', build: wordmark },
  { id: 'bold-typographic', name: 'Bold typographic', description: 'Heavy stacked lettering with an accent bar.', build: boldTypographic },
  { id: 'geometric-symbol', name: 'Geometric symbol', description: 'Overlapping circles with a cut-out diamond.', build: geometricSymbol },
  { id: 'circular-badge', name: 'Circular badge', description: 'Concentric rings framing a stacked name.', build: circularBadge },
  { id: 'arabic-geometric', name: 'Arabic-inspired geometric mark', description: 'Eight-pointed star construction with RTL text.', build: arabicInspired },
  { id: 'modern-editorial', name: 'Modern editorial identity', description: 'Serif italic title with rule and kicker.', build: editorial },
];

export function buildTemplate(id: string): Project | null {
  return TEMPLATES.find((t) => t.id === id)?.build() ?? null;
}

export function blankVariation(): Variation {
  return createVariation();
}

