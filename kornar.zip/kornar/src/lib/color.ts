import type { ColorRef, ColorSettings, ColorMode } from '../types';

const HEX = /^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i;

/** Accepts "#abc", "abc", "#AABBCC"; returns lowercase "#rrggbb" or null when invalid. */
export function normalizeHex(input: string): string | null {
  let s = input.trim();
  if (!s.startsWith('#')) s = '#' + s;
  if (!HEX.test(s)) return null;
  if (s.length === 4) s = '#' + s[1] + s[1] + s[2] + s[2] + s[3] + s[3];
  return s.toLowerCase();
}

export function hexToRgb(hex: string): [number, number, number] {
  const h = normalizeHex(hex) ?? '#000000';
  return [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
}

export function relativeLuminance(hex: string): number {
  const [r, g, b] = hexToRgb(hex).map((v) => {
    const s = v / 255;
    return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
  }) as [number, number, number];
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

export function contrastRatio(a: string, b: string): number {
  const la = relativeLuminance(a);
  const lb = relativeLuminance(b);
  const hi = Math.max(la, lb);
  const lo = Math.min(la, lb);
  return (hi + 0.05) / (lo + 0.05);
}

/** Keep `color` if it reads on `against`, otherwise use `fallback`. */
export function ensureContrast(color: string, against: string, fallback: string, min = 3): string {
  return contrastRatio(color, against) >= min ? color : fallback;
}

export const COLOR_ROLES = ['primary', 'secondary', 'background', 'none'] as const;

export function isRole(ref: string): boolean {
  return (COLOR_ROLES as readonly string[]).includes(ref);
}

/** Returns a canonical colour ref ("primary" | ... | "#rrggbb") or null if invalid. */
export function normalizeColorRef(ref: unknown): ColorRef | null {
  if (typeof ref !== 'string') return null;
  if (isRole(ref)) return ref;
  return normalizeHex(ref);
}

interface ColorContext {
  colors: ColorSettings;
  colorMode: ColorMode;
}

/** Background colour as it should be painted for the current colour mode. */
export function resolveBackground(v: ColorContext): string {
  switch (v.colorMode) {
    case 'bw':
      return '#ffffff';
    case 'bw-inverted':
      return '#000000';
    default:
      return v.colors.background;
  }
}

/** Turns a colour ref into a concrete CSS colour (or "none") for the variation's colour mode. */
export function resolveColor(ref: ColorRef, v: ColorContext): string {
  if (ref === 'none') return 'none';
  const { colors, colorMode } = v;
  const isHex = !isRole(ref);
  switch (colorMode) {
    case 'mono':
      if (ref === 'background') return colors.background;
      return colors.primary;
    case 'bw':
      if (ref === 'background') return '#ffffff';
      if (isHex) return relativeLuminance(ref) >= 0.85 ? '#ffffff' : '#000000';
      return '#000000';
    case 'bw-inverted':
      if (ref === 'background') return '#000000';
      if (isHex) return relativeLuminance(ref) >= 0.85 ? '#000000' : '#ffffff';
      return '#ffffff';
    default:
      if (ref === 'primary') return colors.primary;
      if (ref === 'secondary') return colors.secondary;
      if (ref === 'background') return colors.background;
      return ref;
  }
}
