import type { ColorMode, ColorSettings, LogoObject, ObjectPatch, Project, Variation } from '../types';
import { clamp } from './util';
import { LIMITS, cloneObject } from './model';
import { r2 } from './geometry';

export interface EditorState {
  project: Project;
  activeId: string;
  selection: string[];
  past: Project[];
  future: Project[];
  lastKey: string | null;
  lastAt: number;
}

export interface Meta {
  /** Timestamp supplied by the dispatcher so the reducer stays pure. */
  t?: number;
  /** Consecutive actions with the same key inside `window` ms share one undo step. */
  coalesce?: string;
  window?: number;
}

export type Action = Meta &
  (
    | { type: 'load'; project: Project; activeId?: string }
    | { type: 'rename'; name: string }
    | { type: 'setActiveVariation'; id: string }
    | { type: 'select'; ids: string[] }
    | { type: 'toggleSelect'; id: string }
    | { type: 'addObject'; object: LogoObject }
    | { type: 'patchObjects'; ids: string[]; patch: ObjectPatch }
    | { type: 'applyChanges'; changes: Record<string, ObjectPatch> }
    | { type: 'deleteObjects'; ids: string[] }
    | { type: 'duplicateObjects'; ids: string[] }
    | { type: 'reorder'; id: string; to: 'up' | 'down' | 'top' | 'bottom' }
    | { type: 'setCanvas'; width?: number; height?: number; padding?: number; recenter?: boolean }
    | { type: 'setColors'; patch: Partial<ColorSettings>; allVariations?: boolean }
    | { type: 'setColorMode'; mode: ColorMode }
    | { type: 'addVariation'; variation: Variation }
    | { type: 'deleteVariation'; id: string }
    | { type: 'renameVariation'; id: string; name: string }
    | { type: 'replaceObjects'; objects: LogoObject[] }
    | { type: 'replaceVariation'; variation: Variation }
    | { type: 'undo' }
    | { type: 'redo' }
  );

export function createEditorState(project: Project, activeId?: string): EditorState {
  const id = project.variations.some((v) => v.id === activeId) ? activeId! : project.variations.some((v) => v.id === project.activeVariationId) ? project.activeVariationId : project.variations[0]!.id;
  return { project, activeId: id, selection: [], past: [], future: [], lastKey: null, lastAt: 0 };
}

export const getActiveVariation = (s: Pick<EditorState, 'project' | 'activeId'>): Variation =>
  s.project.variations.find((v) => v.id === s.activeId) ?? s.project.variations[0]!;

function commit(s: EditorState, next: Project, a: Meta, selection?: string[]): EditorState {
  if (next === s.project) return selection ? { ...s, selection } : s;
  const t = a.t ?? 0;
  const merge = !!a.coalesce && a.coalesce === s.lastKey && t - s.lastAt <= (a.window ?? 1000);
  const past = merge ? s.past : [...s.past, s.project].slice(-LIMITS.maxHistory);
  return {
    ...s,
    project: { ...next, updatedAt: t || next.updatedAt },
    past,
    future: [],
    selection: selection ?? s.selection,
    lastKey: a.coalesce ?? null,
    lastAt: t,
  };
}

function mapActive(s: EditorState, fn: (v: Variation) => Variation): Project {
  let changed = false;
  const variations = s.project.variations.map((v) => {
    if (v.id !== s.activeId) return v;
    const nv = fn(v);
    if (nv !== v) changed = true;
    return nv;
  });
  return changed ? { ...s.project, variations } : s.project;
}

const mapObjects = (v: Variation, fn: (o: LogoObject) => LogoObject): Variation => {
  let changed = false;
  const objects = v.objects.map((o) => {
    const n = fn(o);
    if (n !== o) changed = true;
    return n;
  });
  return changed ? { ...v, objects } : v;
};

/** Merges a patch into an object, ignoring keys that don't apply to its type. Returns the same object if nothing changes. */
function applyPatch(o: LogoObject, patch: ObjectPatch): LogoObject {
  const next: Record<string, unknown> = { ...o };
  let changed = false;
  for (const [k, val] of Object.entries(patch)) {
    if (val === undefined || !(k in o)) continue;
    if ((o as unknown as Record<string, unknown>)[k] !== val) {
      next[k] = val;
      changed = true;
    }
  }
  return changed ? (next as unknown as LogoObject) : o;
}

function sanitizeSelection(ids: string[], v: Variation): string[] {
  return ids.filter((id) => v.objects.some((o) => o.id === id));
}

export function reducer(s: EditorState, a: Action): EditorState {
  switch (a.type) {
    case 'load':
      return createEditorState(a.project, a.activeId);

    case 'rename': {
      const name = a.name.slice(0, 80);
      if (name === s.project.name) return s;
      return commit(s, { ...s.project, name }, { ...a, coalesce: a.coalesce ?? 'rename' });
    }

    case 'setActiveVariation':
      if (!s.project.variations.some((v) => v.id === a.id) || a.id === s.activeId) return s;
      return { ...s, activeId: a.id, selection: [] };

    case 'select':
      return { ...s, selection: sanitizeSelection(a.ids, getActiveVariation(s)) };

    case 'toggleSelect':
      return { ...s, selection: s.selection.includes(a.id) ? s.selection.filter((i) => i !== a.id) : [...s.selection, a.id] };

    case 'addObject': {
      const v = getActiveVariation(s);
      if (v.objects.length >= LIMITS.maxObjects) return s;
      return commit(s, mapActive(s, (vv) => ({ ...vv, objects: [...vv.objects, a.object] })), a, [a.object.id]);
    }

    case 'patchObjects': {
      const ids = new Set(a.ids);
      return commit(s, mapActive(s, (v) => mapObjects(v, (o) => (ids.has(o.id) ? applyPatch(o, a.patch) : o))), a);
    }

    case 'applyChanges':
      return commit(s, mapActive(s, (v) => mapObjects(v, (o) => (a.changes[o.id] ? applyPatch(o, a.changes[o.id]!) : o))), a);

    case 'deleteObjects': {
      const ids = new Set(a.ids);
      const next = mapActive(s, (v) => (v.objects.some((o) => ids.has(o.id)) ? { ...v, objects: v.objects.filter((o) => !ids.has(o.id)) } : v));
      return commit(s, next, a, s.selection.filter((i) => !ids.has(i)));
    }

    case 'duplicateObjects': {
      const v = getActiveVariation(s);
      const ids = new Set(a.ids);
      const clones = v.objects
        .filter((o) => ids.has(o.id))
        .map((o) => {
          const c = cloneObject(o);
          return { ...c, name: `${o.name} copy`, x: r2(o.x + 20), y: r2(o.y + 20), locked: false } as LogoObject;
        });
      if (clones.length === 0 || v.objects.length + clones.length > LIMITS.maxObjects) return s;
      return commit(s, mapActive(s, (vv) => ({ ...vv, objects: [...vv.objects, ...clones] })), a, clones.map((c) => c.id));
    }

    case 'reorder': {
      return commit(
        s,
        mapActive(s, (v) => {
          const i = v.objects.findIndex((o) => o.id === a.id);
          if (i < 0) return v;
          const last = v.objects.length - 1;
          const j = a.to === 'up' ? Math.min(i + 1, last) : a.to === 'down' ? Math.max(i - 1, 0) : a.to === 'top' ? last : 0;
          if (j === i) return v;
          const objects = [...v.objects];
          const [item] = objects.splice(i, 1);
          objects.splice(j, 0, item!);
          return { ...v, objects };
        }),
        a,
      );
    }

    case 'setCanvas': {
      return commit(
        s,
        mapActive(s, (v) => {
          const width = Math.round(clamp(a.width ?? v.width, LIMITS.minCanvas, LIMITS.maxCanvas));
          const height = Math.round(clamp(a.height ?? v.height, LIMITS.minCanvas, LIMITS.maxCanvas));
          const maxPad = Math.max(0, Math.min(width, height) / 2 - 8);
          const padding = Math.round(clamp(a.padding ?? v.padding, 0, maxPad));
          if (width === v.width && height === v.height && padding === v.padding) return v;
          const dx = a.recenter ? (width - v.width) / 2 : 0;
          const dy = a.recenter ? (height - v.height) / 2 : 0;
          const objects = dx || dy ? v.objects.map((o) => ({ ...o, x: r2(o.x + dx), y: r2(o.y + dy) })) : v.objects;
          return { ...v, width, height, padding, objects };
        }),
        a,
      );
    }

    case 'setColors': {
      const apply = (v: Variation): Variation => ({ ...v, colors: { ...v.colors, ...a.patch } });
      if (a.allVariations) return commit(s, { ...s.project, variations: s.project.variations.map(apply) }, a);
      return commit(s, mapActive(s, apply), a);
    }

    case 'setColorMode':
      return commit(s, mapActive(s, (v) => (v.colorMode === a.mode ? v : { ...v, colorMode: a.mode })), a);

    case 'addVariation': {
      if (s.project.variations.length >= LIMITS.maxVariations) return s;
      const next = { ...s.project, variations: [...s.project.variations, a.variation] };
      return { ...commit(s, next, a, []), activeId: a.variation.id };
    }

    case 'deleteVariation': {
      if (s.project.variations.length <= 1) return s;
      const idx = s.project.variations.findIndex((v) => v.id === a.id);
      if (idx < 0) return s;
      const variations = s.project.variations.filter((v) => v.id !== a.id);
      const activeId = s.activeId === a.id ? variations[Math.min(idx, variations.length - 1)]!.id : s.activeId;
      return { ...commit(s, { ...s.project, variations }, a, s.activeId === a.id ? [] : s.selection), activeId };
    }

    case 'renameVariation': {
      const name = a.name.slice(0, 60);
      const variations = s.project.variations.map((v) => (v.id === a.id && v.name !== name ? { ...v, name } : v));
      const changed = variations.some((v, i) => v !== s.project.variations[i]);
      return changed ? commit(s, { ...s.project, variations }, { ...a, coalesce: a.coalesce ?? `rv:${a.id}` }) : s;
    }

    case 'replaceObjects':
      return commit(s, mapActive(s, (v) => ({ ...v, objects: a.objects })), a, sanitizeSelection(s.selection, { ...getActiveVariation(s), objects: a.objects }));

    case 'replaceVariation': {
      const variations = s.project.variations.map((v) => (v.id === s.activeId ? { ...a.variation, id: v.id } : v));
      return commit(s, { ...s.project, variations }, a, []);
    }

    case 'undo': {
      const prev = s.past[s.past.length - 1];
      if (!prev) return s;
      return restore(s, prev, s.past.slice(0, -1), [s.project, ...s.future]);
    }

    case 'redo': {
      const next = s.future[0];
      if (!next) return s;
      return restore(s, next, [...s.past, s.project], s.future.slice(1));
    }
  }
}

function restore(s: EditorState, project: Project, past: Project[], future: Project[]): EditorState {
  const activeId = project.variations.some((v) => v.id === s.activeId) ? s.activeId : project.variations[0]!.id;
  const v = project.variations.find((x) => x.id === activeId)!;
  return { ...s, project, activeId, past, future, selection: sanitizeSelection(s.selection, v), lastKey: null, lastAt: 0 };
}

