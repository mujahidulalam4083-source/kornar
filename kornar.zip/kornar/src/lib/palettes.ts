export interface Palette {
  id: string;
  name: string;
  background: string;
  primary: string;
  secondary: string;
}

export const PALETTES: Palette[] = [
  { id: 'ink-paper', name: 'Ink & Paper', background: '#f7f5f0', primary: '#1a1a1a', secondary: '#c8553d' },
  { id: 'midnight', name: 'Midnight', background: '#0f172a', primary: '#f8fafc', secondary: '#38bdf8' },
  { id: 'forest', name: 'Forest', background: '#f2efe6', primary: '#1f4d3a', secondary: '#d9a441' },
  { id: 'sunset', name: 'Sunset', background: '#fff4e6', primary: '#8a2c0d', secondary: '#f97316' },
  { id: 'ocean', name: 'Ocean', background: '#eaf4f8', primary: '#0b3c5d', secondary: '#1d9bf0' },
  { id: 'berry', name: 'Berry', background: '#fdf2f8', primary: '#831843', secondary: '#ec4899' },
  { id: 'slate-lime', name: 'Slate & Lime', background: '#111827', primary: '#f3f4f6', secondary: '#a3e635' },
  { id: 'terracotta', name: 'Terracotta', background: '#f6ebe0', primary: '#1f1a17', secondary: '#b4532a' },
  { id: 'lavender', name: 'Lavender', background: '#f5f3ff', primary: '#3b2a7a', secondary: '#8b5cf6' },
  { id: 'gold-navy', name: 'Gold & Navy', background: '#0b1b3a', primary: '#e8c872', secondary: '#ffffff' },
  { id: 'mono', name: 'Graphite', background: '#ffffff', primary: '#111111', secondary: '#777777' },
  { id: 'emerald', name: 'Emerald', background: '#ecfdf5', primary: '#064e3b', secondary: '#10b981' },
];
