import type { HandleId, LogoObject, ObjectPatch, Variation } from '../types';
import { layoutText } from './measure';
import { clamp, round } from './util';

export interface Point {
  x: number;
  y: number;
}
export interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

export const r2 = (v: number): number => round(v, 2);

/** Unrotated bounding box. Text boxes come from measurement; lines have zero height. */
export function getBounds(o: LogoObject): Rect {
  switch (o.type) {
    case 'text': {
      const l = layoutText(o);
      return { x: o.x, y: o.y, w: l.width, h: l.height };
    }
    case 'line':
      return { x: o.x, y: o.y, w: o.width, h: 0 };
    default:
      return { x: o.x, y: o.y, w: o.width, h: o.height };
  }
}

/** Box used for selection / handles. Lines get their stroke thickness as height. */
export function getFrame(o: LogoObject): Rect {
  const b = getBounds(o);
  if (o.type === 'line') {
    const t = Math.max(o.strokeWidth, 1);
    return { x: b.x, y: b.y - t / 2, w: b.w, h: t };
  }
  return b;
}

export const centerOf = (r: Rect): Point => ({ x: r.x + r.w / 2, y: r.y + r.h / 2 });

export function rotateVec(v: Point, deg: number): Point {
  const a = (deg * Math.PI) / 180;
  const cos = Math.cos(a);
  const sin = Math.sin(a);
  return { x: v.x * cos - v.y * sin, y: v.x * sin + v.y * cos };
}

export function rotatePoint(p: Point, c: Point, deg: number): Point {
  const v = rotateVec({ x: p.x - c.x, y: p.y - c.y }, deg);
  return { x: c.x + v.x, y: c.y + v.y };
}

export function getCornerPoints(o: LogoObject): Point[] {
  const f = getFrame(o);
  const c = centerOf(f);
  const pts = [
    { x: f.x, y: f.y },
    { x: f.x + f.w, y: f.y },
    { x: f.x + f.w, y: f.y + f.h },
    { x: f.x, y: f.y + f.h },
  ];
  return o.rotation ? pts.map((p) => rotatePoint(p, c, o.rotation)) : pts;
}

/** Axis-aligned bounding box of the rotated object. */
export function getAABB(o: LogoObject): Rect {
  const pts = getCornerPoints(o);
  const xs = pts.map((p) => p.x);
  const ys = pts.map((p) => p.y);
  const x = Math.min(...xs);
  const y = Math.min(...ys);
  return { x, y, w: Math.max(...xs) - x, h: Math.max(...ys) - y };
}

export function unionRects(rects: Rect[]): Rect | null {
  if (rects.length === 0) return null;
  const x1 = Math.min(...rects.map((r) => r.x));
  const y1 = Math.min(...rects.map((r) => r.y));
  const x2 = Math.max(...rects.map((r) => r.x + r.w));
  const y2 = Math.max(...rects.map((r) => r.y + r.h));
  return { x: x1, y: y1, w: x2 - x1, h: y2 - y1 };
}

export const selectionBounds = (objs: LogoObject[]): Rect | null => unionRects(objs.map(getAABB));

export function rectsIntersect(a: Rect, b: Rect): boolean {
  return a.x <= b.x + b.w && a.x + a.w >= b.x && a.y <= b.y + b.h && a.y + a.h >= b.y;
}

/** Returns a copy of `o` whose bounding box is centred on (cx, cy). */
export function placeCentered<T extends LogoObject>(o: T, cx: number, cy: number): T {
  const b = getBounds(o);
  return { ...o, x: cx - b.w / 2, y: cy - b.h / 2 };
}

// ---------------------------------------------------------------------------------------------
// Resizing & rotating
// ---------------------------------------------------------------------------------------------

const MIN_SIZE = 4;

export interface ResizeOptions {
  keepAspect: boolean;
  fromCenter: boolean;
}

/**
 * Computes the patch for dragging resize handle `handle` from pointer position p0 to p.
 * Works in the object's rotated local space so rotated objects resize correctly, and keeps the
 * opposite edge/corner fixed in canvas space. Text is scaled via font size (always proportional).
 */
export function resizeObject(start: LogoObject, handle: HandleId, p0: Point, p: Point, opts: ResizeOptions): ObjectPatch {
  const b = getBounds(start);
  const c0 = centerOf(b);
  const d = rotateVec({ x: p.x - p0.x, y: p.y - p0.y }, -start.rotation);
  const hx = handle.includes('e') ? 1 : handle.includes('w') ? -1 : 0;
  let hy = handle.includes('s') ? 1 : handle.includes('n') ? -1 : 0;
  if (start.type === 'line') hy = 0;
  const mult = opts.fromCenter ? 2 : 1;
  const w0 = Math.max(b.w, 0.0001);
  const h0 = Math.max(b.h, 0.0001);

  let nw = hx ? Math.max(MIN_SIZE, b.w + hx * d.x * mult) : b.w;
  let nh = hy ? Math.max(MIN_SIZE, b.h + hy * d.y * mult) : b.h;

  const lock = start.type !== 'line' && (opts.keepAspect || start.type === 'circle' || start.type === 'text');
  if (lock) {
    let s: number;
    if (hx && hy) s = Math.max(nw / w0, nh / h0);
    else if (hx) s = nw / w0;
    else s = nh / h0;
    const minS = start.type === 'text' ? 4 / Math.max(start.fontSize, 1) : MIN_SIZE / Math.min(w0, h0);
    s = Math.max(s, minS);
    nw = w0 * s;
    nh = h0 * s;
  }

  const shift = opts.fromCenter
    ? { x: 0, y: 0 }
    : rotateVec({ x: (hx * (nw - b.w)) / 2, y: (hy * (nh - b.h)) / 2 }, start.rotation);
  const nc = { x: c0.x + shift.x, y: c0.y + shift.y };

  switch (start.type) {
    case 'text': {
      const s = nw / w0;
      return {
        x: nc.x - nw / 2,
        y: nc.y - nh / 2,
        fontSize: r2(start.fontSize * s),
        letterSpacing: r2(start.letterSpacing * s),
        strokeWidth: r2(start.strokeWidth * s),
      };
    }
    case 'line':
      return { x: r2(nc.x - nw / 2), y: r2(nc.y), width: r2(nw) };
    default:
      return { x: r2(nc.x - nw / 2), y: r2(nc.y - nh / 2), width: r2(nw), height: r2(nh) };
  }
}

export function angleFromPointer(center: Point, p: Point, snap: boolean): number {
  let a = (Math.atan2(p.y - center.y, p.x - center.x) * 180) / Math.PI + 90;
  if (snap) a = Math.round(a / 15) * 15;
  a = ((a % 360) + 360) % 360;
  return round(a, 1);
}

// ---------------------------------------------------------------------------------------------
// Snapping
// ---------------------------------------------------------------------------------------------

export interface Guide {
  axis: 'x' | 'y';
  pos: number;
}

export interface SnapTargets {
  xs: number[];
  ys: number[];
  grid?: number;
}

function bestSnap(candidates: number[], targets: number[], threshold: number): { delta: number; pos: number } | null {
  let best: { delta: number; pos: number } | null = null;
  for (const c of candidates) {
    for (const t of targets) {
      const delta = t - c;
      if (Math.abs(delta) <= threshold && (!best || Math.abs(delta) < Math.abs(best.delta))) best = { delta, pos: t };
    }
  }
  return best;
}

/** Snaps the left/centre/right and top/middle/bottom of `box` to the targets within `threshold`. */
export function computeSnap(box: Rect, t: SnapTargets, threshold: number): { dx: number; dy: number; guides: Guide[] } {
  const cx = [box.x, box.x + box.w / 2, box.x + box.w];
  const cy = [box.y, box.y + box.h / 2, box.y + box.h];
  const xs = [...t.xs];
  const ys = [...t.ys];
  if (t.grid && t.grid > 0) {
    for (const c of cx) xs.push(Math.round(c / t.grid) * t.grid);
    for (const c of cy) ys.push(Math.round(c / t.grid) * t.grid);
  }
  const sx = bestSnap(cx, xs, threshold);
  const sy = bestSnap(cy, ys, threshold);
  const guides: Guide[] = [];
  if (sx) guides.push({ axis: 'x', pos: sx.pos });
  if (sy) guides.push({ axis: 'y', pos: sy.pos });
  return { dx: sx?.delta ?? 0, dy: sy?.delta ?? 0, guides };
}

export function snapTargetsFor(v: Variation, excludeIds: string[], grid?: number): SnapTargets {
  const xs = [0, v.width / 2, v.width];
  const ys = [0, v.height / 2, v.height];
  if (v.padding > 0) {
    xs.push(v.padding, v.width - v.padding);
    ys.push(v.padding, v.height - v.padding);
  }
  for (const o of v.objects) {
    if (excludeIds.includes(o.id) || !o.visible) continue;
    const a = getAABB(o);
    xs.push(a.x, a.x + a.w / 2, a.x + a.w);
    ys.push(a.y, a.y + a.h / 2, a.y + a.h);
  }
  return { xs, ys, grid };
}

// ---------------------------------------------------------------------------------------------
// Alignment, distribution, spacing
// ---------------------------------------------------------------------------------------------

export type AlignMode = 'left' | 'hcenter' | 'right' | 'top' | 'vcenter' | 'bottom';
export type Changes = Record<string, ObjectPatch>;

export function alignChanges(objs: LogoObject[], mode: AlignMode, area: Rect): Changes {
  const out: Changes = {};
  for (const o of objs) {
    const a = getAABB(o);
    let dx = 0;
    let dy = 0;
    switch (mode) {
      case 'left':
        dx = area.x - a.x;
        break;
      case 'hcenter':
        dx = area.x + area.w / 2 - (a.x + a.w / 2);
        break;
      case 'right':
        dx = area.x + area.w - (a.x + a.w);
        break;
      case 'top':
        dy = area.y - a.y;
        break;
      case 'vcenter':
        dy = area.y + area.h / 2 - (a.y + a.h / 2);
        break;
      case 'bottom':
        dy = area.y + area.h - (a.y + a.h);
        break;
    }
    out[o.id] = { x: r2(o.x + dx), y: r2(o.y + dy) };
  }
  return out;
}

/**
 * Arranges objects along an axis. With `gap` undefined the free space between the first and last
 * object is split evenly; with a number every gap is set to that value (the first object stays put).
 */
export function distributeChanges(objs: LogoObject[], axis: 'h' | 'v', gap?: number): Changes {
  const out: Changes = {};
  if (objs.length < 2) return out;
  const items = objs
    .map((o) => ({ o, a: getAABB(o) }))
    .sort((p, q) => (axis === 'h' ? p.a.x - q.a.x : p.a.y - q.a.y));
  const size = (r: Rect) => (axis === 'h' ? r.w : r.h);
  const start = (r: Rect) => (axis === 'h' ? r.x : r.y);
  const first = items[0]!;
  const last = items[items.length - 1]!;
  let g: number;
  if (gap === undefined) {
    if (items.length < 3) return out;
    const span = start(last.a) + size(last.a) - start(first.a);
    const total = items.reduce((s, it) => s + size(it.a), 0);
    g = (span - total) / (items.length - 1);
  } else {
    g = gap;
  }
  let cursor = start(first.a);
  for (const it of items) {
    const delta = cursor - start(it.a);
    out[it.o.id] = axis === 'h' ? { x: r2(it.o.x + delta) } : { y: r2(it.o.y + delta) };
    cursor += size(it.a) + g;
  }
  return out;
}

export function translateChanges(objs: LogoObject[], dx: number, dy: number): Changes {
  const out: Changes = {};
  for (const o of objs) out[o.id] = { x: r2(o.x + dx), y: r2(o.y + dy) };
  return out;
}

// ---------------------------------------------------------------------------------------------
// Scaling groups of objects (fit to safe area, variation layouts)
// ---------------------------------------------------------------------------------------------

/** Uniformly scales one object so that the point `from` maps to `to`. Rotation is preserved. */
export function scaleObject(o: LogoObject, s: number, from: Point, to: Point): LogoObject {
  const b = getBounds(o);
  const c = centerOf(b);
  const nc = { x: to.x + (c.x - from.x) * s, y: to.y + (c.y - from.y) * s };
  switch (o.type) {
    case 'text': {
      const w = b.w * s;
      const h = b.h * s;
      return {
        ...o,
        x: r2(nc.x - w / 2),
        y: r2(nc.y - h / 2),
        fontSize: r2(o.fontSize * s),
        letterSpacing: r2(o.letterSpacing * s),
        strokeWidth: r2(o.strokeWidth * s),
      };
    }
    case 'line':
      return { ...o, x: r2(nc.x - (o.width * s) / 2), y: r2(nc.y), width: r2(o.width * s), strokeWidth: r2(o.strokeWidth * s) };
    case 'rect': {
      const w = o.width * s;
      const h = o.height * s;
      return { ...o, x: r2(nc.x - w / 2), y: r2(nc.y - h / 2), width: r2(w), height: r2(h), strokeWidth: r2(o.strokeWidth * s), cornerRadius: r2(o.cornerRadius * s) };
    }
    default: {
      const w = o.width * s;
      const h = o.height * s;
      return { ...o, x: r2(nc.x - w / 2), y: r2(nc.y - h / 2), width: r2(w), height: r2(h), strokeWidth: r2(o.strokeWidth * s) };
    }
  }
}

export function translateObjects(objs: LogoObject[], dx: number, dy: number): LogoObject[] {
  return objs.map((o) => ({ ...o, x: r2(o.x + dx), y: r2(o.y + dy) }));
}

/** Scales (never beyond `maxScale`) and centres all objects inside `area`. */
export function fitObjects(objs: LogoObject[], area: Rect, maxScale = Infinity): LogoObject[] {
  const b = selectionBounds(objs);
  if (!b || (b.w <= 0 && b.h <= 0)) return objs;
  const sx = b.w > 0 ? area.w / b.w : Infinity;
  const sy = b.h > 0 ? area.h / b.h : Infinity;
  const s = clamp(Math.min(sx, sy), 0.01, maxScale);
  const nx = area.x + (area.w - b.w * s) / 2;
  const ny = area.y + (area.h - b.h * s) / 2;
  return objs.map((o) => scaleObject(o, s, { x: b.x, y: b.y }, { x: nx, y: ny }));
}

export function safeArea(v: Pick<Variation, 'width' | 'height' | 'padding'>): Rect {
  const p = clamp(v.padding, 0, Math.min(v.width, v.height) / 2 - 8);
  return { x: p, y: p, w: v.width - 2 * p, h: v.height - 2 * p };
}

export function cursorForHandle(handle: HandleId, rotation: number): string {
  const base: Record<HandleId, number> = { n: 0, ne: 45, e: 90, se: 135, s: 180, sw: 225, w: 270, nw: 315 };
  const a = (((base[handle] + rotation) % 360) + 360) % 360;
  const idx = Math.round(a / 45) % 8;
  return ['ns-resize', 'nesw-resize', 'ew-resize', 'nwse-resize', 'ns-resize', 'nesw-resize', 'ew-resize', 'nwse-resize'][idx]!;
}
