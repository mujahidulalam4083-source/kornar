/** A colour reference: a palette role, "none", or a #rrggbb hex value. */
export type ColorRef = string;
export type ColorRole = 'primary' | 'secondary' | 'background' | 'none';

export type TextAlign = 'left' | 'center' | 'right';
export type TextTransform = 'none' | 'uppercase' | 'lowercase';
export type TextDirection = 'ltr' | 'rtl';
export type LineCap = 'butt' | 'round' | 'square';
export type ObjectType = 'text' | 'rect' | 'circle' | 'ellipse' | 'line';

export interface ObjectBase {
  id: string;
  name: string;
  /** Top-left of the (unrotated) bounding box; for lines the left end point. */
  x: number;
  y: number;
  /** Degrees, clockwise, around the centre of the bounding box. */
  rotation: number;
  opacity: number;
  visible: boolean;
  locked: boolean;
}

export interface TextObject extends ObjectBase {
  type: 'text';
  text: string;
  fontFamily: string;
  fontSize: number;
  fontWeight: number;
  italic: boolean;
  letterSpacing: number;
  lineHeight: number;
  align: TextAlign;
  transform: TextTransform;
  direction: TextDirection;
  fill: ColorRef;
  stroke: ColorRef;
  strokeWidth: number;
}

export interface ShapeBase extends ObjectBase {
  width: number;
  height: number;
  fill: ColorRef;
  stroke: ColorRef;
  strokeWidth: number;
  lockAspect: boolean;
}

export interface RectObject extends ShapeBase {
  type: 'rect';
  cornerRadius: number;
}
export interface CircleObject extends ShapeBase {
  type: 'circle';
}
export interface EllipseObject extends ShapeBase {
  type: 'ellipse';
}

/** A horizontal segment of length `width` starting at (x, y); rotate it for other angles. */
export interface LineObject extends ObjectBase {
  type: 'line';
  width: number;
  stroke: ColorRef;
  strokeWidth: number;
  lineCap: LineCap;
}

export type ShapeObject = RectObject | CircleObject | EllipseObject;
export type LogoObject = TextObject | RectObject | CircleObject | EllipseObject | LineObject;

type Mutable<T> = Omit<T, 'id' | 'type'>;
/** Any subset of editable object properties (applied with a shallow merge). */
export type ObjectPatch = Partial<Mutable<TextObject> & Mutable<RectObject> & Mutable<LineObject>>;

export interface ColorSettings {
  background: string;
  primary: string;
  secondary: string;
  transparentBackground: boolean;
}

export type ColorMode = 'full' | 'mono' | 'bw' | 'bw-inverted';

export type VariationKind =
  | 'primary'
  | 'horizontal'
  | 'stacked'
  | 'icon'
  | 'wordmark'
  | 'light'
  | 'dark'
  | 'mono'
  | 'custom';

export interface Variation {
  id: string;
  name: string;
  kind: VariationKind;
  width: number;
  height: number;
  /** Safe-area padding in px. */
  padding: number;
  colors: ColorSettings;
  colorMode: ColorMode;
  /** Z-order: first = bottom, last = top. */
  objects: LogoObject[];
}

export interface Project {
  schemaVersion: 1;
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  templateId?: string;
  /** Remembered at save time; the live value is held by the editor. */
  activeVariationId: string;
  variations: Variation[];
}

export interface ExportOptions {
  format: 'svg' | 'png';
  /** Output size in px. For SVG this sets width/height attributes; the viewBox always stays the design size. */
  width: number;
  height: number;
  includeBackground: boolean;
  filename: string;
}

export type HandleId = 'nw' | 'n' | 'ne' | 'e' | 'se' | 's' | 'sw' | 'w';

export type Result<T> = { ok: true; value: T } | { ok: false; error: string };

export interface Prefs {
  theme: 'light' | 'dark';
  autosave: boolean;
  onboardingSeen: boolean;
  showGrid: boolean;
  showCenter: boolean;
  showSafe: boolean;
  snap: boolean;
  gridSize: number;
}
