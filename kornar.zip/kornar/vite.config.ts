import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Relative base so the production build also works when opened from any folder / static host.
export default defineConfig({
  base: './',
  plugins: [react()],
  server: { port: 5173, open: true },
  build: { target: 'es2022', sourcemap: false },
});
